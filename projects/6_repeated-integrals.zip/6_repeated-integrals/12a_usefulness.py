
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "12a_usefulness"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    cauchy = mo.graphics.MultiImage("./resources/cauchy-formula.png").set(
        pos=7j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    mainlayer.merge(cauchy)

    cbox = mo.grid.rect(cauchy.last().box(pad=0.5)).set(
        width=4, color=[0,0,1], fill=[1,1,1]
        )
    cbox = mo.Actor(cbox)
    mainlayer.merge(cbox, beforeActor=cauchy)

    mation.endDelayUntil(3.25*30)
    print("Show sin(x) disaster:", mation.seconds())

    badsin = mo.graphics.MultiImage("./resources/sine-disaster.png").set(
        pos=3j, height=2.25
        )
    badsin = mo.Actor(badsin)
    mainlayer.append(badsin)
    badsin.fadeIn(20, jump=2j)

    mation.endDelayUntil(7.25*30)
    print("Show cartoons:", mation.seconds())

    hero = mo.graphics.MultiImage("./resources/hero-chalkboard.png").set(
        pos=-3-8j, align=[0,-1], height=9, scale_x=-1
        )
    hero = mo.Actor(hero)
    mainlayer.append(hero)
    hero.fadeIn(20)

    kman = mo.graphics.MultiImage("./resources/k-chair.png").set(
        pos=8.5+hero.last().pos.imag*1j, align=[-1,-1],
        height=7.5, rotation=-3*deg
        )
    kman = mo.Actor(kman)
    mainlayer.append(kman)
    kman.fadeIn(20)

    mation.endDelay(5)

    symb = mo.graphics.MultiImage("./resources/calculator.png").set(
        pos=(-0.3-0.31j), align=[-1,0], height=1.5
        )
    symb = mo.Actor(symb)
    mainlayer.append(symb)
    symb.fadeIn(20, jump=3+1j)

    harc = mo.grid.arc(0.24-1.33j, (-0.76-2.31j), -75*deg).set(
        width=3.5, color=[0,0,0]
        )
    harc = mo.Actor(harc)
    mainlayer.append(harc)
    harc.growIn(20)

    mation.endDelay(15)

    no = mo.text.Text("No.",
        pos=(9.19+0.13j), anchor_y=-1, font="Qarmic sans",
        size=32, color=[0,0,0]
        )
    no = mo.Actor(no)
    mainlayer.append(no)
    no.fadeIn(20, jump=-2+2j)

    karc = mo.grid.arc(9.22-0.11j, (9.98-0.65j), 60*deg).set(
        width=3.5, color=[0,0,0]
        )
    karc = mo.Actor(karc)
    mainlayer.append(karc)
    karc.growIn(20)

    mation.endDelay(10)

    time = mation.lastID()
    mo.action.fadeOut([symb, harc], atFrame=time, duration=20)

    hero.newkey(time)
    hero.newendkey(20).newSource("./resources/hero-chalkboard-sad.png").scaleByHeight()

    # time = mation.lastID()
    rats = mo.text.Text("(Rats...)",
        pos=(-5.61-0.93j), anchor_x=1, anchor_y=-1,
        font="Qarmic sans",
        size=32, color=[0,0,0]
        )
    rats = mo.Actor(rats)
    mainlayer.merge(rats, atFrame=time)
    rats.fadeIn(20, jump=-2+1j)

    harc2 = mo.grid.arc(-6.19-1.22j, (-5.24-1.96j), 75*deg).set(
        width=3.5, color=[0,0,0], dash=[8]
        )
    harc2 = mo.Actor(harc2)
    mainlayer.append(harc2)
    harc2.growIn(20)

    mation.endDelay(20)
    print("Remove cartoons:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([harc2, rats, hero, karc, no, kman],
        duration=20, atFrame=time)

    mation.endDelayUntil(20.25*30)
    print("Show disaster label:", mation.seconds())

    dlabel = mo.graphics.MultiImage("./resources/sine-underbrace.png").set(
        pos=mean([9.67, 0.57])+1.69j, width=9.67-0.57, align=[0,1],
        scale_x=0
        )
    dlabel = mo.Actor(dlabel)
    mainlayer.append(dlabel)
    dlabel.newendkey(20).scale_x = 1

    mation.endDelayUntil(26.5*30)
    print("De-label:", mation.seconds())

    time = mation.lastID()
    dlabel.rollback(20, atFrame=time)

    mation.endDelayUntil(28.5*30)
    print("Show new cartoons:", mation.seconds())

    # # mation.endDelay(30)
    # print("'Can I PLEASE use a calculator?':", mation.seconds())

    time = mation.lastID()
    hero.newkey(time, hero.first().copy())
    mo.action.fadeIn([hero, kman], duration=20, atFrame=time, stagger=10)

    mation.endDelay(5)

    calc = mo.graphics.MultiImage("./resources/calculator-please.png").set(
        pos=symb.last().pos, align=symb.last().align[:],
        height=symb.last().height
        )
    calc = mo.Actor(calc)
    mainlayer.append(calc)
    calc.fadeIn(20, jump=3+1j)

    time = mation.lastID()
    harc.newkey(time).alpha = 1
    harc.growIn(20)

    mation.endDelay(15)

    whatev = no.segment(no.keyID[0], no.keyID[1])
    for fig in whatev.keys():
        fig.text = "Fine, whatever."
    mainlayer.append(whatev)

    time = mation.lastID()
    karc.newkey(time).alpha = 1
    karc.growIn(20)

    mation.endDelay(10)

    time = mation.lastID()
    mo.action.fadeOut([calc, harc], duration=20, atFrame=time)

    hero.newkey(time)
    hero.newendkey(20).newSource("./resources/hero-chalkboard-happy.png").scaleByHeight()

    yes = rats.segment(rats.keyID[0], rats.keyID[1])
    for fig in yes.keys():
        fig.text = "Yessss..."
    mainlayer.merge(yes, atFrame=time)

    time = mation.lastID()
    harc2.newkey(time).alpha = 1
    harc2.growIn(20)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./12a_usefulness.mp4", scale=1)


main()
