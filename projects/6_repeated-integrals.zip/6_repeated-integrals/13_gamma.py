
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "13_gamma"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    title = morpho.text.Text("One more application...",
        pos=1j,
        size=72, anchor_x=0, anchor_y=0,
        color=(0,0,0)
        )
    title = morpho.Actor(title)
    mainlayer.merge(title)

    mation.endDelayUntil(5*30)
    print("Remove title:", mation.seconds())

    title.last().transition = drop
    title.fadeOut(30, jump=5j)

    mation.endDelayUntil(8.5*30)
    print("Show gamma function:", mation.seconds())

    gma = mo.graphics.MultiImage("./resources/gamma-function.png").set(
        pos=-10+3.5j, align=[-1,0], height=1.15
        )
    gma = mo.Actor(gma)
    mainlayer.append(gma)
    gma.fadeIn(20, jump=2j)

    mation.endDelayUntil(12.25*30)
    print("Fade in definition:", mation.seconds())

    gmadef = mo.graphics.MultiImage("./resources/gamma-factorial.png").set(
        pos=gma.last().pos, align=[-1,0], height=gma.last().height
        )
    gmadef = mo.Actor(gmadef)
    mainlayer.append(gmadef)
    gmadef.fadeIn(20)

    time = mation.lastID()
    gma.newkey(time).visible = False

    mation.endDelayUntil(19*30)
    print("Label 'can be non-int':", mation.seconds())

    time = mation.lastID()

    canbe = mo.graphics.MultiImage("./resources/canbe.png").set(
        pos=(0.67+6.65j), align=[0,-1.25],
        height=0.9
        )
    canbe = mo.Actor(canbe)
    mainlayer.append(canbe)
    canbe.fadeIn(20, jump=3j)

    canarrow = mo.grid.Arrow(0.72+canbe.last().pos.imag*1j, (0.72+4j)).set(
        width=4, color=[1,0,0], headSize=25
        )
    canarrow = mo.Actor(canarrow)
    mainlayer.append(canarrow)
    canarrow.growIn(20)

    # mation.start = mation.end = mation.lastID()

    mation.endDelayUntil(24*30)
    print("Show particular evaluations:", mation.seconds())

    time = mation.lastID()
    gma12 = mo.graphics.MultiImage("./resources/gamma-12.png").set(
        pos=-0.8, align=[-1,0], height=1.4
        )
    gma12 = mo.Actor(gma12)
    mainlayer.merge(gma12, atFrame=time)

    gma53 = mo.graphics.MultiImage("./resources/gamma-53.png").set(
        pos=gma12.last().pos-2j, align=[-1,0], height=gma12.last().height
        )
    gma53 = mo.Actor(gma53)
    mainlayer.merge(gma53, atFrame=time)

    gmapi = mo.graphics.MultiImage("./resources/gamma-pi.png").set(
        pos=gma53.last().pos-2j, align=[-1,0], height=gma53.last().height*0.85
        )
    gmapi = mo.Actor(gmapi)
    mainlayer.merge(gmapi, atFrame=time)

    mo.action.fadeIn([gma12, gma53, gmapi],
        atFrame=time, duration=20, stagger=15, jump=3
        )

    mation.endDelayUntil(32.25*30)
    print("Fade all but gamma(1/2):", mation.seconds())

    mo.action.fadeOut([gma53, gmapi, canarrow, canbe], duration=20)

    mation.endDelayUntil(34.5*30)
    print("Show '= sqrt(pi)':", mation.seconds())

    eqpi = mo.graphics.MultiImage("./resources/eq-sqrt-pi.png").set(
        pos=gma12.last().pos+gma12.last().width+0.5,
        align=[-1,0], height=gma12.last().height*0.85
        )
    eqpi = mo.Actor(eqpi)
    mainlayer.append(eqpi)
    eqpi.fadeIn(20, jump=3)

    mation.endDelayUntil(37.65*30)
    print("Show (-1/2)!:", mation.seconds())

    simfac = mo.graphics.MultiImage("./resources/sim-factorial.png").set(
        pos=eqpi.last().pos+eqpi.last().width+0.5,
        align=[-1,0], height=gma12.last().height
        )
    simfac = mo.Actor(simfac)
    mainlayer.append(simfac)
    simfac.fadeIn(20, jump=3)

    mation.endDelayUntil(44*30)
    print("'But how?':", mation.seconds())

    buthow = mo.text.Text("but how??",
        pos=(10.65-1.57j), anchor_x=1,
        size=56, color=[1,0,0]
        )
    buthow = mo.Actor(buthow)
    mainlayer.append(buthow)
    buthow.fadeIn(20, jump=-2j)

    mation.endDelayUntil(49.35*30)
    print("'Exists' and 'Computable':", mation.seconds())

    buthow.rollback(20)

    exists = mo.text.Text("exists",
        pos=(-1+6.31j), anchor_x=1, anchor_y=-1,
        size=56, color=[0,0,0.8]
        )
    exists = mo.Actor(exists)
    mainlayer.append(exists)
    exists.fadeIn(15, jump=-2+2j)

    earrow = mo.grid.Arrow(-2.26+6j, (-0.69+4.28j)).set(
        width=4, color=exists.last().color[:], headSize=25
        )
    earrow = mo.Actor(earrow)
    mainlayer.append(earrow)
    earrow.growIn(15)

    comp = mo.text.Text("computable",
        pos=(0.59+6.31j), anchor_x=-1, anchor_y=-1,
        size=56, color=[0,0.6,0]
        )
    comp = mo.Actor(comp)
    mainlayer.append(comp)
    comp.fadeIn(15, jump=2+2j)

    carrow = mo.grid.Arrow(1.39+6j, (-0.2+4.28j)).set(
        width=4, color=comp.last().color[:], headSize=25
        )
    carrow = mo.Actor(carrow)
    mainlayer.append(carrow)
    carrow.growIn(15)

    mation.endDelayUntil(62.25*30)
    print("Show Cauchy formula and highlight (n-1)!:", mation.seconds())

    time = mation.lastID()

    # Fade out gamma(1/2) stuff and other labels
    mo.action.rollback([carrow, comp, earrow, exists, simfac, eqpi, gma12],
        duration=20, atFrame=time, stagger=2
        )

    cauchy = mo.graphics.MultiImage("./resources/cauchy-formula-alt.png").set(
        pos=-1j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    mainlayer.append(cauchy)
    cauchy.fadeIn(20, jump=2j)

    mation.endDelay(10)

    boxer = mo.gadgets.enbox([-2.85,0.44, -2.3,-1.06],
        width=4, color=[1,0,0]
        )
    mainlayer.append(boxer)

    mation.endDelay(15)

    gboxer = mo.gadgets.enbox([2.94,7.17, 2.7,4.31],
        width=4, color=[1,0,0]
        )
    mainlayer.append(gboxer)

    mation.endDelayUntil(68*30)
    print("Fade out boxers:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([gboxer, boxer], atFrame=time, duration=20)

    mation.endDelayUntil(69*30)
    print("Replace with gamma(n):", mation.seconds())

    time = mation.lastID()
    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/cauchy-formula-gamma.png").scaleByHeight()

    gboxer2 = mo.gadgets.enbox([-2.3,-0.24, -2.33,-1.06],
        width=4, color=[1,0,0]
        )
    mainlayer.append(gboxer2)
    gboxer2.newendkey(30).set(start=1, visible=False)

    mation.endDelayUntil(76.5*30)
    print("Plug in 1/2:", mation.seconds())

    time = mation.lastID()
    plugin = mo.graphics.MultiImage("./resources/n-eq-half.png").set(
        pos=(-1.31-4.15j), align=[-0.3,0.6],
        height=1.95
        )
    plugin = mo.Actor(plugin)
    mainlayer.append(plugin)
    plugin.fadeIn(20, jump=-2j)

    parrow = mo.grid.Arrow(-0.98-4.19j, (-0.98-2.24j)).set(
        width=4, color=[1,0,0], headSize=25
        )
    parrow = mo.Actor(parrow)
    mainlayer.append(parrow)
    parrow.growIn(20)








    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./13_gamma.mp4", scale=1)


main()
