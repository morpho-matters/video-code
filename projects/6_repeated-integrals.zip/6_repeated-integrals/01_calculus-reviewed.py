
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "01_calculus-reviewed"


def card():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightviolet

    stagger = 5
    text1 = morpho.text.Text("Why Compress Integrals?",
        pos=0j-4j, anchor_x=0,
        size=128, color=[0,0,0], alpha=0
        )
    text1.transition = toss
    text1 = morpho.Actor(text1)
    mainlayer.merge(text1)
    text1.newendkey(20).set(alpha=1, transition=drop).pos += 4j

    mation.endDelay(50)

    text1.newendkey(20).set(alpha=0, visible=False).pos += 4j

    mation.endDelay(30)





    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./01card_calculus-reviewed.mp4", scale=1)


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mation.endDelay(20)

    bar = mo.grid.Path([11j,-11j]).set(
        width=5, color=[0,0,0], end=0
        )
    bar = mo.Actor(bar)
    mainlayer.merge(bar)
    bar.newendkey(30).end = 1

    mation.endDelayUntil(2*30)
    print("Show derivatives and integrals:", mation.seconds())

    time = mation.lastID()
    dy = 4
    ddx1 = mo.graphics.MultiImage("./resources/ddx1.png").set(
        pos=-16.75+7j, align=[-1,0], height=1.75
        )
    ddx1 = mo.Actor(ddx1)
    mainlayer.merge(ddx1)

    ddx2 = mo.graphics.MultiImage("./resources/ddx2.png").set(
        pos=ddx1.last().pos-dy*1j, align=[-1,0], height=ddx1.last().height
        )
    ddx2 = mo.Actor(ddx2)
    mainlayer.merge(ddx2)

    ddx3 = mo.graphics.MultiImage("./resources/ddx3.png").set(
        pos=ddx2.last().pos-dy*1j, align=[-1,0], height=1.2*ddx2.last().height
        )
    ddx3 = mo.Actor(ddx3)
    mainlayer.merge(ddx3)

    ddx4 = mo.graphics.MultiImage("./resources/ddx4.png").set(
        pos=ddx3.last().pos-dy*1j, align=[-1,0], height=ddx2.last().height
        )
    ddx4 = mo.Actor(ddx4)
    mainlayer.merge(ddx4)

    derivs = [ddx1, ddx2, ddx3, ddx4]

    integ1 = mo.graphics.MultiImage("./resources/integ1.png").set(
        pos=1+7j, align=[-1,0], height=1.75
        )
    integ1 = mo.Actor(integ1)
    mainlayer.merge(integ1)

    integ2 = mo.graphics.MultiImage("./resources/integ2.png").set(
        pos=integ1.last().pos-dy*1j, align=[-1,0], height=integ1.last().height
        )
    integ2 = mo.Actor(integ2)
    mainlayer.merge(integ2)

    integ3 = mo.graphics.MultiImage("./resources/integ3.png").set(
        pos=integ2.last().pos-dy*1j-0.5j, align=[-1,0], height=1.75*integ2.last().height
        )
    integ3 = mo.Actor(integ3)
    mainlayer.merge(integ3)

    integs = [integ1, integ2, integ3]

    mo.actions.fadeIn(derivs+integs, atFrame=time, duration=20, stagger=7, jump=2j)

    mation.endDelayUntil(7*30)
    print("Show derivative beast:", mation.seconds())

    time = mation.lastID()
    dbeast = mo.graphics.Image("./resources/ddx.png").set(
        pos=(-4-8.43j), align=[0,-1], height=4
        )
    dbeast = mo.Actor(dbeast)
    mainlayer.merge(dbeast)
    mo.actions.fadeIn(dbeast, atFrame=time, duration=20)

    mation.endDelayUntil(9*30)
    print("Show integral beast:", mation.seconds())

    ibeast = mo.graphics.Image("./resources/serpentine-integral.png").set(
        pos=-dbeast.last().pos.conjugate()-0.5j, align=[0,-1], height=6.5
        )
    ibeast = mo.Actor(ibeast)
    mainlayer.append(ibeast)
    mo.actions.fadeIn(ibeast, duration=20)

    mation.endDelayUntil(15.25*30)
    print("Show 'Power Rule':", mation.seconds())

    mo.actions.rollback([ibeast, dbeast], duration=20)

    time = mation.lastID()
    power = mo.text.Text("Power Rule",
        pos=ddx1.last().pos, anchor_x=-1,
        size=50, color=[0.2,0.2,0.8], alpha=0
        )
    power = mo.Actor(power)
    mainlayer.append(power)
    power.newendkey(20).set(alpha=1).pos += 1.5j

    mation.endDelayUntil(17*30)
    print("Show 'Product/Quotient Rule':", mation.seconds())

    prod = mo.text.Text("Product Rule",
        pos=ddx2.last().pos, anchor_x=-1,
        size=power.last().size, color=power.last().color[:], alpha=0
        )
    prod = mo.Actor(prod)
    mainlayer.append(prod)
    prod.newendkey(20).set(alpha=1).pos += 1.5j

    quot = mo.text.Text("Quotient Rule",
        pos=ddx3.last().pos, anchor_x=-1,
        size=power.last().size, color=power.last().color[:], alpha=0
        )
    quot = mo.Actor(quot)
    mainlayer.append(quot)
    quot.newendkey(20).set(alpha=1).pos += 2j

    mation.endDelayUntil(19*30)
    print("Show 'Chain Rule':", mation.seconds())

    chain = mo.text.Text("Chain Rule",
        pos=ddx4.last().pos, anchor_x=-1,
        size=power.last().size, color=power.last().color[:], alpha=0
        )
    chain = mo.Actor(chain)
    mainlayer.append(chain)
    chain.newendkey(20).set(alpha=1).pos += 1.5j

    mation.endDelayUntil(35.5*30)
    print("Show integral rules:", mation.seconds())

    time = mation.lastID()
    stagger = 10
    rules = []
    names = ["u-sub", "Integration by Parts", "Partial Fractions"]
    for n in range(3):
        rule = mo.text.Text(names[n],
            pos=integs[n].last().pos, anchor_x=-1,
            size=power.last().size, color=power.last().color[:], alpha=0
            )
        rule = mo.Actor(rule)
        rules.append(rule)
        mainlayer.merge(rule, atFrame=time+n*stagger)
        rule.newendkey(20).set(alpha=1).pos += 1.75j

    usub, voodoo, parfrac = rules
    parfrac.last().pos += 0.35j

    mation.endDelayUntil(44.3*30)
    print("Show non-elementary integral:", mation.seconds())

    nonelem = mo.graphics.Image("./resources/integ-nonelem.png").set(
        pos=integ3.last().pos.real - 5.74j, align=[-1,0], height=integ1.last().height
        )
    nonelem = mo.Actor(nonelem)
    mainlayer.append(nonelem)
    mo.actions.fadeIn(nonelem, duration=20, jump=2j)

    mation.endDelay(15)

    nonelemlabel = mo.text.Text("non-elementary",
        pos=nonelem.last().pos+nonelem.last().width+0.25+0.25j, anchor_x=-1,
        size=50, color=[1,0,0], italic=True
        )
    nonelemlabel = mo.Actor(nonelemlabel)
    mainlayer.append(nonelemlabel)
    mo.actions.fadeIn(nonelemlabel, duration=20, jump=3)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./01_calculus-reviewed.mp4", scale=1)


# card()
main()
