
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "07_slicing-the-solid"


# Converts minutes, seconds into seconds
def seconds(mins, secs=None):
    if secs is None:
        secs = mins
        mins = 0
    return 60*mins + secs

mins = 60

def main():
    # mation = mo.video.setupSpace()
    # mainlayer = mation.layers[0]
    # del mainlayer.camera.key[-1]
    # mainlayer.camera.first().orient = mo.matrix.rotation([1,0,0], -tau/4)
    # mation.background = lightviolet

    mainlayer = morpho.SpaceLayer(view=mo.video.view169())
    layer2 = mainlayer.copy()
    layerz = mainlayer.copy()
    layerz.poolPrimitives = False
    lowlayer = mainlayer.copy()
    mation = morpho.Animation([lowlayer, mainlayer, layer2, layerz])
    mation.windowShape = (1920, 1080)
    aspectRatio = mation.windowShape[0] / mation.windowShape[1]
    mation.fullscreen = True
    mation.background = lightviolet

    mainlayer.camera.first().view[:2] = [-2.5, 9.5]
    mainlayer.camera.first().rescaleHeight(aspectRatio).moveBy(1.5j)
    xmin,xmax,ymin,ymax = mainlayer.camera.first().view

    orient = mo.matrix.rotation([1,0,0], tau/4)
    orientXZ = orient.T
    mainlayer.camera.first().orient = orientXZ

    flatlayer = mo.Layer(view=mainlayer.camera.first().view[:])
    mation.merge(flatlayer, beforeLayer=0)
    toplayer = mo.Layer(view=mo.video.view169())
    mation.merge(toplayer)

    dint = mo.graphics.Image("./resources/double-definite-integral.png").set(
        pos=1j, height=2.75
        )
    dint = mo.Actor(dint)
    toplayer.merge(dint)

    mation.endDelayUntil(1*30)
    print("Fade to only inner integral:", mation.seconds())

    time = mation.lastID() + 1
    sint = mo.graphics.MultiImage("./resources/single-definite-integral-padded.png")
    sint.set(pos=dint.last().pos, height=dint.last().height)
    sint = mo.Actor(sint)
    toplayer.merge(sint, atFrame=time)

    dint.newkey(time)
    dint.fadeOut(duration=20)

    mation.endDelayUntil(5.25*30)
    print("Encircle 'a':", mation.seconds())

    circ = mo.grid.ellipse((-1.74-0.17j), 0.45).edge().set(
        width=4, color=[1,0,0], end=0
        )
    circ = mo.Actor(circ)
    toplayer.append(circ)
    circ.newendkey(20).end = 1

    mation.endDelayUntil(13.75*30)
    print("Morph 'a' to '0':", mation.seconds())

    time = mation.lastID()
    sint.newkey(time)
    sint.newendkey(20).newSource("./resources/single-integral0-padded.png").scaleByHeight()

    mation.endDelay(30)

    time = mation.lastID()
    circ.newkey(time)
    circ.fadeOut(duration=20)

    mation.endDelayUntil(16.25*30)
    print("Encircle 'y':", mation.seconds())

    circy = mo.grid.ellipse((-1.22+1.98j), 0.45).edge().set(
        width=4, color=[0,0,1], end=0
        )
    circy = mo.Actor(circy)
    toplayer.append(circy)
    circy.newendkey(20).end = 1

    mation.endDelayUntil(18*30)
    print("Draw graph:", mation.seconds())

    # Scoot formula
    time = mation.lastID()
    sint.newkey(time)
    sint.newendkey(30).pos += 6j
    circy.newkey(time)
    circy.newendkey(30).origin += 6j


    xmin,xmax,ymin,ymax = mainlayer.camera.first().view
    axes = mo.grid.SpacePath(
        [math.floor(xmin), math.ceil(xmax), 1j*math.floor(ymin), 1j*math.ceil(ymax)]
        ).set(
        width=8, color=[0,0,0], deadends={1}, zdepth=10
        ).fimage(lambda v: orient @ v)
    axes.end = 0
    axes = mo.Actor(axes)
    layerz.merge(axes, atFrame=time)
    axes.newendkey(30).end = 1

    time = mation.lastID()
    f = lambda x: (2*x**3-21*x**2+60*x+3)/20 + 0.5
    F = lambda x: (x**4-14*x**3+60*x**2+6*x)/40 + 0.5*x - 1.5
    fcurve = mo.graph.realgraph(f, 0, 7, steps=150).set(
        width=6, color=[0.8,0,0], end=0
        )
    fcurve = mo.Actor(fcurve)
    flatlayer.merge(fcurve, atFrame=time)
    fcurve.newendkey(40).end = 1

    stdFill = mo.color.parseHexColor("e64d70")
    stdColor = tuple((0.65*mo.array(stdFill)).tolist())
    endFill = mo.color.parseHexColor("4d50e6")
    endColor = tuple((0.65*mo.array(endFill)).tolist())
    fillgrad = mo.color.Gradient({0:stdFill, 1:endFill})
    area = mo.calculus.IntegralArea(
        func=f, start=0, end=0, strokeWeight=5,
        color=stdColor, fill=stdFill, alphaFill=1, steps=150
        ).set(zdepth=-1)
    area = mo.Actor(area)
    flatlayer.append(area)
    area.newendkey(30).end = 6

    time = mation.lastID()
    da = -0.2-0.1j
    alabel = mo.text.MultiText("0",
        pos=area.last().start+da,
        size=64, color=[0.8,0,0], alpha=0
        )
    alabel.set(
        background=[1,1,1],
        backAlpha=0.5, backPad=0.02, zdepth=-2
        )
    alabel.backAlpha = 0
    alabel = mo.Actor(alabel)
    flatlayer.merge(alabel, atFrame=time)
    alabel.newendkey(20).set(anchor_y=1, alpha=1)

    blabel = alabel.first().copy()
    db = -0.05j
    blabel.set(
        text="y", pos=area.last().end+db, color=[0,0,0.8], italic=True
        ).backPad += 0.025
    blabel = mo.Actor(blabel)
    flatlayer.merge(blabel, atFrame=time+10)
    blabel.newendkey(20).set(anchor_x=-1, anchor_y=1, alpha=1)

    blabelbase = blabel.last().copy()

    @mo.SkitParameters(alpha=1)
    class BTracker(mo.Skit):
        def makeFrame(self, index=None):
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            b = area.time(index).end
            num = mo.text.Number(b, decimal=2, rightDigits=2)
            ylabel = blabelbase.copy().figures[0]
            ylabel.text = "y"
            eqlabel = blabelbase.copy().figures[0]
            eqlabel.set(text=" = "+str(num), italic=False)

            blabel = mo.text.group(
                [ylabel, eqlabel], flatlayer.camera.time(index).view,
                mation.windowShape,
                pos=b+db, anchor_x=-1, anchor_y=1, alpha=alpha
                )
            # blabel.pos = b + db
            # blabel.alpha = alpha

            return blabel


    mation.endDelayUntil(22.6*30)
    print("Start varying the rightbound:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    btrack = BTracker()
    btrack = mo.Actor(btrack)
    flatlayer.merge(btrack, atFrame=time+20)

    blabel.newkey(time)
    blabel.newendkey(20, btrack.last().makeFrame(mation.lastID())).visible = False

    mation.endDelay(15)

    time = mation.lastID()
    area.newkey(time)
    area.newendkey(50).end /= 2.02
    area.newendkey(60).end = 7
    area.newendkey(30).end = area.key[1].end

    mation.endDelayUntil(31.75*30)
    print("'NOT the y-axis':", mation.seconds())

    time = mation.lastID()
    noty = mo.text.group(
        [mo.text.Text("NOT the ", size=56, color=[0,0,0]),
        mo.text.Text("y", size=56, color=[0,0,0.8], italic=True),
        mo.text.Text("-axis!", size=56, color=[0,0,0])],
        toplayer.camera.last().view, mation.windowShape,
        pos=(-9.81+8.83j), anchor_x=0, alpha=0
        )
    noty = mo.Actor(noty)
    toplayer.merge(noty, atFrame=time)
    noty.newendkey(20, mo.text.group(
        [mo.text.Text("NOT the  ", size=56, color=[0,0,0]),
        mo.text.Text("y ", size=56, color=[0,0,0.8], italic=True),
        mo.text.Text("-axis!", size=56, color=[0,0,0])],
        toplayer.camera.last().view, mation.windowShape,
        pos=(-9.81+8.83j), anchor_x=-1, alpha=1
        ))

    mation.endDelayUntil(36.75*30)
    print("Wiggle the y-parameter some:", mation.seconds())

    time = mation.lastID()
    area.newkey(time)
    area.newendkey(15).end += 0.5
    area.newendkey(20).end -= 1
    area.newendkey(20).end += 1
    area.newendkey(20).end -= 1
    area.newendkey(15).end += 0.5

    mation.endDelayUntil(55*30)
    print("Fade noty label:", mation.seconds())

    time = mation.lastID()
    noty.newkey(time)
    noty.rollback(duration=20)

    circy.newkey(time)
    circy.fadeOut(duration=20)

    # Create 3D version of integral area as a skit
    @mo.SkitParameters(
        start=0, end=1, alpha=1, yAlpha=1, color=[0,0,0],
        fill=stdFill, alphaFill=1, textsize=64,
        manualColor=0
        )
    class HSlicer(mo.SpaceSkit):
        def makeFrame(self, index=None):
            start = self.start
            end = self.end
            alpha = self.alpha
            yAlpha = self.yAlpha
            color = self.color
            fill = self.fill
            alphaFill = self.alphaFill
            textsize = self.textsize
            manualColor = bool(self.manualColor)
            if index is None:
                index = mation.currentIndex

            figs = []

            if not manualColor:
                color = tuple((0.65*mo.array(fill)).tolist())
            area = mo.calculus.IntegralArea(
                func=f, start=start, end=end, strokeWeight=5,
                color=color, alpha=alpha, fill=fill, alphaFill=alphaFill,
                steps=150
                )
            poly = mo.grid.SpacePolygon(area.polygon)
            poly = poly.fimage(lambda v: orient @ v + [0,end,0])
            figs.append(poly)

            if yAlpha > 0:
                # num = mo.text.Number(end, decimal=2, rightDigits=2)
                # blabel = blabelbase.copy()
                # blabel.text = "y = " + str(num)
                # blabel.pos = b + db
                # blabel.alpha = alpha*yAlpha
                # figs.append(blabel)

                num = mo.text.Number(end, decimal=2, rightDigits=2)
                ylabel = mo.text.SpaceText("y",
                    pos=mo.array([end+db.real,end,0+db.imag]),
                    anchor_x=-1, anchor_y=1, italic=True,
                    size=textsize, color=[0,0,0.8], alpha=alpha*yAlpha
                    )
                ylabel.set(orientable=True, orient=orient)

                eqlabel = ylabel.copy()
                eqlabel.set(text=" = "+str(num), italic=False)
                eqlabel.pos += [ylabel.width(mainlayer.viewtime(index), mation.windowShape), 0, 0]

                figs.extend([ylabel, eqlabel])

            return mo.SpaceFrame(figs)

    time = mation.lastID()
    hslicer0 = HSlicer(end=area.last().end)
    hslicer0 = mo.Actor(hslicer0)
    layerz.merge(hslicer0, atFrame=time)

    fcurve3d = mo.grid.SpacePath(fcurve.last().copy())
    fcurve3d = fcurve3d.fimage(lambda v: orient @ v)
    fcurve3d = mo.Actor(fcurve3d)
    layerz.merge(fcurve3d, atFrame=time)

    alabel3d = mo.text.SpaceMultiText("0",
        pos=orient@mo.array(alabel.last().pos),
        anchor_y=1,
        size=64, color=[0.8,0,0], alpha=1
        )
    alabel3d.set(
        background=[1,1,1],
        backAlpha=0.5, backPad=0.02, zdepth=-2,
        orientable=True, orient=orient
        )
    alabel3d.backAlpha = 0
    alabel3d = mo.Actor(alabel3d)
    lowlayer.merge(alabel3d, atFrame=time)

    area.newkey(time).visible = False
    btrack.newkey(time).visible = False
    fcurve.newkey(time).visible = False
    alabel.newkey(time).visible = False

    mation.endDelay(20)
    print("Show multiple areas:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    heatmap = mo.color.heatmap()
    yend = 6.5
    hslicer0.newendkey(30).end = yend/4
    hslicer0.last().textsize = 48

    mation.endDelay(20)

    time = mation.lastID()
    hslicer1 = hslicer0.last().copy()
    hslicer1 = mo.Actor(hslicer1)
    mainlayer.merge(hslicer1, atFrame=time+1)
    hslicer1.newendkey(20).set(fill=fillgrad.value(1/3)).end=0.5*yend

    mation.endDelay(20)

    hslicer2 = hslicer1.last().copy()
    hslicer2 = mo.Actor(hslicer2)
    mainlayer.append(hslicer2, timeOffset=1)
    hslicer2.newendkey(20).set(fill=fillgrad.value(2/3)).end = 0.75*yend

    mation.endDelay(20)

    hslicer3 = hslicer2.last().copy()
    hslicer3 = mo.Actor(hslicer3)
    mainlayer.append(hslicer3, timeOffset=1)
    hslicer3.newendkey(20).set(fill=fillgrad.value(3/3)).end = 1*yend

    mation.endDelayUntil(seconds(1, 6.5)*30)
    print("Rotate camera to 3/4 view:", mation.seconds())

    time = mation.lastID()
    oblique = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -30*deg)
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(90).set(orient=oblique).zoomOut(1.35)

    # Fade away integral expression
    sint.newkey(time)
    sint.fadeOut(duration=20)

    fcurve3d.last().origin = [0,hslicer0.last().end,0]

    # Insert additional curves
    fcurve3d_1 = fcurve3d.last().copy()
    fcurve3d_1.origin = [0,hslicer1.last().end,0]
    # fcurve3d_1.commitTransforms()
    fcurve3d_1.color = tuple((0.65*mo.array(hslicer1.last().fill)).tolist())
    fcurve3d_1 = mo.Actor(fcurve3d_1)
    mainlayer.merge(fcurve3d_1, atFrame=time)

    fcurve3d_2 = fcurve3d.last().copy()
    fcurve3d_2.origin = [0,hslicer2.last().end,0]
    # fcurve3d_2.commitTransforms()
    fcurve3d_2.color = tuple((0.65*mo.array(hslicer2.last().fill)).tolist())
    fcurve3d_2 = mo.Actor(fcurve3d_2)
    mainlayer.merge(fcurve3d_2, atFrame=time)

    fcurve3d_3 = fcurve3d.last().copy()
    fcurve3d_3.origin = [0,hslicer3.last().end,0]
    # fcurve3d_3.commitTransforms()
    fcurve3d_3.color = tuple((0.65*mo.array(hslicer2.last().fill)).tolist())
    fcurve3d_3 = mo.Actor(fcurve3d_3)
    mainlayer.merge(fcurve3d_3, atFrame=time)

    # Create y-axis
    yAxis = axes.last().copy()
    yAxis.deadends = set()
    yAxis.seq = [[0,-2,0], [0,12,0]]
    yAxis = mo.Actor(yAxis)
    mainlayer.merge(yAxis, atFrame=time)

    grid = mo.grid.mathgrid3d(
        view=[axes.last().seq[0][0].tolist(), axes.last().seq[1][0].tolist(), yAxis.last().seq[0][1].tolist(), yAxis.last().seq[1][1].tolist()],
        hsteps=1, vsteps=1,
        hmidWidth=2, vmidWidth=2,
        hcolor=mo.color.parseHexColor("008000"), alpha=0.5,
        axesColor=[0,0,0],
        axes=False,
        xaxisWidth=8, yaxisWidth=8
        ) # .fimage(lambda v: orient @ v)
    grid = mo.Actor(grid)
    lowlayer.merge(grid, atFrame=time)

    # Create axis labels
    xlabel = mo.text.SpaceText("x",
        pos=axes.last().seq[1]+[0.5,0,0], italic=True,
        size=64, color=[0,0,0]
        )
    xlabel = mo.Actor(xlabel)
    layer2.merge(xlabel, atFrame=time)

    ylabel = xlabel.last().copy().set(
        text="y", pos=yAxis.last().seq[1]+[0,0.5,0], alpha=0
        )
    ylabel = mo.Actor(ylabel)
    lowlayer.merge(ylabel, atFrame=time)
    ylabel.newkey(mainlayer.camera.lastID()).alpha = 1

    zlabel = xlabel.last().copy().set(
        text="z", pos=axes.last().seq[-1]+[0,0,0.5]
        )
    zlabel = mo.Actor(zlabel)
    layer2.merge(zlabel, atFrame=time)

    mation.endDelay(30)
    print("Slide fcurves:", mation.seconds())

    time = mation.lastID()
    stagger = 4
    for n,actor in enumerate([fcurve3d, fcurve3d_1, fcurve3d_2, fcurve3d_3]):
        actor.newkey(time+n*stagger)
        actor.newendkey(20).end = mo.lerp(0,1, (n+1)/4*yend, start=0, end=7)

    mation.endDelayUntil(seconds(1,21.5)*30)
    print("Fade in solid:", mation.seconds())

    def colorfunc(v):
        x,y,z = v.tolist()
        return fillgrad.value(mo.lerp(0,1, y, start=0, end=yend))

    def solidf(v):
        x,y,z = v
        Z = f(x)
        return mo.array([x,y,Z])

    time = mation.lastID()
    # mation.start = time
    top = mo.grid.quadgrid(
        view=[0,yend,0,yend],
        dx=yend/24, dy=yend/1,
        width=1.5,
        color=[0,0,0], fill=colorfunc,
        ).set(shading=True)
    def trianglify(v):
        x,y,z = v
        Y = (yend-x)/yend*(yend-y)
        Y = yend - Y
        return mo.array([x,Y,z])

    top = top.fimage(compose(solidf, trianglify))
    top = mo.Actor(top)
    layerz.merge(top, atFrame=time)
    top.fadeIn(duration=90)

    solid = mo.calculus.DoubleIntegralVolume(
        func=solidf, mode="dydx",
        inmin=lambda x: x, inmax=yend,
        outmin=0, outmax=yend,
        width=top.first().width, color=[0,0,0],
        fill=[0,0.5,1],
        steps=24
        )
    walls = solid.makeWalls()

    southWall = walls["south"]
    southWall.fill = colorfunc
    southWall = mo.Actor(southWall)
    layerz.merge(southWall, atFrame=time)
    southWall.fadeIn(duration=90)

    # wall = mo.calculus.Wall(
    #     func=solidf, start=0, end=complex(yend,yend),
    #     steps=24
    #     )
    # layerz.merge(wall, atFrame=time)

    mo.actions.fadeOut(
        [fcurve3d, fcurve3d_1, fcurve3d_2, fcurve3d_3,
        hslicer0, hslicer1, hslicer2, hslicer3],
        duration=90, atFrame=time
        )

    # mation.endDelayUntil()
    # print("Revolve solid around a little bit:", mation.seconds())

    # time = mation.lastID()
    # mation.start = time
    # mainlayer.camera.newkey(time)
    # mainlayer.camera.newendkey(60).orient = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -75*deg)
    # mainlayer.camera.newendkey(60).orient = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -10*deg)
    # mainlayer.camera.newendkey(30).orient = oblique

    mation.endDelayUntil(seconds(1,33.75)*30)
    print("Show single integral again:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    sint.newkey(time).set(pos=(3.81-3.75j),
        background=mation.background, backAlpha=0.5, backPad=0
        )
    sint.fadeIn(duration=20, jump=3)

    boxer = mo.gadgets.enbox([1.07,6.81, -5.28,-2.28],
        duration=30, width=4, color=[0,0,1]
        )
    toplayer.append(boxer)

    mation.endDelay(10)
    print("Show horizontal slice:", mation.seconds())

    time = mation.lastID()
    hs = HSlicer(fill=[1,1,0.25], alpha=0, manualColor=True)
    hs.zdepth = 100
    hs = mo.Actor(hs)
    layerz.merge(hs, atFrame=time)
    hs.newendkey(20).alpha = 0.7

    mation.endDelayUntil(seconds(1,38.5)*30)
    print("Show double integral version:", mation.seconds())
    # print("Move horizontal slice up and down the y-axis:", mation.seconds())

    time = mation.lastID()
    boxer.newkey(time)
    boxer.fadeOut(duration=20)

    time = mation.lastID()
    sint.newkey(time)
    sint.newendkey(20).newSource("./resources/double-integral0.png").scaleByHeight()

    outboxer = mo.gadgets.enbox(sint.last().box(pad=0.15),
        duration=30, width=4, color=[1,0,0]
        )
    toplayer.append(outboxer)


    mation.endDelay(10)

    time = mation.lastID()
    hs.newkey(time)
    hs.newendkey(60).end = yend
    hs.newendkey(75).end = 0
    hs.newendkey(30).end = 1

    mation.endDelayUntil(seconds(1,50)*30)
    print("Fade outer enboxing:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    mo.actions.fadeOut([outboxer, hs], duration=20)

    mation.endDelayUntil(seconds(1,53.25)*30)
    print("Restore original hslicers:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    origHslicers = [hslicer0, hslicer1, hslicer2, hslicer3]
    newHslicers = [mo.Actor(hslicer.last().copy()) for hslicer in origHslicers]
    for n,hslicer in enumerate(newHslicers):
        hslicer.last().set(
            zdepth=1/(n+1),
            fill=[1,1,0.25], color=[0,0,0], manualColor=True,
            yAlpha=0
            )
        layerz.merge(hslicer, atFrame=time)
    mo.actions.fadeIn(newHslicers, atFrame=time, duration=20, stagger=4)
    for hslicer in newHslicers:
        hslicer.last().alpha = 0.65

    mation.endDelayUntil(seconds(1,58.75)*30)
    print("Fade hslicers:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut(newHslicers+[sint], atFrame=time, duration=20)

    mation.endDelayUntil(seconds(2,1.25)*30)
    print("Show vertical slicer at x=0:", mation.seconds())

    time = mation.lastID()
    oblique2 = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -60*deg)
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(25).orient = oblique2

    mation.endDelay(10)

    time = mation.lastID()
    for actor in [top, southWall]:
        actor.newkey(time)
        actor.newendkey(15).alpha = 0.5

    # mation.endDelay(10)

    xlabelOrient = mo.matrix.rotation([0,0,1], tau/4) @ orient

    # Create 3D version of integral area as a skit
    @mo.SkitParameters(
        x=0, start=0, end=1, alpha=1, xAlpha=1, color=[0,0,0],
        fill=stdFill, alphaFill=1, textsize=64, backAlpha=0,
        manualColor=0
        )
    class VSlicer(mo.SpaceSkit):
        def makeFrame(self, index=None):
            x = self.x
            start = self.start
            end = self.end
            alpha = self.alpha
            xAlpha = self.xAlpha
            color = self.color
            fill = self.fill
            alphaFill = self.alphaFill
            textsize = self.textsize
            backAlpha = self.backAlpha
            manualColor = bool(self.manualColor)
            if index is None:
                index = mation.currentIndex

            figs = []
            f_x = f(x)

            if not manualColor:
                color = tuple((0.65*mo.array(fill)).tolist())
            y0 = mo.lerp(x, yend, start)
            y1 = mo.lerp(x, yend, end)
            v0 = mo.array([x, y0, 0])
            v1 = v0 + f_x*khat
            v2 = v1 + (y1-y0)*jhat
            v3 = v0 + (y1-y0)*jhat
            poly = mo.grid.SpacePolygon([v0, v1, v2, v3],
                width=5, color=color, fill=fill,
                alphaFill=alphaFill, alpha=alpha
                )
            figs.append(poly)

            if xAlpha > 0:
                # num = mo.text.Number(end, decimal=2, rightDigits=2)
                # blabel = blabelbase.copy()
                # blabel.text = "y = " + str(num)
                # blabel.pos = b + db
                # blabel.alpha = alpha*yAlpha
                # figs.append(blabel)

                num = mo.text.Number(x, decimal=2, rightDigits=2)
                xlabel = mo.text.SpaceText("x",
                    anchor_x=1, anchor_y=-1, italic=True,
                    size=textsize, color=[0,0,0], alpha=alpha*xAlpha
                    ).set(background=mation.background, backAlpha=backAlpha)
                xlabel.set(orientable=True, orient=xlabelOrient)

                eqlabel = xlabel.copy()
                eqlabel.set(text=" = "+str(num), italic=False)
                eqlabel.pos = [x, x-0.05, 0]

                xlabel.pos = eqlabel.pos - jhat*eqlabel.width(mainlayer.viewtime(index), mation.windowShape)

                figs.extend([xlabel, eqlabel])

            return mo.SpaceFrame(figs)

    time = mation.lastID() + 1
    # mation.start = time
    vslice0 = VSlicer(
        x=1, end=0, alphaFill=0.7, xAlpha=1, fill=[0,0.6,0], backAlpha=1
        ).set(zdepth=11)
    vslice0 = mo.Actor(vslice0)
    layerz.merge(vslice0, atFrame=time)
    vslice0.newendkey(20).end = 1

    mation.endDelayUntil(seconds(2,4.25)*30)
    print("Start sliding the vslice:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    vslice0.newkey(time)
    vslice0.newendkey(75).x = yend
    vslice0.newendkey(75).x = 1

    mation.endDelayUntil(seconds(2,11)*30)
    print("Draw multiple vslices:", mation.seconds())

    time = mation.lastID()+1
    # mation.start = time
    stagger = 4
    vslices = [vslice0]
    for n in range(1,4):
        vslice = vslice0.last().copy()
        vslice.xAlpha = 0
        vslice.end = 0
        vslice.x = mo.lerp(1, yend, n/4)
        vslice.zdepth += 1
        vslice = mo.Actor(vslice)
        vslices.append(vslice)
        layerz.merge(vslice, atFrame=time+n*stagger)
        vslice.newendkey(20).set(end=1, xAlpha=1)

    mation.endDelayUntil(seconds(2,15.75)*30)
    print("Rotate camera to look at slices head-on:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    mainlayer.camera.newkey(time)
    orientYZ = mo.matrix.rotation([1,0,0], -tau/4) @ mo.matrix.rotation([0,0,1], -tau/4)
    mainlayer.camera.newendkey(45).orient = orientYZ

    for vslice in vslices:
        vslice.newkey(time)
        vslice.newendkey(45).xAlpha = 0

    for actor in [top, southWall]:
        actor.newkey(time)
        actor.fadeOut(duration=45)

    # mation.endDelayUntil(seconds(2,15)*30)
    mation.endDelay(15)
    print("Flourish each rectangle:", mation.seconds())

    for vslice in vslices:
        time = mation.lastID()
        vslice.newkey(time)
        vslice.newendkey(10).set(
            fill=[1,1,0], # zdepth=10000000
            )
        vslice.newendkey(10, vslice.key(-2).copy())

    mation.endDelayUntil(seconds(2,21.75)*30)
    print("Return to previous view:", mation.seconds())

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(45).orient = oblique

    # for actor in [top, southWall]:
    #     actor.newkey(time).visible = True
    #     actor.newendkey(45).alpha = 0.5

    mo.actions.fadeIn([top, southWall],
        atFrame=time, duration=45, alpha=0.5
        )

    time = mation.lastID()
    mo.actions.fadeOut(vslices, atFrame=time, duration=20)

    for actor in [top, southWall]:
        actor.newkey(time)
        actor.newendkey(20).alpha = 1

    mation.endDelayUntil(seconds(2,25.5)*30)
    print("Fade solid and show hslices:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    mo.actions.fadeOut([top, southWall], atFrame=time, duration=30)
    mo.actions.fadeIn(origHslicers, atFrame=time, duration=30)

    mation.endDelayUntil(seconds(2,29.5)*30)
    print("Revolve camera to XZ plane:", mation.seconds())

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(50, mainlayer.camera.first().copy())

    ylabel.newkey(time)
    ylabel.fadeOut(duration=30)

    mation.endDelay(20)

    fcurve3d.newkey(time).set(visible=True, alpha=1, end=0)
    fcurve3d.newendkey(30).end = 1

    mation.endDelayUntil(seconds(2,40)*30)
    print("Fade 'behind' slices and highlight a point:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut(origHslicers[1:], atFrame=time, duration=20)

    dashx = 2
    dashline = mo.grid.SpacePath([dashx*ihat + yend*jhat, dashx*ihat + yend*jhat + khat*f(dashx)]).set(
        width=4, color=[0,0,0], end=0, dash=[15,10], zdepth=1000
        )
    dashline = mo.Actor(dashline)
    layerz.merge(dashline, atFrame=time)
    dashline.newendkey(20).end = 1

    pt = mo.grid.SpacePoint(dashline.last().positionAt(1)).set(
        size=15, strokeWeight=2, color=[0,0,0], fill=[1,1,0],
        zdepth=1000
        )
    pt.pos = [pt.pos[0], yend, pt.pos[2]]
    pt = mo.Actor(pt)
    layerz.append(pt)
    pt.fadeIn(duration=15)

    mation.endDelayUntil(seconds(2,45.5)*30)
    print("Extend right bound:", mation.seconds())

    time = mation.lastID()
    hslicer0.newkey(time)
    hslicer0.newendkey(6*30).end = yend
    hslicer0.last().zdepth = 1000

    mation.endDelayUntil(seconds(2,59.5)*30)
    print("Revolve camera to reveal flat line:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(60, mainlayer.camera.key[2].copy())

    ylabel.newkey(time)
    ylabel.fadeIn(duration=60)
    fcurve3d.newkey(time)
    fcurve3d.fadeOut(duration=60)

    mo.actions.fadeIn([top, southWall], atFrame=time, duration=60, alpha=0.75)

    hslicer0.newkey(time)
    hslicer0.newendkey(60).alphaFill = 0.75

    # Yellow flat line
    flatline = mo.grid.SpacePath([[2,2,f(2)], [2,yend,f(2)]])
    flatline.set(width=5, color=[1,1,0], zdepth=1000)
    flatline = mo.Actor(flatline)
    layerz.merge(flatline, atFrame=time, beforeActor=pt)

    mation.endDelay(45)
    print("Scoot slice up and down a bit:", mation.seconds())

    time = mation.lastID()
    hslicer0.newkey(time)
    hslicer0.newendkey(60).end = 2
    hslicer0.newendkey(60, hslicer0.key[-2].copy())

    pt.newkey(time)
    pt.newendkey(60).pos[1] = 2
    pt.newendkey(60, pt.key[-2].copy())

    dashline.newkey(time)
    dashline.newendkey(60).origin -= (yend-2)*jhat
    dashline.newendkey(60, dashline.key[-2].copy())

    mation.endDelayUntil(seconds(3,7.75)*30)
    print("Fade and show vslice:", mation.seconds())

    time = mation.lastID()
    hslicer0.newkey(time)
    hslicer0.fadeOut(duration=20)

    dashline.newkey(time)
    dashline.newendkey(20).color = [1,1,1]

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(30).orient = oblique2

    time = mation.lastID()
    mainVslice = vslice0.last().copy()
    xmain = 2
    mainVslice.set(
        x=xmain, color=[0,0,0], fill=[1,1,0], manualColor=True, zdepth=1000,
        alphaFill=0.65
        )
    mainVslice = mo.Actor(mainVslice)
    layerz.merge(mainVslice, atFrame=time, beforeActor=pt)
    mainVslice.fadeIn(duration=40)

    mo.actions.fadeOut([dashline, flatline, pt], atFrame=time, duration=40)

    mation.endDelayUntil(seconds(3,12)*30)
    print("Show height label:", mation.seconds())

    time = mation.lastID()
    rect = mainVslice.last().makeFrame().figures[0]
    flabel = mo.graphics.SpaceMultiImage("./resources/f(x).png").set(
        pos=mean(rect.vertices), height=0.5, orientable=True,
        orient=mo.matrix.rotation([0,1,0], tau/4) @ mo.matrix.rotation([0,0,1], tau/4),
        zdepth=1000
        )
    flabel = mo.Actor(flabel)
    layerz.merge(flabel, atFrame=time)
    flabel.fadeIn(duration=20)

    time = mation.lastID()
    uparrow = mo.grid.SpaceArrow()
    uparrow.head = uparrow.tail = flabel.last().pos + 0.5*khat
    uparrow.set(width=5, color=[0,0,0], headSize=0, zdepth=1000)
    uparrow = mo.Actor(uparrow)
    layerz.merge(uparrow, atFrame=time)
    uparrow.newendkey(20).head = np.append(uparrow.last().head[:2], f(2))
    uparrow.last().headSize = 22

    downarrow = uparrow.first().copy()
    downarrow.head = downarrow.tail = flabel.last().pos - 0.5*khat
    downarrow = mo.Actor(downarrow)
    layerz.merge(downarrow, atFrame=time)
    downarrow.newendkey(20).set(
        head=np.append(downarrow.last().head[:2], 0),
        headSize=22
        )

    mation.endDelayUntil(seconds(3,19)*30)
    print("Remove arrow spanner label:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    mo.actions.fadeOut([flabel, uparrow, downarrow], duration=20)

    # mation.endDelay(10)

    wspanner = uparrow.first().copy()
    wspanner.head = wspanner.tail = middle = flabel.last().pos
    wspanner = mo.Actor(wspanner)
    layerz.append(wspanner)
    wspanner.newendkey(20).set(
        tail=middle[0]*ihat+middle[0]*jhat+middle[2]*khat,
        head=middle[0]*ihat+yend*jhat+middle[2]*khat,
        headSize=22, tailSize=22
        )
    qmark = mo.text.SpaceText("?",
        pos=wspanner.last().midpoint()+0.25*khat, anchor_y=-1,
        size=72, color=[0,0,0]).set(
        orientable=True, orient=mo.matrix.rotation([0,1,0], tau/4) @ mo.matrix.rotation([0,0,1], tau/4),
        zdepth=1000
        )
    qmark = mo.Actor(qmark)
    layerz.append(qmark)
    qmark.fadeIn(duration=20, jump=0.5*khat)

    mation.endDelayUntil(seconds(3,24.75)*30)
    print("Highlight far-end slice:", mation.seconds())

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(30).orient = oblique

    mation.endDelay(10)

    time = mation.lastID()

    mo.actions.fadeOut([qmark, wspanner], atFrame=time, duration=20)

    time = mation.lastID()
    hslicer0.newkey(time).set(fill=[0,0.8,0], yAlpha=0) #, zdepth=1001)
    hslicer0.fadeIn(duration=20)

    mainVslice.newkey(time)
    mainVslice.newendkey(20).alpha /= 2

    mation.endDelayUntil(seconds(3,28)*30)
    print("Show 'y = t' label:", mation.seconds())

    ytext, eqtext = hslicer0.key[-4].makeFrame().figures[-2:]
    ytext.text = "y = t"
    ytext.zdepth = 1000
    ytext.set(anchor_y=-1, background=[1,1,1], backAlpha=1, backPad=0.1).size *= 1.5
    ytext.pos += ytext.backPad*(ihat+khat)
    ytext = mo.Actor(ytext)
    layerz.append(ytext)
    ytext.fadeIn(duration=20, jump=1*ihat)

    time = mation.lastID()
    dint.newkey(time).set(
        pos=(7.07-3.37j), align=[-1,0],
        background=[1,1,1], backAlpha=0.5
        )
    dint.fadeIn(duration=20)

    time = mation.lastID()
    tcirc1 = mo.grid.ellipse(8.28-2.24j, 0.5).edge().set(
        width=4, color=[1,0,0], end=0
        )
    tcirc1 = mo.Actor(tcirc1)
    toplayer.merge(tcirc1, atFrame=time)
    tcirc1.newendkey(20).end = 1

    tcirc2 = mo.grid.ellipse((14.52-1.05j), 0.65).edge().set(
        width=4, color=[1,0,0], end=0
        )
    tcirc2 = mo.Actor(tcirc2)
    toplayer.merge(tcirc2, atFrame=time)
    tcirc2.newendkey(20).end = 1

    mation.endDelayUntil(seconds(3,34.25)*30)
    print("Fade encirclings and scoot 'y=t' tag:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut([tcirc1, tcirc2], atFrame=time, duration=20)

    time = mation.lastID()
    ytext.newkey(time)
    ytext.newendkey(20).pos = ytext.last().pos*[0,1,1] + flabel.last().pos*[1,0,0]
    ytext.last().pos += ytext.last().backPad*(ihat+khat)
    ytext.last().backAlpha = 0.5

    mation.endDelay(30)

    time = mation.lastID()
    mo.actions.fadeOut([hslicer0, dint], atFrame=time, duration=30)

    mainVslice.newkey(time)
    mainVslice.newendkey(30, mainVslice.key[-3].copy())

    mation.endDelayUntil(seconds(3,38)*30)
    print("Highlight near-end of rectangle:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    near = mo.grid.SpacePath([[xmain, xmain, 0], [xmain, xmain, f(xmain)]]).set(
        width=rect.width+2, color=[1,0,0], end=0,
        outlineWidth=2, outlineColor=[1,1,1],
        zdepth=1000
        )
    near = mo.Actor(near)
    layerz.merge(near, atFrame=time)
    # near.fadeIn(duration=20)
    near.newendkey(20).end = 1

    mation.endDelayUntil(seconds(3,43.5)*30)
    print("Revolve to xz-plane and show integration slice:", mation.seconds())

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(45, mainlayer.camera.first().copy())

    mo.actions.fadeOut([top, southWall, ytext, ylabel], atFrame=time, duration=45)

    fcurve3d.newkey(time)
    fcurve3d.last().set(origin=[0,0,0])
    fcurve3d.fadeIn(duration=45)

    mation.endDelay(10)

    time = mation.lastID() + 1
    hslicer0.newkey(time).set(
        end=0, alpha=1,
        fill=hslicer0.first().fill[:],
        yAlpha=0, visible=True
        )
    hslicer0.newendkey(60).end = 5
    hslicer0.last().yAlpha = 1
    mation.endDelay(10)
    hslicer0.newendkey(45).end = 2

    mation.endDelayUntil(seconds(3,51)*30)
    print("Back to 3/4 view and highlight y-position:", mation.seconds())

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(45, mainlayer.camera.key[-3].copy())

    fcurve3d.newkey(time)
    fcurve3d.fadeOut(duration=30)

    ylabel.newkey(time)
    ylabel.fadeIn(duration=45)

    mation.endDelay(10)

    # Draw arrow spanner
    time = mation.lastID()
    yspanner = mo.grid.SpaceArrow()
    yspanner.head = yspanner.tail = [xmain/2, xmain/2, 0]
    yspanner.set(
        width=4, color=violet, headSize=0,
        outlineWidth=1.5, outlineColor=[0,0,0],
        zdepth=1000
        )
    yspanner = mo.Actor(yspanner)
    layerz.merge(yspanner, atFrame=time)
    yspanner.newendkey(20).set(
        head=[xmain/2, xmain, 0],
        tail=[xmain/2, 0, 0],
        headSize=22, tailSize=22
        )

    yspantext = ytext.last().copy()
    yspantext.text = "y"
    yspantext.set(anchor_y=0, size=64)
    yspantext.pos = yspanner.last().midpoint() + 0.15*ihat
    yspantext = mo.Actor(yspantext)
    layerz.append(yspantext)
    yspantext.fadeIn(duration=20, jump=0.5*ihat)

    mation.endDelayUntil(seconds(4,0)*30)
    print("Show x spanner:", mation.seconds())

    time = mation.lastID()
    xspanner = mo.grid.SpaceArrow()
    xspanner.head = xspanner.tail = [xmain/2, xmain, 0.25]
    xspanner.set(
        width=4, color=[0,0.6,0], headSize=0,
        outlineWidth=1.5, outlineColor=[1,1,1],
        zdepth=1000
        )
    xspanner = mo.Actor(xspanner)
    layerz.append(xspanner)
    xspanner.newendkey(20).set(
        head=[0, xmain, 0.25], tail=[xmain, xmain, 0.25],
        tipSize=22
        )

    xspantext = yspantext.last().copy()
    xspantext.pos = xspanner.last().midpoint() + xspantext.backPad*khat
    xspantext.anchor_y = -1
    xspantext = mo.Actor(xspantext)
    layerz.append(xspantext)
    xspantext.fadeIn(duration=20, jump=0.5*khat)

    mation.endDelayUntil(seconds(4,10.35)*30)
    print("Fade arrow spanners highlight point:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut([xspantext, xspanner, yspantext, yspanner], atFrame=time, duration=20)

    hslicer0.newkey(time)
    hslicer0.newendkey(20).yAlpha = 0

    time = mation.lastID()
    pt2 = mo.grid.SpacePoint([xmain, xmain, 0]).set(
        strokeWeight=2, color=[0,0,0], fill=[1,1,0],
        zdepth=1000
        )
    pt2 = mo.Actor(pt2)
    layerz.append(pt2)
    pt2.fadeIn(duration=15)

    xy = mo.graphics.SpaceMultiImage("./resources/y-eq-x.png").set(
        pos=pt2.last().pos, height=0.3, alpha=0,
        background=[1,1,1], backAlpha=0.35, backPad=0.1,
        zdepth=1000
        )
    xy = mo.Actor(xy)
    layerz.append(xy)
    xy.newendkey(20).set(alpha=1, align=[-1,0]).pos += 0.5*(ihat-jhat)

    mation.endDelayUntil(seconds(4,18.5)*30)
    print("Show solid and revolve camera:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeIn([top, southWall], atFrame=time, duration=20, alpha=top.key[-2].alpha)

    mation.endDelay(20)

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(45).orient = np.eye(3)
    mainlayer.camera.last().moveBy(1.5+1.5j)

    zlabel.newkey(time)
    zlabel.fadeOut(duration=30)

    mation.endDelay(10)

    # Highlight y = x line
    time = mation.lastID()
    yxline = mo.grid.SpacePath([-2-2j, 8+8j]).set(
        width=5, color=[1,1,0], end=0,
        outlineWidth=1.5, outlineColor=[0,0,0],
        zdepth=1000
        )
    yxline = mo.Actor(yxline)
    layerz.merge(yxline, atFrame=time, beforeActor=pt2)
    yxline.newendkey(30).end = 1

    mation.endDelayUntil(seconds(4,25.5)*30)
    print("Revolve camera:", mation.seconds())

    time = mation.lastID()
    xy.newkey(time).orientable = True
    xy.newendkey(45).set(
        orient=ytext.last().orient, pos=pt2.last().pos+xy.last().backPad*(ihat+khat),
        align=[-1,-1], backAlpha=ytext.last().backAlpha
        )
    xy.last().height *= 1.25

    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(45, mainlayer.camera.key[-3].copy()).orient = oblique

    zlabel.newkey(time)
    zlabel.fadeIn(duration=30)

    mo.actions.fadeOut([yxline, hslicer0], atFrame=time, duration=30)

    mation.endDelayUntil(seconds(4,38.25)*30)
    print("Show 'y = t' label again:", mation.seconds())

    time = mation.lastID()
    ytext2 = mo.graphics.SpaceMultiImage("./resources/y-is-t.png").set(
        pos=ytext.last().pos, height=1.15*xy.last().height,
        align=[ytext.last().anchor_x, ytext.last().anchor_y],
        background=ytext.last().background[:],
        backAlpha=ytext.last().backAlpha,
        backPad=ytext.last().backPad,
        orientable=True, orient=ytext.last().orient,
        zdepth=1000
        )
    ytext2 = mo.Actor(ytext2)
    layerz.merge(ytext2, atFrame=time, beforeActor=ytext)
    ytext2.fadeIn(duration=20)

    near.newkey(time)
    near.fadeOut(duration=20)
    pt2.newkey(time)
    pt2.fadeOut(duration=20)

    mation.endDelayUntil(seconds(4,42.3)*30)
    print("Show width is (t-x):", mation.seconds())

    time = mation.lastID()
    obliqueMid = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -45*deg)
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(30).orient = obliqueMid

    mation.endDelay(10)

    time = mation.lastID()
    wspanner.newkey(time, wspanner.first().copy())
    wspanner.newendkey(20, wspanner.key[1].copy())

    time = mation.lastID()
    tminusx = mo.graphics.SpaceMultiImage("./resources/(t-x).png").set(
        pos=wspanner.last().midpoint()+ytext2.last().backPad*khat, align=[0,-1],
        height=1.15*ytext2.last().height,
        background=ytext2.last().background[:],
        backAlpha=ytext2.last().backAlpha,
        backPad=ytext2.last().backPad,
        orientable=True, orient=qmark.last().orient,
        zdepth=1000
        )
    tminusx = mo.Actor(tminusx)
    layerz.merge(tminusx, atFrame=time)
    tminusx.fadeIn(duration=20, jump=0.5*khat)

    mation.endDelayUntil(seconds(4,47.5)*30)
    print("Scoot up and display height spanner:", mation.seconds())

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(30).orient = oblique2

    time = mation.lastID()
    wspanner.newkey(time)
    wspanner.newendkey(20).origin = (0.5+f(xmain)/2)*khat
    wspanner.last().set(outlineWidth=1, outlineColor=[1,1,1])

    tminusx.newkey(time)
    tminusx.newendkey(20).pos += wspanner.last().origin

    time = mation.lastID()
    flabel.newkey(time)
    flabel.fadeIn(duration=20)

    time = mation.lastID()
    for arrow in [uparrow, downarrow]:
        arrow.newkey(time, arrow.first().copy())
        arrow.newendkey(20, arrow.key[1].copy())

    mation.endDelayUntil(seconds(4,50.5)*30)
    print("Scoot left and display area:", mation.seconds())

    time = mation.lastID()
    dy = (yend - xmain)/2
    for arrow in [uparrow, downarrow]:
        arrow.newkey(time)
        arrow.newendkey(20).origin = -(dy+0.65)*jhat
        arrow.last().set(
            outlineWidth=1, outlineColor=[1,1,1]
            )

    flabel.newkey(time)
    flabel.newendkey(20).pos += uparrow.last().origin
    flabel.last().set(
        background=[1,1,1], backAlpha=0.5, backPad=0.1
        )

    mation.endDelay(15)

    time = mation.lastID()
    arealabel = mo.graphics.SpaceMultiImage("./resources/(t-x)f(x).png").set(
        pos=flabel.key[-2].pos, height=0.55,
        orientable=True, orient=flabel.last().orient,
        zdepth=1000
        )
    arealabel = mo.Actor(arealabel)
    layerz.merge(arealabel, atFrame=time)
    arealabel.fadeIn(duration=20)

    mainVslice.newkey(time)
    mainVslice.newendkey(20).set(
        alphaFill=1, fill=[1,1,0.25]
        )

    mation.endDelayUntil(seconds(5,1.75)*30)
    print("Show Cauchy formula:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    cauchy = mo.graphics.MultiImage("./resources/cauchy0.png").set(
        pos=2-7.46j, height=2.25,
        background=[1,1,1], backAlpha=1, backPad=0.5
        )
    cauchy = mo.Actor(cauchy)
    toplayer.merge(cauchy, atFrame=time)
    cauchy.fadeIn(duration=20, jump=2j)

    finalbox = mo.gadgets.enbox(cauchy.last().box(pad=cauchy.last().backPad),
        width=5, color=[0,0,1], duration=30
        )
    toplayer.append(finalbox)

    # mation.start = mation.end = mation.lastID()

    mation.endDelay(30)
    print("Start scooting vslice:", mation.seconds())

    # Make vslice semi-transparent again
    time = mation.lastID()
    # mation.start = time
    mainVslice.newkey(time)
    mainVslice.newendkey(30).alphaFill = mainVslice.key[-4].alphaFill

    # Fade out spanners and labels to reduce clutter
    mo.actions.fadeOut(
        [flabel, uparrow, downarrow, tminusx, wspanner, ytext2, xy],
        atFrame=time, duration=30
        )

    # Revolve camera to mid oblique view
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(30).orient = obliqueMid
    # mainlayer.camera.newendkey(30).orient = orientYZ

    # Also scoot the formula up a bit
    cauchy.newkey(time)
    cauchy.newendkey(30).pos += 1.5j
    finalbox.newkey(time)
    finalbox.newendkey(30).origin += 1.5j

    mation.endDelay(10)

    arealabelBase = arealabel.last().copy()
    arealabelBase.unlink()
    @mo.SkitParameters(alpha=1)
    class AreaLabel(mo.Skit):
        def makeFrame(self, index=None):
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            vslice = mainVslice.time(index)
            rect = vslice.makeFrame().figures[0]
            alabel = arealabelBase.copy()
            alabel.pos = mean(rect.vertices)
            alabel.width = constrain(0.9*(yend-vslice.x), 0, alabel.width)
            # alabel.width = min(alabel.width, max(0, yend-vslice.x-0.25))
            alabel.alpha = alpha

            return alabel

    time = mation.lastID()
    # mation.start = time
    arealabel.newkey(time).visible = False
    alabel = AreaLabel().set(zdepth=1000)
    alabel = mo.Actor(alabel)
    layerz.merge(alabel, atFrame=time)

    mainVslice.newkey(time)
    mainVslice.newendkey(45).x = 0
    mainVslice.newendkey(75).x = yend
    mainVslice.newendkey(60).x = 2

    mation.endDelayUntil(seconds(5,24.5)*30)
    print("Slide back and forth some more:", mation.seconds())

    mainVslice.newendkey(75).x = yend-1
    mainVslice.newendkey(75).x = 2





    # Synchronize other space cameras with mainlayer.camera
    for layer in mation.layers:
        if issubclass(layer.camera.figureType, mo.anim.SpaceCamera) and layer is not mainlayer:
            layer.camera = mainlayer.camera.copy()

    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = toplayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./07_slicing-the-solid.mp4", scale=1)


main()
