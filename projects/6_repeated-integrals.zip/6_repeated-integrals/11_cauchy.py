
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "11_cauchy"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    prooflayer = mainlayer.copy()
    mation = morpho.Animation([prooflayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    masklayer = prooflayer.copy()
    masklayer.camera.first().visible = False
    prooflayer.mask = masklayer

    curtain = mo.grid.rect([-18,18,-11,2.5]).set(width=0)
    curtain = mo.Actor(curtain)
    masklayer.merge(curtain)

    # title = morpho.text.Text("Compressing a 2-Fold Integral",
    #     pos=8j,
    #     size=84, anchor_x=0, anchor_y=0,
    #     color=(0,0,0)
    #     )
    # title = morpho.Actor(title)
    # toplayer.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    mation.endDelay(15)

    time = mation.lastID()
    cauchy2 = mo.graphics.MultiImage("./resources/cauchy0.png").set(
        pos=6j, height=2.25
        )
    cauchy2 = mo.Actor(cauchy2)
    mainlayer.merge(cauchy2, atFrame=time)

    mation.endDelayUntil(6*30)
    print("Show n-fold expression:", mation.seconds())

    nfold = mo.graphics.MultiImage("./resources/nth-antideriv.png").set(
        pos=1.5j, height=3.4
        )
    nfold = mo.Actor(nfold)
    mainlayer.append(nfold)
    nfold.fadeIn(duration=20, jump=2j)

    mation.endDelayUntil(11.5*30)
    print("Fade out double-Cauchy:", mation.seconds())

    time = mation.lastID()
    cauchy2.newkey(time)
    cauchy2.fadeOut(duration=20)

    # nfold.newkey(time)
    # nfold.newendkey(30).set(pos=6j)

    mation.endDelayUntil(13.75*30)
    print("Rewrite as nested definite integrals:", mation.seconds())

    time = mation.lastID()
    nfold.newkey(time)
    nfold.newendkey(20).newSource("./resources/n-fold-integ-long.png").scaleByHeight()
    nfold.last().height = cauchy2.last().height

    mation.endDelayUntil(31.5*30)
    print("Abbreviate:", mation.seconds())

    nfold.newendkey(20).newSource("./resources/n-fold-integ-compressed.png").scaleByHeight()

    mation.endDelayUntil(38.25*30)
    print("Show full Cauchy formula:", mation.seconds())

    # Scoot expression
    time = mation.lastID()
    nfold.newkey(time)
    nfold.newendkey(20).set(align=[1,0]).pos -= 4

    time = mation.lastID()
    eq = mo.graphics.MultiImage("./resources/eq.png").set(
        pos=nfold.last().pos, align=[-1,0], height=1
        )
    eq = mo.Actor(eq)
    mainlayer.merge(eq, atFrame=time)
    eq.fadeIn(duration=20, jump=1.5)

    cauchy = mo.graphics.MultiImage("./resources/cauchy-n.png").set(
        pos=eq.last().pos+eq.last().width, align=[-1,0],
        height=nfold.last().height
        )
    cauchy = mo.Actor(cauchy)
    mainlayer.append(cauchy)
    cauchy.fadeIn(20, jump=3)

    mation.endDelayUntil(44.25*30)
    print("Show old 2-fold Cauchy formula:", mation.seconds())

    time = mation.lastID()
    cauchy2.newkey(time)
    cauchy2.fadeIn(20)

    mation.endDelayUntil(47*30)
    print("Enbox exponent:", mation.seconds())

    expboxer = mo.gadgets.enbox([4.74,6.15, 1.52,2.17],
        width=4, color=[1,0,0]
        )
    mainlayer.append(expboxer)

    mation.endDelayUntil(50.75*30)
    print("Enbox factorial division:", mation.seconds())

    facboxer = mo.gadgets.enbox([-2.7,0.81, 0.15,2.7],
        width=4, color=[1,0,0]
        )
    mainlayer.append(facboxer)

    mation.endDelayUntil(55.5*30)
    print("Fade:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([facboxer, expboxer, cauchy2], duration=20, atFrame=time)

    mation.endDelayUntil(57.5*30)
    print("Label the Cauchy Formula:", mation.seconds())

    cauchylabel = mo.text.Text("Cauchy's Formula for Repeated Integration",
        pos=cauchy.last().pos.imag*1j + 3j,
        size=64, color=[0,0,0.8]
        )
    cauchylabel = mo.Actor(cauchylabel)
    mainlayer.append(cauchylabel)
    cauchylabel.fadeIn(duration=20, jump=2j)

    mation.endDelayUntil(61*30)
    print("Not to be confused with...:", mation.seconds())

    cif = mo.text.Text("Cauchy's Integral Formula",
        pos=cauchylabel.last().pos+2j,
        size=56, color=[0,0,0]
        )
    cif = mo.Actor(cif)
    mainlayer.append(cif)
    cif.fadeIn(duration=20, jump=2j)

    mation.endDelayUntil(63.5*30)
    print("Crossout:", mation.seconds())

    crossout = mo.gadgets.crossout(
        cif.last().box(mainlayer.camera.last().view, mation.windowShape, pad=0.15),
        width=4, color=[1,0,0]
        )
    mainlayer.append(crossout)

    mation.endDelayUntil(67.25*30)
    print("Fade and scoot:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([crossout, cif], atFrame=time, duration=20)

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(30).moveBy(-4j)

    mation.endDelayUntil(74*30)
    print("Integration by Parts:", mation.seconds())

    voodoo = mo.text.Text("Recursively apply integration by parts",
        pos=cauchy.last().pos+cauchy.last().width-2j, anchor_x=1, italic=True,
        size=48, color=violet
        )
    voodoo = mo.Actor(voodoo)
    mainlayer.append(voodoo)
    voodoo.fadeIn(20, jump=-2j)

    mation.endDelayUntil(83*30)
    print("Show proof:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    # Enable mask for prooflayer
    masklayer.camera.newkey(time).visible = True

    proof1 = mo.graphics.MultiImage("./resources/proof1.png").set(
        pos=2.25j, align=[1,1], height=5
        )
    proof1 = mo.Actor(proof1)
    prooflayer.merge(proof1, atFrame=time)
    proof1.fadeIn(20, jump=3j)

    mation.endDelay(10)

    proof2 = mo.graphics.MultiImage("./resources/proof2.png").set(
        pos=proof1.last().pos+3-1j*proof1.last().height/2,
        align=[-1,1], height=2.75
        )
    proof2 = mo.Actor(proof2)
    prooflayer.append(proof2)
    proof2.fadeIn(20, jump=3)

    boxer2 = mo.gadgets.enbox(proof2.last().box(pad=0.5),
        width=4, color=violet
        )
    prooflayer.append(boxer2, beforeActor=proof2)
    boxer2.last().fill = [1,1,1]
    boxer2.newendkey(15).alphaFill = 1

    # mation.endDelay(10)

    proof3 = mo.graphics.MultiImage("./resources/proof3.png").set(
        pos=proof1.last().center-5-1j*proof1.last().height*0.85,
        align=[-1,1], height=10
        )
    proof3 = mo.Actor(proof3)
    prooflayer.append(proof3)
    proof3.fadeIn(20, jump=3j)

    mation.endDelay(30)
    print("Start scrolling the proof:", mation.seconds())

    time = mation.lastID()
    prooflayer.camera.newkey(time)
    prooflayer.camera.newendkey(60).moveBy(-7j)

    mation.endDelay(10)

    finalboxer = mo.gadgets.enbox([-8,2, -14.8,-11.96],
        width=4, color=[0,0,1]
        )
    prooflayer.append(finalboxer, beforeActor=proof3)
    finalboxer.last().fill = [1,1,1]
    finalboxer.newendkey(15).alphaFill = 1





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = prooflayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./11_cauchy.mp4", scale=1)


main()
