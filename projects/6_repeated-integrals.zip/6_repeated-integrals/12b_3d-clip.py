
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "12b_3d-clip"



def main():
    # mation = mo.video.setupSpace()
    # mainlayer = mation.layers[0]
    # del mainlayer.camera.key[-1]
    # mainlayer.camera.first().orient = mo.matrix.rotation([1,0,0], -tau/4)
    # mation.background = lightviolet

    mainlayer = morpho.SpaceLayer(view=mo.video.view169())
    layer2 = mainlayer.copy()
    layerz = mainlayer.copy()
    layerz.poolPrimitives = False
    lowlayer = mainlayer.copy()
    mation = morpho.Animation([lowlayer, mainlayer, layer2, layerz])
    mation.windowShape = (1920, 1080)
    aspectRatio = mation.windowShape[0] / mation.windowShape[1]
    mation.fullscreen = True
    mation.background = lightviolet

    mainlayer.camera.first().view[:2] = [-2.5, 9.5]
    mainlayer.camera.first().rescaleHeight(aspectRatio).moveBy(1.5j)
    xmin,xmax,ymin,ymax = mainlayer.camera.first().view

    orient = mo.matrix.rotation([1,0,0], tau/4)
    orientXZ = orient.T
    mainlayer.camera.first().orient = orientXZ

    flatlayer = mo.Layer(view=mainlayer.camera.first().view[:])
    mation.merge(flatlayer, beforeLayer=0)
    toplayer = mo.Layer(view=mo.video.view169())
    mation.merge(toplayer)

    dint = mo.graphics.Image("./resources/double-definite-integral.png").set(
        pos=1j, height=2.75
        )
    dint = mo.Actor(dint)
    toplayer.merge(dint)

    mation.endDelayUntil()
    print("Fade to only inner integral:", mation.seconds())

    time = mation.lastID() + 1
    sint = mo.graphics.MultiImage("./resources/single-definite-integral-padded.png")
    sint.set(pos=dint.last().pos, height=dint.last().height)
    sint = mo.Actor(sint)
    toplayer.merge(sint, atFrame=time)

    dint.newkey(time)
    dint.fadeOut(duration=20)

    mation.endDelayUntil()
    print("Encircle 'a':", mation.seconds())

    circ = mo.grid.ellipse((-1.74-0.17j), 0.45).edge().set(
        width=4, color=[1,0,0], end=0
        )
    circ = mo.Actor(circ)
    toplayer.append(circ)
    circ.newendkey(20).end = 1

    mation.endDelayUntil()
    print("Morph 'a' to '0':", mation.seconds())

    time = mation.lastID()
    sint.newkey(time)
    sint.newendkey(20).newSource("./resources/single-integral0-padded.png").scaleByHeight()

    mation.endDelay(30)

    time = mation.lastID()
    circ.newkey(time)
    circ.fadeOut(duration=20)

    mation.endDelayUntil()
    print("Encircle 'y':", mation.seconds())

    circy = mo.grid.ellipse((-1.22+1.98j), 0.45).edge().set(
        width=4, color=[0,0,1], end=0
        )
    circy = mo.Actor(circy)
    toplayer.append(circy)
    circy.newendkey(20).end = 1

    mation.endDelayUntil()
    print("Draw graph:", mation.seconds())

    # Scoot formula
    time = mation.lastID()
    sint.newkey(time)
    sint.newendkey(30).pos += 6j
    circy.newkey(time)
    circy.newendkey(30).origin += 6j


    xmin,xmax,ymin,ymax = mainlayer.camera.first().view
    axes = mo.grid.SpacePath(
        [math.floor(xmin), math.ceil(xmax), 1j*math.floor(ymin), 1j*math.ceil(ymax)]
        ).set(
        width=8, color=[0,0,0], deadends={1}, zdepth=10
        ).fimage(lambda v: orient @ v)
    axes.end = 0
    axes = mo.Actor(axes)
    layerz.merge(axes, atFrame=time)
    axes.newendkey(30).end = 1

    time = mation.lastID()
    f = lambda x: (2*x**3-21*x**2+60*x+3)/20 + 0.5
    F = lambda x: (x**4-14*x**3+60*x**2+6*x)/40 + 0.5*x - 1.5
    fcurve = mo.graph.realgraph(f, 0, 7, steps=150).set(
        width=6, color=[0.8,0,0], end=0
        )
    fcurve = mo.Actor(fcurve)
    flatlayer.merge(fcurve, atFrame=time)
    fcurve.newendkey(40).end = 1

    stdFill = mo.color.parseHexColor("e64d70")
    stdColor = tuple((0.65*mo.array(stdFill)).tolist())
    endFill = mo.color.parseHexColor("4d50e6")
    endColor = tuple((0.65*mo.array(endFill)).tolist())
    fillgrad = mo.color.Gradient({0:stdFill, 1:endFill})
    area = mo.calculus.IntegralArea(
        func=f, start=0, end=0, strokeWeight=5,
        color=stdColor, fill=stdFill, alphaFill=1, steps=150
        ).set(zdepth=-1)
    area = mo.Actor(area)
    flatlayer.append(area)
    area.newendkey(30).end = 6

    time = mation.lastID()
    da = -0.2-0.1j
    alabel = mo.text.MultiText("0",
        pos=area.last().start+da,
        size=64, color=[0.8,0,0], alpha=0
        )
    alabel.set(
        background=[1,1,1],
        backAlpha=0.5, backPad=0.02, zdepth=-2
        )
    alabel.backAlpha = 0
    alabel = mo.Actor(alabel)
    flatlayer.merge(alabel, atFrame=time)
    alabel.newendkey(20).set(anchor_y=1, alpha=1)

    blabel = alabel.first().copy()
    db = -0.05j
    blabel.set(
        text="y", pos=area.last().end+db, color=[0,0,0.8], italic=True
        ).backPad += 0.025
    blabel = mo.Actor(blabel)
    flatlayer.merge(blabel, atFrame=time+10)
    blabel.newendkey(20).set(anchor_x=-1, anchor_y=1, alpha=1)

    blabelbase = blabel.last().copy()

    @mo.SkitParameters(alpha=1)
    class BTracker(mo.Skit):
        def makeFrame(self, index=None):
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            b = area.time(index).end
            num = mo.text.Number(b, decimal=2, rightDigits=2)
            ylabel = blabelbase.copy().figures[0]
            ylabel.text = "y"
            eqlabel = blabelbase.copy().figures[0]
            eqlabel.set(text=" = "+str(num), italic=False)

            blabel = mo.text.group(
                [ylabel, eqlabel], flatlayer.camera.time(index).view,
                mation.windowShape,
                pos=b+db, anchor_x=-1, anchor_y=1, alpha=alpha
                )
            # blabel.pos = b + db
            # blabel.alpha = alpha

            return blabel


    mation.endDelayUntil()
    print("Start varying the rightbound:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    btrack = BTracker()
    btrack = mo.Actor(btrack)
    flatlayer.merge(btrack, atFrame=time+20)

    blabel.newkey(time)
    blabel.newendkey(20, btrack.last().makeFrame(mation.lastID())).visible = False

    mation.endDelay(15)

    time = mation.lastID()
    area.newkey(time)
    area.newendkey(50).end /= 2.02
    area.newendkey(60).end = 7
    area.newendkey(30).end = area.key[1].end

    mation.endDelayUntil()
    print("'NOT the y-axis':", mation.seconds())

    time = mation.lastID()
    noty = mo.text.group(
        [mo.text.Text("NOT the ", size=56, color=[0,0,0]),
        mo.text.Text("y", size=56, color=[0,0,0.8], italic=True),
        mo.text.Text("-axis!", size=56, color=[0,0,0])],
        toplayer.camera.last().view, mation.windowShape,
        pos=(-9.81+8.83j), anchor_x=0, alpha=0
        )
    noty = mo.Actor(noty)
    toplayer.merge(noty, atFrame=time)
    noty.newendkey(20, mo.text.group(
        [mo.text.Text("NOT the  ", size=56, color=[0,0,0]),
        mo.text.Text("y ", size=56, color=[0,0,0.8], italic=True),
        mo.text.Text("-axis!", size=56, color=[0,0,0])],
        toplayer.camera.last().view, mation.windowShape,
        pos=(-9.81+8.83j), anchor_x=-1, alpha=1
        ))

    mation.endDelayUntil()
    print("Wiggle the y-parameter some:", mation.seconds())

    time = mation.lastID()
    area.newkey(time)
    area.newendkey(15).end += 0.5
    area.newendkey(20).end -= 1
    area.newendkey(20).end += 1
    area.newendkey(20).end -= 1
    area.newendkey(15).end += 0.5

    mation.endDelayUntil()
    print("Draw out several separate integral areas:", mation.seconds())

    time = mation.lastID()
    noty.newkey(time)
    noty.rollback(duration=20)

    circy.newkey(time)
    circy.fadeOut(duration=20)

    # Create 3D version of integral area as a skit
    @mo.SkitParameters(
        start=0, end=1, alpha=1, yAlpha=1, color=[0,0,0],
        fill=stdFill, alphaFill=1, textsize=64,
        manualColor=0
        )
    class HSlicer(mo.SpaceSkit):
        def makeFrame(self, index=None):
            start = self.start
            end = self.end
            alpha = self.alpha
            yAlpha = self.yAlpha
            color = self.color
            fill = self.fill
            alphaFill = self.alphaFill
            textsize = self.textsize
            manualColor = bool(self.manualColor)
            if index is None:
                index = mation.currentIndex

            figs = []

            if not manualColor:
                color = tuple((0.65*mo.array(fill)).tolist())
            area = mo.calculus.IntegralArea(
                func=f, start=start, end=end, strokeWeight=5,
                color=color, alpha=alpha, fill=fill, alphaFill=alphaFill,
                steps=150
                )
            poly = mo.grid.SpacePolygon(area.polygon)
            poly = poly.fimage(lambda v: orient @ v + [0,end,0])
            figs.append(poly)

            if yAlpha > 0:
                # num = mo.text.Number(end, decimal=2, rightDigits=2)
                # blabel = blabelbase.copy()
                # blabel.text = "y = " + str(num)
                # blabel.pos = b + db
                # blabel.alpha = alpha*yAlpha
                # figs.append(blabel)

                num = mo.text.Number(end, decimal=2, rightDigits=2)
                ylabel = mo.text.SpaceText("y",
                    pos=mo.array([end+db.real,end,0+db.imag]),
                    anchor_x=-1, anchor_y=1, italic=True,
                    size=textsize, color=[0,0,0.8], alpha=alpha*yAlpha
                    )
                ylabel.set(orientable=True, orient=orient)

                eqlabel = ylabel.copy()
                eqlabel.set(text=" = "+str(num), italic=False)
                eqlabel.pos += [ylabel.width(mainlayer.viewtime(index), mation.windowShape), 0, 0]

                figs.extend([ylabel, eqlabel])

            return mo.SpaceFrame(figs)

    time = mation.lastID()
    hslicer0 = HSlicer(end=area.last().end)
    hslicer0 = mo.Actor(hslicer0)
    layerz.merge(hslicer0, atFrame=time)

    fcurve3d = mo.grid.SpacePath(fcurve.last().copy())
    fcurve3d = fcurve3d.fimage(lambda v: orient @ v)
    fcurve3d = mo.Actor(fcurve3d)
    layerz.merge(fcurve3d, atFrame=time)

    alabel3d = mo.text.SpaceMultiText("0",
        pos=orient@mo.array(alabel.last().pos),
        anchor_y=1,
        size=64, color=[0.8,0,0], alpha=1
        )
    alabel3d.set(
        background=[1,1,1],
        backAlpha=0.5, backPad=0.02, zdepth=-2,
        orientable=True, orient=orient
        )
    alabel3d.backAlpha = 0
    alabel3d = mo.Actor(alabel3d)
    lowlayer.merge(alabel3d, atFrame=time)

    area.newkey(time).visible = False
    btrack.newkey(time).visible = False
    fcurve.newkey(time).visible = False
    alabel.newkey(time).visible = False

    mation.endDelayUntil()
    print("Show multiple areas:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    heatmap = mo.color.heatmap()
    yend = 6.5
    hslicer0.newendkey(30).end = yend/4
    hslicer0.last().textsize = 48

    mation.endDelay(20)

    time = mation.lastID()
    hslicer1 = hslicer0.last().copy()
    hslicer1 = mo.Actor(hslicer1)
    mainlayer.merge(hslicer1, atFrame=time+1)
    hslicer1.newendkey(20).set(fill=fillgrad.value(1/3)).end=0.5*yend

    mation.endDelay(20)

    hslicer2 = hslicer1.last().copy()
    hslicer2 = mo.Actor(hslicer2)
    mainlayer.append(hslicer2, timeOffset=1)
    hslicer2.newendkey(20).set(fill=fillgrad.value(2/3)).end = 0.75*yend

    mation.endDelay(20)

    hslicer3 = hslicer2.last().copy()
    hslicer3 = mo.Actor(hslicer3)
    mainlayer.append(hslicer3, timeOffset=1)
    hslicer3.newendkey(20).set(fill=fillgrad.value(3/3)).end = 1*yend

    mation.endDelayUntil()
    print("Rotate camera to 3/4 view:", mation.seconds())

    time = mation.lastID()
    oblique = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -30*deg)
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(60).set(orient=oblique).zoomOut(1.35)

    # Fade away integral expression
    sint.newkey(time)
    sint.fadeOut(duration=20)

    fcurve3d.last().origin = [0,hslicer0.last().end,0]

    # Insert additional curves
    fcurve3d_1 = fcurve3d.last().copy()
    fcurve3d_1.origin = [0,hslicer1.last().end,0]
    # fcurve3d_1.commitTransforms()
    fcurve3d_1.color = tuple((0.65*mo.array(hslicer1.last().fill)).tolist())
    fcurve3d_1 = mo.Actor(fcurve3d_1)
    mainlayer.merge(fcurve3d_1, atFrame=time)

    fcurve3d_2 = fcurve3d.last().copy()
    fcurve3d_2.origin = [0,hslicer2.last().end,0]
    # fcurve3d_2.commitTransforms()
    fcurve3d_2.color = tuple((0.65*mo.array(hslicer2.last().fill)).tolist())
    fcurve3d_2 = mo.Actor(fcurve3d_2)
    mainlayer.merge(fcurve3d_2, atFrame=time)

    fcurve3d_3 = fcurve3d.last().copy()
    fcurve3d_3.origin = [0,hslicer3.last().end,0]
    # fcurve3d_3.commitTransforms()
    fcurve3d_3.color = tuple((0.65*mo.array(hslicer2.last().fill)).tolist())
    fcurve3d_3 = mo.Actor(fcurve3d_3)
    mainlayer.merge(fcurve3d_3, atFrame=time)

    # Create y-axis
    yAxis = axes.last().copy()
    yAxis.deadends = set()
    yAxis.seq = [[0,-2,0], [0,12,0]]
    yAxis = mo.Actor(yAxis)
    mainlayer.merge(yAxis, atFrame=time)

    grid = mo.grid.mathgrid3d(
        view=[axes.last().seq[0][0].tolist(), axes.last().seq[1][0].tolist(), yAxis.last().seq[0][1].tolist(), yAxis.last().seq[1][1].tolist()],
        hsteps=1, vsteps=1,
        hmidWidth=2, vmidWidth=2,
        hcolor=mo.color.parseHexColor("008000"), alpha=0.5,
        axesColor=[0,0,0],
        axes=False,
        xaxisWidth=8, yaxisWidth=8
        ) # .fimage(lambda v: orient @ v)
    grid = mo.Actor(grid)
    lowlayer.merge(grid, atFrame=time)

    # Create axis labels
    xlabel = mo.text.SpaceText("x",
        pos=axes.last().seq[1]+[0.5,0,0], italic=True,
        size=64, color=[0,0,0]
        )
    xlabel = mo.Actor(xlabel)
    layer2.merge(xlabel, atFrame=time)

    ylabel = xlabel.last().copy().set(
        text="y", pos=yAxis.last().seq[1]+[0,0.5,0], alpha=0
        )
    ylabel = mo.Actor(ylabel)
    lowlayer.merge(ylabel, atFrame=time)
    ylabel.newkey(mainlayer.camera.lastID()).alpha = 1

    zlabel = xlabel.last().copy().set(
        text="z", pos=axes.last().seq[-1]+[0,0,0.5]
        )
    zlabel = mo.Actor(zlabel)
    layer2.merge(zlabel, atFrame=time)

    mation.endDelayUntil()
    print("Slide fcurves:", mation.seconds())

    time = mation.lastID()
    stagger = 4
    for n,actor in enumerate([fcurve3d, fcurve3d_1, fcurve3d_2, fcurve3d_3]):
        actor.newkey(time+n*stagger)
        actor.newendkey(20).end = mo.lerp(0,1, (n+1)/4*yend, start=0, end=7)

    mation.endDelayUntil()
    print("Fade in solid:", mation.seconds())

    def colorfunc(v):
        x,y,z = v.tolist()
        return fillgrad.value(mo.lerp(0,1, y, start=0, end=yend))

    def solidf(v):
        x,y,z = v
        Z = f(x)
        return mo.array([x,y,Z])

    time = mation.lastID()
    # mation.start = time
    top = mo.grid.quadgrid(
        view=[0,yend,0,yend],
        dx=yend/24, dy=yend/1,
        width=1.5,
        color=[0,0,0], fill=colorfunc,
        ).set(shading=True)
    def trianglify(v):
        x,y,z = v
        Y = (yend-x)/yend*(yend-y)
        Y = yend - Y
        return mo.array([x,Y,z])

    top = top.fimage(compose(solidf, trianglify))
    top = mo.Actor(top)
    layerz.merge(top, atFrame=time)
    top.fadeIn(duration=45)

    solid = mo.calculus.DoubleIntegralVolume(
        func=solidf, mode="dydx",
        inmin=lambda x: x, inmax=yend,
        outmin=0, outmax=yend,
        width=top.first().width, color=[0,0,0],
        fill=[0,0.5,1],
        steps=24
        )
    walls = solid.makeWalls()

    southWall = walls["south"]
    southWall.fill = colorfunc
    southWall = mo.Actor(southWall)
    layerz.merge(southWall, atFrame=time)
    southWall.fadeIn(duration=45)

    # wall = mo.calculus.Wall(
    #     func=solidf, start=0, end=complex(yend,yend),
    #     steps=24
    #     )
    # layerz.merge(wall, atFrame=time)

    mo.actions.fadeOut(
        [fcurve3d, fcurve3d_1, fcurve3d_2, fcurve3d_3,
        hslicer0, hslicer1, hslicer2, hslicer3],
        duration=45, atFrame=time
        )

    # mation.endDelayUntil()
    # print("Revolve solid around a little bit:", mation.seconds())

    # time = mation.lastID()
    # mation.start = time
    # mainlayer.camera.newkey(time)
    # mainlayer.camera.newendkey(60).orient = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -75*deg)
    # mainlayer.camera.newendkey(60).orient = mo.matrix.rotation([1,0,0], -60*deg) @ mo.matrix.rotation([0,0,1], -10*deg)
    # mainlayer.camera.newendkey(30).orient = oblique

    mation.endDelayUntil()
    print("Show single integral again:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    sint.newkey(time).set(pos=(3.81-3.75j),
        background=mation.background, backAlpha=0.5, backPad=0
        )
    sint.fadeIn(duration=20, jump=3)

    boxer = mo.gadgets.enbox([1.07,6.81, -5.28,-2.28],
        duration=30, width=4, color=[0,0,1]
        )
    toplayer.append(boxer)

    mation.endDelayUntil()
    print("Show horizontal slice:", mation.seconds())

    time = mation.lastID()
    hs = HSlicer(fill=[1,1,0.25], alpha=0, manualColor=True)
    hs.zdepth = 100
    hs = mo.Actor(hs)
    layerz.merge(hs, atFrame=time)
    hs.newendkey(20).alpha = 0.7

    mation.endDelayUntil()
    print("Show double integral version:", mation.seconds())
    # print("Move horizontal slice up and down the y-axis:", mation.seconds())

    time = mation.lastID()
    boxer.newkey(time)
    boxer.fadeOut(duration=20)

    time = mation.lastID()
    sint.newkey(time)
    sint.newendkey(20).newSource("./resources/double-integral0.png").scaleByHeight()

    outboxer = mo.gadgets.enbox(sint.last().box(pad=0.15),
        duration=30, width=4, color=[1,0,0]
        )
    # toplayer.append(outboxer)




    ### ABOVE IS PRELIM ###

    time = mation.lastID()
    mation.start = time
    hs.newkey(time).end = 0
    hs.newendkey(100).end = yend
    hs.newendkey(100).end = 0





    # Synchronize other space cameras with mainlayer.camera
    for layer in mation.layers:
        if issubclass(layer.camera.figureType, mo.anim.SpaceCamera) and layer is not mainlayer:
            layer.camera = mainlayer.camera.copy()

    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = toplayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./12b_3d-clip.mp4", scale=1)


main()
