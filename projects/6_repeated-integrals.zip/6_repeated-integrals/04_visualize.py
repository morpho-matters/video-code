
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "04_visualize"



def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    toplayer = mainlayer.copy()
    mation = morpho.Animation([mainlayer, toplayer])
    mation.windowShape = (1920, 1080)
    aspectRatio = mation.windowShape[0] / mation.windowShape[1]
    mation.fullscreen = True
    mation.background = lightviolet

    mainlayer.camera.first().view[:2] = [-2.5, 9.5]
    mainlayer.camera.first().rescaleHeight(aspectRatio).moveBy(1.5j)
    xmin,xmax,ymin,ymax = mainlayer.camera.first().view

    grid = mo.grid.mathgrid(
        view=[math.floor(xmin), math.ceil(xmax), math.floor(ymin), math.ceil(ymax)],
        hsteps=1, vsteps=1,
        hmidWidth=2, vmidWidth=2,
        hcolor=mo.color.parseHexColor("008000"), alpha=0.5,
        axesColor=[0,0,0],
        axes=False,
        xaxisWidth=8, yaxisWidth=8,
        axesStatic=False
        ).set(zdepth=-10)
    grid = mo.Actor(grid)
    # mainlayer.merge(grid)

    axes = mo.grid.Path(
        [math.floor(xmin), math.ceil(xmax), 1j*math.floor(ymin), 1j*math.ceil(ymax)]
        ).set(
        width=8, color=[0,0,0], deadends={1}, zdepth=10
        )
    axes = mo.Actor(axes)
    mainlayer.merge(axes)

    mation.endDelay(20)

    f = lambda x: (2*x**3-21*x**2+60*x+3)/20 + 0.5
    F = lambda x: (x**4-14*x**3+60*x**2+6*x)/40 + 0.5*x - 1.5
    fcurve = mo.graph.realgraph(f, -1, 8, steps=150).set(
        width=6, color=[0.8,0,0], end=0
        )
    fcurve = mo.Actor(fcurve)
    mainlayer.append(fcurve)
    fcurve.newendkey(40).end = 1

    flabel = mo.graphics.MultiImage("./resources/f(x).png").set(
        pos=(7.6+3.5j), align=[1,0], height=0.35,
        background=mation.background, backPad=0.025, backAlpha=0.5
        )
    flabel = mo.Actor(flabel)
    mainlayer.append(flabel)
    flabel.fadeIn(duration=20, jump=0.5)

    mation.endDelayUntil(8.5*30)
    print("Show antiderivative curve:", mation.seconds())

    Fcurve = mo.graph.realgraph(F, -2.5, 3, steps=100).set(
        width=6, color=[0,0,1], end=0
        )
    Fcurve = mo.Actor(Fcurve)
    mainlayer.append(Fcurve)
    Fcurve.newendkey(40).end = 1

    Flabel = mo.graphics.MultiImage("./resources/single-integral.png").set(
        pos=(2.2+3.75j), align=[-1,0], height=0.7
        )
    Flabel = mo.Actor(Flabel)
    mainlayer.append(Flabel)
    Flabel.fadeIn(duration=20, jump=0.5)

    # mation.endDelay(15)

    # @mo.SkitParameters(x=0, radius=0, alphaPoint=0)
    # class Tanline(mo.Skit):
    #     def makeFrame(self):
    #         x = self.x
    #         radius = self.radius
    #         alphaPoint = self.alphaPoint

    #         pt = mo.grid.Point(x + 1j*F(x)).set(
    #             strokeWeight=2, color=[0,0,0], fill=[0,1,1],
    #             alpha=alphaPoint
    #             )

    #         fx = f(x)

    #         line = mo.grid.Path([-radius, radius]).set(
    #             width=5, color=[0,0,0],
    #             outlineWidth=1.5, outlineColor=mation.background
    #             )
    #         line.origin = pt.pos
    #         line.rotation = math.atan(fx)

    #         dashline = mo.grid.Path([pt.pos, x+1j*fx]).set(
    #             width=4, color=[0,0,0], alpha=alphaPoint,
    #             dash=[15,10]
    #             )

    #         return mo.Frame([dashline, line, pt])

    # @mo.SkitParameters(x=0, alpha=0)
    # class Follower(mo.Skit):
    #     def makeFrame(self):
    #         x = self.x
    #         alpha = self.alpha

    #         pt = mo.grid.Point(x + 1j*f(x)).set(
    #             strokeWeight=2, color=[0,0,0], fill=[1,0,1],
    #             alpha=alpha
    #             )

    #         return pt


    # time = mation.lastID() + 1
    # tanline = Tanline().set(zdepth=19)
    # tanline = mo.Actor(tanline)
    # mainlayer.merge(tanline, atFrame=time)
    # tanline.newendkey(20).set(radius=1.5, alphaPoint=1)

    # follower = Follower().set(zdepth=20)
    # follower = mo.Actor(follower)
    # mainlayer.merge(follower, atFrame=time)
    # follower.newendkey(20).alpha = 1

    # mation.endDelay(20)

    # for actor in [tanline, follower]:
    #     actor.newendkey(50).x = 2.5
    #     actor.newendkey(50).x = 0

    mation.endDelayUntil(15.6*30)
    print("Fade antideriv:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut([Flabel, Fcurve],
        atFrame=time, duration=20
        )

    mation.endDelayUntil(17.75*30)
    print("Draw integral area:", mation.seconds())

    area = mo.calculus.IntegralArea(
        func=f, start=1, end=1, strokeWeight=0,
        color=[0.8,0,0], fill=[1,0,0], alphaFill=0.5, steps=150
        ).set(zdepth=-1)
    area = mo.Actor(area)
    mainlayer.append(area)
    area.newendkey(30).end = 6

    mation.endDelay(10)

    time = mation.lastID()
    da = -0.05-0.05j
    alabel = mo.text.MultiText("a",
        pos=area.last().start+da, italic=True,
        size=64, color=[0.8,0,0], alpha=0
        )
    alabel.set(
        background=[1,1,1],
        backAlpha=0.5, backPad=0.02, zdepth=-2
        )
    alabel.backAlpha = 0
    alabel = mo.Actor(alabel)
    mainlayer.merge(alabel, atFrame=time)
    alabel.newendkey(20).set(anchor_y=1, alpha=1)

    blabel = alabel.first().copy()
    db = 0.05-0.05j
    blabel.set(text="b", pos=area.last().end+db, color=[0,0,0.8]).backPad += 0.025
    blabel = mo.Actor(blabel)
    mainlayer.merge(blabel, atFrame=time+10)
    blabel.newendkey(20).set(anchor_y=1, alpha=1)

    # mation.endDelayUntil(19.75*30)
    print("Show integral expression:", mation.seconds())

    time = mation.lastID()
    ilabel = mo.graphics.MultiImage("./resources/def-integral.png").set(
        height=0.75,
        background=[1,1,1], backPad=0.03, backAlpha=0.25
        )
    ilabel = mo.Actor(ilabel)
    ilabel.visible = False
    mainlayer.merge(ilabel)

    @mo.SkitParameters(alpha=0)
    class IntegralExpression(mo.Skit):
        def makeFrame(self, index=None):
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            expr = ilabel.time(index).copy()
            area_t = area.time(index)
            a,b = area_t.start, area_t.end
            for fig in expr.figures:
                fig.set(pos=mean([a,b]) + 1j).alpha *= alpha

            return expr

    expr = IntegralExpression()
    expr = mo.Actor(expr)
    mainlayer.merge(expr, atFrame=time)
    expr.newendkey(20).alpha = 1

    mation.endDelayUntil(26.25*30)
    print("Encircle b's:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    circ1 = mo.grid.ellipse(6.08-0.21j, 0.25).edge().set(
        width=5, color=[0,0,1], end=0, zdepth=100
        )
    circ1 = mo.Actor(circ1)
    mainlayer.merge(circ1, atFrame=time)
    circ1.newendkey(20).end = 1

    circ2 = mo.grid.ellipse((3.14+1.29j), 0.125).edge().set(
        width=4, color=circ1.last().color[:], end=0, zdepth=100
        )
    circ2 = mo.Actor(circ2)
    mainlayer.merge(circ2, atFrame=time)
    circ2.newendkey(20).end = 1

    mation.endDelayUntil(28.2*30)
    print("Morph b to t:", mation.seconds())

    time = mation.lastID()
    ilabel.newkey(time)
    ilabel.newendkey(20).newSource("./resources/def-integral-t.png").scaleByHeight()

    blabel.newkey(time)
    blabel.newendkey(20).set(text="t", color=violet)
    tlabel = blabel
    dt = db

    time = mation.lastID()
    # mation.start = time
    mo.actions.fadeOut([circ1, circ2], duration=20, atFrame=time)

    mation.endDelayUntil(30.5*30)
    print("Label the definite integral:", mation.seconds())

    expr0 = expr.last().makeFrame(index=mation.lastID())
    oneof = mo.graphics.Image("./resources/one-of-the.png").set(
        pos=expr0.pos-(expr0.height/2+2*expr0.backPad)*1j, align=[0,1], height=expr0.height*0.4
        ).set(background=[1,1,1], backAlpha=expr0.backAlpha)
    oneof = mo.Actor(oneof)
    mainlayer.append(oneof)
    oneof.fadeIn(duration=20, jump=-0.4j)

    mation.endDelayUntil(33.6*30)
    print("Unlabel the integral:", mation.seconds())

    oneof.rollback(duration=20)

    mation.endDelayUntil(39*30)
    print("Highlight area:", mation.seconds())

    time = mation.lastID()
    area.newkey(time)
    area.newendkey(20).set(fill=[1,1,0], alphaFill=1)

    mation.endDelayUntil(44.5*30)
    print("De-highlight the area:", mation.seconds())

    area.newendkey(20, area.key(-2).copy())

    # mation.endDelayUntil()
    print("Start scooting the rightbound:", mation.seconds())

    time = mation.lastID()
    area.newkey(time)
    area.newendkey(50).end /= 2
    area.newendkey(60).end = area.key[1].end + 1.5
    area.newendkey(30).end = area.key[1].end

    tlabel.newkey(time)
    for index in area.keyIDs:
        if index > time:
            tlabel.newkey(index).pos = area.time(index).end + dt






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./04_visualize.mp4", scale=1)


main()
