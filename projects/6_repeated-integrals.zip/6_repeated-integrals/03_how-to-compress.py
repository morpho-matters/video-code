
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "03_how-to-compress"


def card():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightviolet

    stagger = 5
    text1 = morpho.text.Text("How to Compress Integrals",
        pos=0j-4j, anchor_x=0,
        size=128, color=[0,0,0], alpha=0
        )
    text1.transition = toss
    text1 = morpho.Actor(text1)
    mainlayer.merge(text1)
    text1.newendkey(20).set(alpha=1, transition=drop).pos += 4j

    mation.endDelay(50)

    text1.newendkey(20).set(alpha=0, visible=False).pos += 4j

    mation.endDelay(30)





    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    # mation.newFrameRate(10)
    mation.play()

    # mation.newFrameRate(60)
    # mation.export("./15_va-property.mp4", scale=2/3)


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    toplayer = mainlayer.copy()
    mation = morpho.Animation([mainlayer, toplayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mation.start = 0

    mainlayer.camera.first().moveBy(-1j)

    title = morpho.text.Text("Compressing a 2-Fold Integral",
        pos=8j,
        size=84, anchor_x=0, anchor_y=0,
        color=(0,0,0)
        )
    title = morpho.Actor(title)
    toplayer.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    time = mation.lastID()
    dint = mo.graphics.MultiImage("./resources/double-integ-6x.png").set(
        pos=3j, height=2.75
        )
    dint = mo.Actor(dint)
    mainlayer.merge(dint, atFrame=-20)
    dint.fadeIn(duration=20, jump=2j)

    mation.endDelayUntil(10.4*30)
    print("Integrate inner integral:", mation.seconds())

    step1 = mo.text.Text("Step 1: Integrate the inner integral!",
        pos=dint.last().pos-3j, anchor_x=0,
        size=64, color=[0,0,0]
        ).set(zdepth=1)
    step1 = mo.Actor(step1)
    mainlayer.append(step1)
    step1.fadeIn(duration=20, jump=-2j)

    # boxer = mo.gadgets.enbox([-2.57,1.83, 1.35, 4.76],
    #     duration=20, width=5, color=[1,0,0]
    #     ).appendTo(mainlayer)

    ubrace = mo.graphics.Image("./resources/ubrace1-red.png").set(
        pos=mean([-2.54,1.85])+1.35j, height=0.5, align=[0,1]
        )
    ubrace.unlink()
    ubrace.width = (2.54+1.85)
    ubrace.scale_x = 0
    ubrace = mo.Actor(ubrace)
    mainlayer.append(ubrace)
    ubrace.newendkey(15).scale_x = 1

    mation.endDelay(10)

    outint = dint.last().copy()
    outint = mo.Actor(outint)
    mainlayer.append(outint)
    outint.newendkey(20).pos = step1.last().pos - 3j
    outint.last().newSource("./resources/integ-3x2.png").scaleByHeight()

    mation.endDelayUntil(13*30)
    print("'Enjoy your single integral!':", mation.seconds())

    step2 = mo.text.Text("Step 2: Enjoy your single integral!",
        pos=outint.last().pos-2.75j,
        size=64, color=[0,0,0]
        ).set(zdepth=1)
    step2 = mo.Actor(step2)
    mainlayer.append(step2)
    step2.fadeIn(duration=20, jump=-2j)

    mation.endDelayUntil(17.2*30)
    print("SCAM!", mation.seconds())

    hero = mo.graphics.Image("./resources/hero-grumpy.png").set(
        pos=(12.5-6.52j), height=8, align=[0,-1]
        )
    hero = mo.Actor(hero)
    mainlayer.append(hero)
    hero.fadeIn(duration=20)

    scam = mo.text.Text("Scam!",
        pos=12.07+0.11j, font="Qarmic sans",
        size=42, color=[0,0,0], alpha=0
        )
    scam = mo.Actor(scam)
    mainlayer.append(scam)
    scam.newendkey(20).set(pos=(9.7+3j), anchor_y=-1, alpha=1)

    arc = mo.grid.arc(9.7+2.63j, (10.93+1.09j), angle=80*deg).set(
        width=4, color=[0,0,0], end=0
        )
    arc = mo.Actor(arc)
    mainlayer.append(arc)
    arc.newendkey(20).end = 1

    mation.endDelayUntil(25.5*30)
    print("Rollback most stuff:", mation.seconds())

    mo.actions.rollback([arc, scam, hero, step2, step1, ubrace],
        duration=20, stagger=3
        )
    outint.fadeOut(duration=20, atFrame=arc.keyID(-2)+10)

    mation.endDelayUntil(32.4*30)
    print("Point to mystery integral:", mation.seconds())

    arrow = mo.grid.Arrow().set(width=6, color=violet, headSize=0)
    arrow.tail = arrow.head = dint.last().pos - 2j
    arrow = mo.Actor(arrow)
    mainlayer.append(arrow)
    arrow.newendkey(20).set(headSize=30).head -= 3j

    mystery = mo.graphics.MultiImage("./resources/integ-mystery.png").set(
        pos=arrow.last().head-2j, height=dint.last().height
        )
    mystery = mo.Actor(mystery)
    mainlayer.append(mystery)
    mystery.fadeIn(duration=20, jump=-3j)

    mation.endDelayUntil(37.25*30)
    print("Underbrace '(???)':", mation.seconds())

    ubrace2 = ubrace.last().copy()
    ubrace2.visible = True
    ubrace2.pos = mean([-1.33, 1.26]) - 4.9j
    ubrace2.align = [0,1]
    ubrace2.unlink()
    ubrace2.width = 1.26 + 1.33
    ubrace2.scale_x = 0
    ubrace2 = mo.Actor(ubrace2)
    mainlayer.append(ubrace2)
    ubrace2.newendkey(20).scale_x = 1

    single = mo.graphics.MultiImage("./resources/mini-integ-6x.png").set(
        pos=ubrace2.last().pos-1.25j, width=ubrace2.last().width
        )
    single = mo.Actor(single)
    mainlayer.append(single)
    single.fadeIn(duration=20, jump=-1j)

    mation.endDelayUntil(41.5*30)
    print("Show '= 3x^2':", mation.seconds())

    expr = mo.graphics.MultiImage("./resources/eq-3x2.png").set(
        pos=single.last().pos+single.last().width/2+0.3,
        align=[-1,-0.4], height=0.8*single.last().height
        )
    expr = mo.Actor(expr)
    mainlayer.append(expr)
    expr.fadeIn(duration=20, jump=2)

    mation.endDelayUntil(46*30)
    print("Find this...:", mation.seconds())

    findthis = mo.text.Text("find this",
        pos=6.26+expr.last().pos.imag*1j, anchor_x=-1,
        size=48, color=[1,0,0]
        )
    findthis = mo.Actor(findthis)
    mainlayer.append(findthis)
    findthis.fadeIn(duration=20, jump=4)

    farrow = mo.grid.Arrow()
    farrow.head = farrow.tail = findthis.last().pos - 0.5
    farrow.set(width=5, color=[1,0,0], headSize=0)
    farrow = mo.Actor(farrow)
    mainlayer.append(farrow)
    farrow.newendkey(20).set(
        head=3.85+1j*expr.last().pos.imag, headSize=25
        )

    mation.endDelayUntil(48.25*30)
    print("...without doing this:", mation.seconds())

    wo = mo.text.Text("without doing this?",
        pos=-1.33-8.5j, anchor_x=-1,
        size=findthis.last().size, color=violet
        )
    wo = mo.Actor(wo)
    mainlayer.append(wo)
    wo.fadeIn(duration=20, jump=-2j)

    warrow = mo.grid.Arrow()
    warrow.head = warrow.tail = 0.1-7.98j
    warrow.set(width=5, color=violet, headSize=0)
    warrow = mo.Actor(warrow)
    mainlayer.append(warrow)
    warrow.newendkey(20).set(
        head=warrow.last().head.real-6.78j, headSize=25
        )

    mation.endDelayUntil(57.25*30)
    print("Fade stuff:", mation.seconds())

    time = mation.lastID()
    # mation.start = time
    mo.actions.rollback(
        [warrow, wo, farrow, findthis, expr, single, ubrace2,
        mystery, arrow, dint],
        duration=20, stagger=3
        )

    mation.endDelayUntil(61*30)
    print("Show horrible integral:", mation.seconds())

    many = mo.graphics.Image("./resources/many-fold-integral.png").set(
        pos=-20+1.94j, align=[-1,0], height=dint.last().height
        )
    many = mo.Actor(many)
    mainlayer.append(many)
    many.fadeIn(duration=20)

    mation.endDelay(15)

    K = mo.graphics.Image("./resources/k-screaming.png").set(
        pos=many.last().pos.imag*1j-3j, align=[0,1], height=8
        )
    K = mo.Actor(K)
    mainlayer.append(K)
    K.fadeIn(duration=20)

    mation.endDelayUntil(67.75*30)
    print("Fade many-fold integral and my character:", mation.seconds())

    mo.actions.fadeOut([many, K], duration=20)

    mation.endDelayUntil(71*30)
    print("Show original double integral:", mation.seconds())

    time = mation.lastID()
    dint.newkey(time, dint.key[1].copy()).pos -= 2j
    dint.fadeIn(duration=20, jump=2j)

    mation.endDelay(20)

    ubrace3 = ubrace2.key[1].copy()
    ubrace3.set(
        pos=mean([-3.41,3.46])-0.69j, align=[0,1],
        width=3.46+3.41, scale_x=0
        )
    ubrace3.newSource("./resources/ubrace3-red.png")
    ubrace3 = mo.Actor(ubrace3)
    mainlayer.append(ubrace3)
    ubrace3.newendkey(20).scale_x = 1

    howto = mo.text.Text("How to visualize this?",
        pos=ubrace3.last().pos-1j,
        size=48, color=[1,0,0]
        )
    howto = mo.Actor(howto)
    mainlayer.append(howto)
    howto.fadeIn(duration=20, jump=-1j)





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./03_how-to-compress.mp4", scale=1)


# card()
main()
