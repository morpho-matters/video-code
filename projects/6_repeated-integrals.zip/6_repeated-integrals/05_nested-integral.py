
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "05_nested-integral"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    toplayer = mainlayer.copy()
    mation = morpho.Animation([mainlayer, toplayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # title = morpho.text.Text("Title",
    #     pos=8j,
    #     size=84, anchor_x=0, anchor_y=0,
    #     color=(0,0,0)
    #     )
    # title = morpho.Actor(title)
    # toplayer.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    dint = mo.graphics.MultiImage("./resources/double-integral-f(t).png").set(
        pos=1j, height=2.75
        )
    dint = mo.Actor(dint)
    mainlayer.merge(dint)

    mation.endDelayUntil(3*30)
    print("Set equal to definite integral version:", mation.seconds())

    dint.newendkey(20).set(align=[1,0]).pos -= 0.5

    defint = mo.graphics.MultiImage("./resources/eq-double-definite-integral.png").set(
        pos=1j, height=dint.last().height, alpha=0
        )
    defint = mo.Actor(defint)
    mainlayer.append(defint, timeOffset=-10)
    defint.newendkey(20).set(align=[-1,0], alpha=1)

    mation.endDelayUntil(16.5*30)
    print("Encircle 't':", mation.seconds())

    circ = mo.grid.ellipse((2.42+2.11j), 0.5).edge().set(
        width=4, color=[0,0,1], end=0
        )
    circ = mo.Actor(circ)
    mainlayer.append(circ)
    circ.newendkey(20).end = 1

    mation.endDelayUntil(22.25*30)
    print("Remove encircling:", mation.seconds())

    circ.fadeOut(duration=20)

    mation.endDelayUntil(28.75*30)
    print("Label:", mation.seconds())

    label = mo.text.Text("Volume of a Solid!",
        pos=defint.last().center+0.5-defint.last().height/2*1j-0.5j,
        anchor_y=1,
        size=56, color=[0,0,0]
        )
    label = mo.Actor(label)
    mainlayer.append(label)
    label.fadeIn(duration=20, jump=-2j)




    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./05_nested-integral.mp4", scale=1)


main()
