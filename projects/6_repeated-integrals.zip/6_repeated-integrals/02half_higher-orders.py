
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "02half_higher-orders"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    integ = mo.graphics.MultiImage("./resources/single-integral.png").set(
        pos=0, height=2.75
        )
    integ = mo.Actor(integ)
    mainlayer.merge(integ)

    mation.endDelayUntil(4.25*30)
    print("Morph to double integral:", mation.seconds())

    integ.newendkey(20).newSource("./resources/double-integral.png").scaleByHeight()

    mation.endDelayUntil(6.6*30)
    print("Morph to triple integral:", mation.seconds())

    integ.newendkey(20).newSource("./resources/triple-integral.png").scaleByHeight()

    mation.endDelay(45)
    print("Morph to n-fold integral:", mation.seconds())

    integ.newendkey(20).newSource("./resources/n-fold-integral.png").scaleByHeight()

    mation.endDelayUntil(12.3*30)
    print("'Slow':", mation.seconds())

    slow = mo.text.Text("Slow",
        pos=integ.last().pos+integ.last().height/2*1j+0.5j, anchor_y=-1,
        size=64, color=violet
        )
    slow = mo.Actor(slow)
    mainlayer.append(slow)
    slow.fadeIn(duration=20, jump=2j)

    mation.endDelayUntil(13.2*30)
    print("'Inaccurate':", mation.seconds())

    inacc = mo.text.Text("Inaccurate",
        pos=integ.last().pos-integ.last().height/2*1j-0.5j, anchor_y=1,
        size=64, color=[1,0,0]
        )
    inacc = mo.Actor(inacc)
    mainlayer.append(inacc)
    inacc.fadeIn(duration=20, jump=-2j)

    mation.endDelayUntil(19.25*30)
    print("Point arrow to mystery single integral:", mation.seconds())

    mo.action.rollback([slow, inacc], duration=20)

    time = mation.lastID()

    arrow = mo.grid.Arrow().set(
        width=6, color=violet, headSize=0
        )
    arrow.tail = arrow.head = integ.last().pos - 2j
    arrow = mo.Actor(arrow)
    mainlayer.append(arrow, timeOffset=20)
    arrow.newendkey(20).set(headSize=30).head -= 4j

    # Scoot camera
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(20).centerAt(arrow.last().midpoint())

    mystery = mo.graphics.MultiImage("./resources/integ-mystery.png").set(
        pos=arrow.last().head-2j, height=integ.last().height
        )
    mystery = mo.Actor(mystery)
    mainlayer.merge(mystery, atFrame=arrow.lastID())
    mystery.fadeIn(duration=20, jump=-5j)

    mation.endDelayUntil(26.5*30)
    print("Show 'How?' label:", mation.seconds())

    how = mo.text.Text("How?",
        pos=arrow.last().midpoint(),
        size=64, color=arrow.last().color[:], alpha=0
        )
    how = mo.Actor(how)
    mainlayer.append(how)
    how.newendkey(20).set(anchor_x=-1.5, alpha=1)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./02half_higher-orders.mp4", scale=1)


main()
