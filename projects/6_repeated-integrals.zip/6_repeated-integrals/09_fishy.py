
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "09_fishy"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    toplayer = mainlayer.copy()
    mation = morpho.Animation([mainlayer, toplayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mainlayer.camera.first().zoomIn(2).moveBy(3+3.75j)

    # title = morpho.text.Text("Compressing a 2-Fold Integral",
    #     pos=8j,
    #     size=84, anchor_x=0, anchor_y=0,
    #     color=(0,0,0)
    #     )
    # title = morpho.Actor(title)
    # toplayer.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    mation.endDelay(15)

    time = mation.lastID()
    cauchy = mo.graphics.MultiImage("./resources/cauchy0.png").set(
        pos=2j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    toplayer.merge(cauchy, atFrame=time)
    cauchy.fadeIn(duration=20, jump=2j)

    # cauchybox = mo.grid.rect(cauchy.last().box(pad=0.5)).set(
    #     width=4, color=[0,0,1], fill=[1,1,1]
    #     )
    # cauchybox = mo.Actor(cauchybox)
    # toplayer.merge(cauchybox, atFrame=time, beforeActor=cauchy)

    mation.endDelayUntil(8*30)
    print("Enbox the double integral signs:", mation.seconds())

    dboxer = mo.gadgets.enbox([-7.8,-4.76, 0.67,3.31],
        width=4, color=[1,0,0]
        )
    toplayer.append(dboxer)

    mation.endDelayUntil(10.5*30)
    print("Enbox the single integral sign:", mation.seconds())

    sboxer = mo.gadgets.enbox([0.43,1.81, 0.78,3.26],
        width=4, color=[0,0,1]
        )
    toplayer.append(sboxer)

    mation.endDelayUntil(17.35*30)
    print("Debox and enbox integrand:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut([sboxer, dboxer], duration=20, atFrame=time)

    mation.endDelay(10)

    time = mation.lastID()
    integrandboxer = mo.gadgets.enbox([1.76,6.43, 1.31,2.67],
        width=4, color=violet, duration=30
        )
    toplayer.append(integrandboxer)

    mation.endDelayUntil(21.25*30)
    print("Enbox inner integral:", mation.seconds())

    time = mation.lastID()
    innerboxer = mo.gadgets.enbox([-6.33,-1.67, 0.76,3.17],
        width=4, color=violet, duration=30
        )
    toplayer.append(innerboxer)

    mation.endDelayUntil(26.25*30)
    print("'Are these the same thing?':", mation.seconds())

    same = mo.text.Text("Are these the same thing?",
        pos=-1.28j,
        size=64, color=violet
        )
    same = mo.Actor(same)
    toplayer.append(same)
    same.fadeIn(duration=20, jump=-2j)

    time = mation.lastID()
    # mation.start = time
    arrow1 = mo.grid.Arrow(-3.93-0.67j, -3.93+0.75j).set(
        width=5, color=violet, headSize=25
        )
    arrow1 = mo.Actor(arrow1)
    toplayer.merge(arrow1, atFrame=time)
    # arrow1.growIn(duration=20)

    arrow2 = arrow1.last().copy()
    arrow2.set(tail=4.26-0.67j, head=4.26+1.3j)
    arrow2 = mo.Actor(arrow2)
    toplayer.merge(arrow2, atFrame=time)
    # arrow2.growIn(duration=20)

    mo.action.growIn([arrow1, arrow2], duration=20)

    # mation.end = mation.lastID()

    mation.endDelayUntil(33*30)
    print("'Not really...':", mation.seconds())

    notrly = mo.text.Text("Not really...",
        pos=same.last().pos+3,
        size=56, color=[1,0,0], alpha=0
        )
    notrly = mo.Actor(notrly)
    toplayer.append(notrly)
    notrly.newendkey(20).set(alpha=1).pos -= 1.5j

    mation.endDelayUntil(37.75*30)
    print("Cleanup labels:", mation.seconds())

    time = mation.lastID()
    mo.actions.rollback([notrly, arrow2, arrow1, same, innerboxer, integrandboxer],
        duration=20, stagger=3
        )

    mation.endDelayUntil(45.15*30)
    print("Encircle the variables in the RHS integrand:", mation.seconds())

    time = mation.lastID()
    stagger = 5
    radius = 0.5
    tcirc1 = mo.grid.ellipse(2.28+2.02j, radius).edge().set(
        width=4, color=violet, end=0
        )
    tcirc1 = mo.Actor(tcirc1)
    toplayer.merge(tcirc1, atFrame=time)
    tcirc1.newendkey(20).end = 1

    xcirc1 = mo.grid.ellipse(3.83+1.96j, radius).edge().set(
        width=4, color=[0,0.6,0], end=0
        )
    xcirc1 = mo.Actor(xcirc1)
    toplayer.merge(xcirc1, atFrame=time+stagger)
    xcirc1.newendkey(20).end = 1

    xcirc2 = mo.grid.ellipse((5.81+1.93j), radius).edge().set(
        width=4, color=[0,0.6,0], end=0
        )
    xcirc2 = mo.Actor(xcirc2)
    toplayer.merge(xcirc2, atFrame=time+2*stagger)
    xcirc2.newendkey(20).end = 1

    mation.endDelayUntil(49*30)
    print("Encircle the t in the upperbound:", mation.seconds())

    tcirc2 = mo.grid.ellipse((1.59+2.89j), 0.33).edge().set(
        width=4, color=violet, end=0
        )
    tcirc2 = mo.Actor(tcirc2)
    toplayer.append(tcirc2)
    tcirc2.newendkey(20).end = 1

    mation.endDelayUntil(54.25*30)
    print("Decircle and morph `t` to a decimal tracker:", mation.seconds())

    time = mation.lastID()
    mo.actions.rollback([tcirc2, tcirc1, xcirc1, xcirc2],
        duration=20, stagger=3, atFrame=time
        )

    time = mation.lastID()
    # mation.start = time
    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/cauchy-blanks.png").scaleByHeight()

    @morpho.SkitParameters(t=0, alpha=0)
    class tTrackers(morpho.Skit):
        def makeFrame(self):
            t = self.t
            alpha = self.alpha

            pos0 = (0.15+2.93j)
            pos1 = (2.26+1.96j)

            num = mo.text.formatNumber(t, decimal=2, rightDigits=2)
            t1 = mo.text.Text(num,
                pos=pos0, anchor_x=-1,
                size=38, color=violet, alpha=alpha
                )
            t2 = t1.copy().set(pos=pos1, size=50)

            return mo.Frame([t1, t2])

    tracker = tTrackers()
    tracker = mo.Actor(tracker)
    toplayer.merge(tracker, atFrame=time)
    tracker.fadeIn(duration=20)

    mation.endDelay(15)

    tracker.newendkey(45).t = tau
    mation.endDelay(30)
    tracker.newendkey(30).t = math.sqrt(2)
    mation.endDelay(30)
    tracker.newendkey(30).t = pi

    mation.endDelayUntil(64.25*30)
    print("Show graph:", mation.seconds())

    time = mation.lastID()
    # # Morph formula back to generic t form
    # tracker.newkey(time)
    # tracker.fadeOut(duration=20)
    # cauchy.newkey(time)
    # cauchy.newendkey(20, cauchy.key[1].copy())

    toplayer.camera.newkey(time)
    toplayer.camera.newendkey(30).moveBy(-5j)

    # Draw grid
    time = mation.lastID() - 15
    axes = mo.grid.Path([6j, 0, 6]).set(
        width=8, color=[0,0,0]
        )
    axes.start = axes.end = 0.5
    axes = mo.Actor(axes)
    mainlayer.merge(axes, atFrame=time)
    axes.newendkey(20).set(start=0, end=1)

    grid = mo.grid.mathgrid(view=[0,6, 0,6],
        hsteps=1, vsteps=1,
        hcolor=[0,0.6,0], vcolor=[0,0,0.8],
        BGgrid=False, axes=False
        )
    grid = mo.Actor(grid)
    grid.newendkey(30)
    for path in grid.first().figures:
        path.end = 0
    mainlayer.append(grid, timeOffset=-10, beforeActor=axes)

    mation.endDelay(10)

    # Draw graph
    f = lambda x: 0.3 + 0.55*x
    integrand = lambda t,x: (t-x)*f(x)

    # Graph skit puppets tTracker
    graphFill = tuple((1-0.5*(1-mo.array(violet))).tolist())
    @morpho.SkitParameters(end=0, alphaArea=0, alphaLabel=0, alpha=1)
    class Graph(mo.Skit):
        def makeFrame(self, index=None):
            end = self.end
            alphaArea = self.alphaArea
            alphaLabel = self.alphaLabel
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex
            t = tracker.time(index).t

            if alpha == 0:
                return mo.Frame()

            figs = []
            curve = mo.graph.realgraph(lambda x: integrand(t,x), 0, t, steps=50).set(
                width=5, end=end,
                color=violet, alpha=alpha
                )
            bg = curve.copy().set(width=0, fill=graphFill, alphaFill=alphaArea)
            bg.seq.append(0)
            bg.close()
            figs.append(bg)
            figs.append(curve)

            if alphaLabel > 0:
                arrow = mo.grid.Arrow(t-0.2j, t).set(
                    headSize=30, color=violet, alpha=alphaLabel*alpha
                    )
                figs.append(arrow)

                num = mo.text.formatNumber(t, decimal=2, rightDigits=2)
                label = mo.text.Text(f"t = {num}",
                    pos=t-0.3j, anchor_x=-0.9, anchor_y=1,
                    size=56, color=violet, alpha=alphaLabel*alpha
                    )
                figs.append(label)


            return mo.Frame(figs)

    time = mation.lastID()
    # mation.start = time
    # tracker.last().t = tau
    graph = Graph()
    graph = mo.Actor(graph)
    mainlayer.merge(graph, atFrame=time, beforeActor=axes)
    graph.newendkey(20).end = 1
    graph.newendkey(20).set(alphaArea=0.5, alphaLabel=1)

    mation.endDelayUntil(73.75*30)
    print("Start scooting t-value:", mation.seconds())

    time = mation.lastID()
    tracker.newkey(time)
    tracker.newendkey(45).t = tau/4
    mation.endDelay(20)
    tracker.newendkey(60).t = 5.43
    mation.endDelay(20)
    tracker.newendkey(50).t = math.e







    print("Animation length:", mation.seconds())
    mation.endDelay(20*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = toplayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./09_fishy.mp4", scale=1)


main()
