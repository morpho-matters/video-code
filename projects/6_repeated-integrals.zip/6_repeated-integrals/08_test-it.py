
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "08_test-it"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    toplayer = mainlayer.copy()
    mation = morpho.Animation([mainlayer, toplayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # title = morpho.text.Text("Compressing a 2-Fold Integral",
    #     pos=8j,
    #     size=84, anchor_x=0, anchor_y=0,
    #     color=(0,0,0)
    #     )
    # title = morpho.Actor(title)
    # toplayer.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    time = mation.lastID()
    cauchy = mo.graphics.Image("./resources/cauchy0.png").set(
        pos=8j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    toplayer.merge(cauchy, atFrame=time)

    cauchybox = mo.grid.rect(cauchy.last().box(pad=0.5)).set(
        width=4, color=[0,0,1], fill=[1,1,1]
        )
    cauchybox = mo.Actor(cauchybox)
    toplayer.merge(cauchybox, atFrame=time, beforeActor=cauchy)

    mation.endDelayUntil(1.5*30)
    print("Show second integral:", mation.seconds())

    time = mation.lastID()
    iint = mo.graphics.MultiImage("./resources/iint-6t.png").set(
        pos=3.5j, height=2.25
        )
    iint = mo.Actor(iint)
    mainlayer.merge(iint, atFrame=time)
    iint.fadeIn(duration=20, jump=2j)

    mation.endDelayUntil(6.75*30)
    print("Show expected result:", mation.seconds())

    time = mation.lastID() + 1
    result = iint.last().copy()
    result = mo.Actor(result)
    toplayer.merge(result, atFrame=time)
    result.newendkey(20).newSource("./resources/int-3t2.png").scaleByHeight().pos -= 3j

    mation.endDelay(10)

    result.newendkey(20).newSource("./resources/t3.png").scaleByHeight().height /= 2.25

    mation.endDelay(20)

    time = mation.lastID()
    result.newkey(time)
    result.newendkey(20).set(pos=(16.54+7.59j), align=[1,0])

    expected = mo.text.Text("Expected:",
        pos=result.last().pos+1.5j, anchor_x=1,
        size=56, color=violet
        )
    expected = mo.Actor(expected)
    toplayer.merge(expected, atFrame=time)
    expected.fadeIn(duration=20)

    time = mation.lastID()
    exbox = mo.gadgets.enbox([11.94, 17.02, 6.74, 9.72],
        duration=20, width=4, color=violet
        )
    exbox.last().fill = [1,1,1]
    toplayer.merge(exbox, atFrame=time, beforeActor=result)
    exbox.newendkey(20).set(alphaFill=1)

    mation.endDelayUntil(12*30)
    print("Morph to definite nested integral:", mation.seconds())

    time = mation.lastID()
    iint.newkey(time)
    iint.newendkey(20).newSource("./resources/nested-int-6x.png").scaleByHeight()

    mation.endDelayUntil(17.25*30)
    print("Scoot and apply Cauchy formula:", mation.seconds())

    gap = 0.33
    iint.newendkey(20).set(pos=-2+iint.last().pos.imag*1j, align=[1,0])

    time = mation.lastID()
    step1 = mo.graphics.MultiImage("./resources/step1.png").set(
        pos=iint.last().pos+gap, align=[-1,0], height=iint.last().height
        )
    step1 = mo.Actor(step1)
    mainlayer.merge(step1, atFrame=time)
    step1.fadeIn(duration=20, jump=4)

    pointer = mo.grid.Arrow()
    pointer.head = pointer.tail = step1.last().pos.real+0.33 + 1j*cauchy.last().box(pad=0.5)[2]
    pointer.set(
        width=cauchybox.last().width, color=cauchybox.last().color[:],
        headSize=0
        )
    pointer = mo.Actor(pointer)
    mainlayer.merge(pointer, atFrame=time)
    pointer.newendkey(20).set(
        head=pointer.last().head.real+1j*step1.last().pos.imag+0.1j,
        headSize=25
        )

    mation.endDelayUntil(25.75*30)
    print("Show Step 2:", mation.seconds())

    time = mation.lastID() + 1
    jumpy = 2.75
    step2 = mo.Actor(step1.last().copy())
    mainlayer.merge(step2, atFrame=time)
    step2.newendkey(20).newSource("./resources/step2.png").scaleByHeight().pos -= jumpy*1j

    mation.endDelayUntil(38.25*30)
    print("Show Step 3:", mation.seconds())

    step3 = mo.Actor(step2.last().copy())
    mainlayer.append(step3, timeOffset=1)
    step3.newendkey(20).newSource("./resources/step3.png").scaleByHeight().pos -= jumpy*1j
    step3.last().height *= 0.85

    mation.endDelayUntil(46.5*30)
    print("Show Step 4:", mation.seconds())

    step4 = mo.Actor(step3.last().copy())
    mainlayer.append(step4, timeOffset=1)
    step4.newendkey(20).newSource("./resources/step4.png").scaleByHeight().pos -= jumpy*1j
    step4.last().height *= 0.62

    mation.endDelayUntil(54.5*30)
    print("Show final step:", mation.seconds())

    step5 = mo.Actor(step4.last().copy())
    mainlayer.append(step5, timeOffset=1)
    step5.newendkey(20).newSource("./resources/step5.png").scaleByHeight().pos -= 0.75*jumpy*1j
    step5.last().height *= 0.75

    mation.endDelay(10)

    finalbox = mo.gadgets.enbox(step5.last().box(pad=0.5),
        width=4, color=[0,0.7,0], duration=20
        )
    finalbox.last().fill = [1,1,1]
    mainlayer.append(finalbox, beforeActor=step5)

    finalbox.newendkey(20).alphaFill = 1

    mation.endDelayUntil(57*30)
    print("Flush expected box:", mation.seconds())

    time = mation.lastID()
    exbox.newkey(time)
    exbox.newendkey(20).set(color=finalbox.last().color[:], fill=[0.75, 1, 0.75])  # .width *= 1.25

    mation.endDelayUntil(59.8*30)
    print("De-flush:", mation.seconds())

    time = mation.lastID()
    exbox.newkey(time)
    exbox.newendkey(20, exbox.key[-2].copy())

    finalbox.newkey(time)
    finalbox.fadeOut(20)

    mation.endDelayUntil(62*30)
    print("Show original indefinite integral:", mation.seconds())

    time = mation.lastID()
    iint2 = iint.key[1].copy()
    iint2.set(pos=step5.last().pos-0.75, align=[1,0.15])
    iint2 = mo.Actor(iint2)
    mainlayer.merge(iint2, atFrame=time)
    iint2.fadeIn(duration=20, jump=-3)

    mation.endDelayUntil(65.05*30)
    print("Add arbitrary linear term:", mation.seconds())

    time = mation.lastID()
    ans = step5
    ans.newkey(time)
    ans.newendkey(20).newSource("./resources/t3-Ct-D.png").scaleByHeight().height *= 1.07

    mation.endDelayUntil(73.8*30)
    print("Re-enbox just the t^3 part:", mation.seconds())

    time = mation.lastID()
    finalbox.insert(finalbox.segment(finalbox.keyID[0], finalbox.keyID[2]), afterFrame=time)







    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./08_test-it.mp4", scale=1)


main()
