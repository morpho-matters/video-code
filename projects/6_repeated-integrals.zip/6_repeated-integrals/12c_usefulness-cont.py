
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "12c_usefulness-cont"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    cauchy = mo.graphics.MultiImage("./resources/cauchy-formula.png").set(
        pos=7j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    mainlayer.merge(cauchy)

    cbox = mo.grid.rect(cauchy.last().box(pad=0.5)).set(
        width=4, color=[0,0,1], fill=[1,1,1]
        )
    cbox = mo.Actor(cbox)
    mainlayer.merge(cbox, beforeActor=cauchy)

    mation.endDelayUntil()
    # print("Show sin(x) disaster:", mation.seconds())

    badsin = mo.graphics.MultiImage("./resources/sine-disaster.png").set(
        pos=3j, height=2.25
        )
    badsin = mo.Actor(badsin)
    mainlayer.append(badsin)
    badsin.fadeIn(20, jump=2j)

    mation.endDelayUntil()
    # print("Show cartoons:", mation.seconds())

    hero = mo.graphics.MultiImage("./resources/hero-chalkboard.png").set(
        pos=-3-8j, align=[0,-1], height=9, scale_x=-1
        )
    hero = mo.Actor(hero)
    mainlayer.append(hero)
    hero.fadeIn(20)

    kman = mo.graphics.MultiImage("./resources/k-chair.png").set(
        pos=9+hero.last().pos.imag*1j, align=[-1,-1],
        height=7.5
        )
    kman = mo.Actor(kman)
    mainlayer.append(kman)
    kman.fadeIn(20)

    mation.endDelay(15)

    symb = mo.graphics.MultiImage("./resources/calculator.png").set(
        pos=(-0.3-0.31j), align=[-1,0], height=1.5
        )
    symb = mo.Actor(symb)
    mainlayer.append(symb)
    symb.fadeIn(20, jump=3+1j)

    harc = mo.grid.arc(0.24-1.33j, (-0.76-2.31j), -75*deg).set(
        width=3.5, color=[0,0,0]
        )
    harc = mo.Actor(harc)
    mainlayer.append(harc)
    harc.growIn(20)

    mation.endDelay(45)

    no = mo.text.Text("No.",
        pos=(9.19+0.13j), anchor_y=-1, font="Qarmic sans",
        size=32, color=[0,0,0]
        )
    no = mo.Actor(no)
    mainlayer.append(no)
    no.fadeIn(20, jump=-2+2j)

    karc = mo.grid.arc(9.22-0.11j, (9.98-0.65j), 60*deg).set(
        width=3.5, color=[0,0,0]
        )
    karc = mo.Actor(karc)
    mainlayer.append(karc)
    karc.growIn(20)

    mation.endDelay(45)

    time = mation.lastID()
    mo.action.fadeOut([symb, harc], atFrame=time, duration=20)

    hero.newkey(time)
    hero.newendkey(20).newSource("./resources/hero-chalkboard-sad.png").scaleByHeight()

    time = mation.lastID()
    rats = mo.text.Text("(Rats...)",
        pos=(-5.61-0.93j), anchor_x=1, anchor_y=-1,
        font="Qarmic sans",
        size=32, color=[0,0,0]
        )
    rats = mo.Actor(rats)
    mainlayer.merge(rats, atFrame=time)
    rats.fadeIn(20, jump=-2+1j)

    harc2 = mo.grid.arc(-6.19-1.22j, (-5.24-1.96j), 75*deg).set(
        width=3.5, color=[0,0,0], dash=[8]
        )
    harc2 = mo.Actor(harc2)
    mainlayer.append(harc2)
    harc2.growIn(20)

    mation.endDelayUntil()
    # print("Remove cartoons:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([harc2, rats, hero, karc, no, kman],
        duration=20, atFrame=time)

    mation.endDelayUntil()
    # print("Show disaster label:", mation.seconds())

    dlabel = mo.graphics.MultiImage("./resources/sine-underbrace.png").set(
        pos=mean([9.67, 0.57])+1.69j, width=9.67-0.57, align=[0,1],
        scale_x=0
        )
    dlabel = mo.Actor(dlabel)
    mainlayer.append(dlabel)
    dlabel.newendkey(20).scale_x = 1





    ### ABOVE IS PRELIM ###

    dlabel.visible = False
    badsin.visible = False
    cbox.visible = False
    cauchy.last().pos -= 2j

    time = mation.lastID()
    mation.start = time

    mation.endDelayUntil(1.5*30)
    print("Enbox single integral sign:", mation.seconds())

    boxer = mo.gadgets.enbox([0.46,1.83, 3.7,6.3],
        width=4, color=[0,0,1]
        )
    mainlayer.merge(boxer, atFrame=time)

    mation.endDelayUntil(5.5*30)
    print("Debox:", mation.seconds())

    boxer.fadeOut(20)

    mation.endDelayUntil(8*30)
    print("Show cartoons:", mation.seconds())

    time = mation.lastID()
    ddx = mo.graphics.MultiImage("./resources/ddx.png").set(
        pos=(3.43-7j), align=[0,-1], height=4
        )
    ddx = mo.Actor(ddx)
    mainlayer.append(ddx)
    ddx.fadeIn(20)

    mation.endDelay(20)

    # serpentbase = mo.graphics.Image("./resources/serpentine-integral.png").set(
    #     height=ddx.last().height*1.5, align=[0,-1]
    #     )
    # serpents = []
    # dx = 3
    # pos0 = (-1.5-6.83j)
    # for n in range(5):
    #     serpent = serpentbase.copy()
    #     serpent.pos = pos0 - n*dx
    #     mainlayer.merge(serpent)

    time = mation.lastID()
    serpents = mo.graphics.MultiImage("./resources/serpents.png").set(
        pos=ddx.last().pos.imag*1j, align=[1,-1], height=ddx.last().height*1.5
        )
    serpents = mo.Actor(serpents)
    mainlayer.merge(serpents, atFrame=time)
    serpents.fadeIn(30)

    mation.endDelay(15)

    canyou = mo.text.Text("Betcha can't do thisss...",
        pos=(-1.25+1j), anchor_x=-1, font="Qarmic sans",
        size=32, color=[0,0,0]
        )
    canyou = mo.Actor(canyou)
    mainlayer.append(canyou)
    canyou.fadeIn(20, jump=1+2j)

    arc = mo.grid.arc(0.59+0.37j, (-0.09-1.26j), angle=-30*deg).set(
        width=4, color=[0,0,0]
        )
    arc = mo.Actor(arc)
    mainlayer.append(arc)
    arc.growIn(20)

    mation.endDelay(40)

    time = mation.lastID()
    mo.action.fadeOut([arc, canyou], atFrame=time, duration=20)

    serpents.newkey(time)
    serpents.newendkey(30).newSource("./resources/serpentine-integral.png").scaleByHeight()

    mation.endDelay(5)

    # ddx is sad
    time = mation.lastID()
    ddx.newkey(time)
    ddx.newendkey(12).newSource("./resources/ddx-sad.png").scaleByHeight().height *= 1.025








    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./12c_usefulness-cont.mp4", scale=1)


main()
