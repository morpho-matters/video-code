
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))

dash = "\u2012"

morpho.anim.exportSignature = "02_numerical-calculus"



def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightviolet

    mainlayer.camera.first().centerAt(14+7j)

    axes = mo.grid.Path([-50,50, -50j,50j]).set(
        width=8, color=[0,0,0], zdepth=10
        )
    axes.deadends.add(1)
    axes = mo.Actor(axes)
    mainlayer.merge(axes)

    mation.endDelay(20)

    a = 4
    b = 26

    A = 0.01575
    B = -0.7322
    C = 10.56
    D = -36.40
    f = lambda x: A*x**3 + B*x**2 + C*x + D
    graph = mo.graph.realgraph(f,a,b, steps=120, width=7, color=[0.8,0,0])
    graph.end = 0
    graph = mo.Actor(graph)
    mainlayer.merge(graph)
    graph.newendkey(30).end = 1

    x0 = 10.43
    y0 = f(x0)
    xradius = 5
    df = lambda x: 3*A*x**2 + 2*B*x + C

    mation.endDelayUntil(3*30)
    print("Show tangent line:", mation.seconds())

    tanpt = mo.grid.Point(x0+1j*y0).set(
        size=15, strokeWeight=2, color=[0,0,0], fill=[1,1,0], alpha=0,
        zdepth=2
        )
    tanpt = mo.Actor(tanpt)
    mainlayer.append(tanpt)
    tanpt.newendkey(15).alpha = 1

    m = df(x0)
    tanfunc = lambda x: x + 1j*(m*(x-x0) + y0)
    tanline = mo.grid.Path([x0-xradius,x0+xradius]).fimage(tanfunc).set(
        width=5, color=[0,0,0], end=0, dash=[15,10], # zdepth=1
        )
    tanline = mo.Actor(tanline)
    mainlayer.append(tanline)
    tanline.newendkey(15).end = 1

    mation.endDelayUntil(5*30)
    print("Show secant line and start scooting:", mation.seconds())


    @morpho.SkitParameters(x0=x0, dx=1, alpha=0, end=0, xradius=xradius)
    class Secant(morpho.Skit):
        def makeFrame(self):
            x0 = self.x0
            dx = self.dx
            alpha = self.alpha
            end = self.end
            xradius = self.xradius

            if alpha == 0:
                return mo.Frame()

            xLeft = x0 - dx
            xRight = x0 + dx
            yLeft = f(xLeft)
            yRight = f(xRight)

            figs = []

            ptLeft = mo.grid.Point(xLeft+1j*yLeft).set(
                size=15, strokeWeight=2, color=[0,0,0], fill=[0,1,1],
                alpha=alpha, zdepth=1
                )
            figs.append(ptLeft)

            ptRight = ptLeft.copy()
            ptRight.pos = xRight + 1j*yRight
            figs.append(ptRight)

            if end > 0:
                # Compute slope
                m = (yRight-yLeft)/(xRight-xLeft)
                func = lambda x: x + 1j*(m*(x-xLeft) + yLeft)
                line = mo.grid.Path([x0-xradius, x0+xradius]).fimage(func)
                line.set(
                    width=6, color=[0,0.6,0], alpha=alpha,
                    end=end
                    )
                figs.append(line)

            return mo.Frame(figs)

    secant = Secant(dx=3)
    secant = mo.Actor(secant)
    mainlayer.append(secant)
    secant.newendkey(15).alpha = 1
    secant.newendkey(15).end = 1

    dapprox = mo.graphics.Image("./resources/deriv-approx.png").set(
        pos=tanpt.last().pos, height=1.5, alpha=0
        )
    dapprox = mo.Actor(dapprox)
    mainlayer.append(dapprox)
    dapprox.newendkey(20).set(
        pos=(10.85+13.11j), align=[1,0], alpha=1
        )

    # mation.start = mation.end = mation.lastID()

    mation.endDelay(20)

    time = mation.lastID()
    secant.newkey(time)
    secant.newendkey(70).dx = 0.1

    mation.endDelayUntil(10*30)
    print("Fade and show integral stuff:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut([secant, tanline, tanpt, dapprox], atFrame=time, duration=20)

    # Draw integration region
    istart = 7.7
    iend = 19.5
    area = mo.calculus.IntegralArea(
        func=f, start=istart, end=istart,
        strokeWeight=0, fill=orange, alpha=0.65,
        steps=100
        ).set(zdepth=-1)
    area = mo.Actor(area)
    mainlayer.append(area)
    area.newendkey(30).end = iend

    mation.endDelay(20)

    # Draw Riemann rects
    time = mation.lastID()
    stagger = 4
    fill = mo.color.parseHexColor("ff8827")
    color = (0.5*mo.array(fill)).tolist()
    rsum = mo.calculus.RiemannSum(f, [istart, iend], rectCount=10,
        align=0, color=[0,0,0], fill=[1,1,0.25],
        strokeWeight=3, transition=quadease
        )
    rects = []
    for n,fig in enumerate(rsum.figures):
        fig = fig.polygon
        fig.alphaFill = 0.6
        rect = mo.Actor(fig)
        mainlayer.merge(rect, atFrame=time+n*stagger)
        rects.append(rect)

        rect.newendkey(20)
        rect.beg = rect.beg.fimage(lambda z: z.real)
        # rect.first().height = 0







    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./02_numerical-calculus.mp4", scale=1)


main()
