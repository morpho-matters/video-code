
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

ihat = mo.matrix.array([1,0,0])
jhat = mo.matrix.array([0,1,0])
khat = mo.matrix.array([0,0,1])

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))

dash = "\u2012"

morpho.anim.exportSignature = "00_intro"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mation.endDelay(30)
    print("Show title:", mation.seconds())

    title = morpho.text.Text("Can you compress two integrals into one?",
        pos=8j-2j,
        size=76, anchor_x=0, anchor_y=0,
        color=(0,0,0), alpha=0
        )
    title = morpho.Actor(title)
    mainlayer.merge(title)
    title.newendkey(20).set(alpha=1).pos += 2j

    mation.endDelayUntil(4.5*30)
    print("Show f(x):", mation.seconds())

    formula = mo.graphics.Image("./resources/f(x)-formula.png")
    formula.set(pos=4.5j-2j, height=2.25, alpha=0)
    formula = mo.Actor(formula)
    mainlayer.append(formula)
    formula.newendkey(20).set(alpha=1).pos += 2j

    mation.endDelayUntil(6.5*30)
    print("Show 'second antiderivative' label:", mation.seconds())

    label = mo.text.Text("\"Second antiderivative\" of",
        pos=formula.last().pos-formula.last().width/2-1, anchor_x=1,
        size=56, color=[1,0,0]
        )
    label = mo.Actor(label)
    mainlayer.append(label)
    label.fadeIn(duration=20, jump=3)

    mation.endDelayUntil(14*30)
    print("Show integral:", mation.seconds())

    time = mation.lastID()
    arrow1 = mo.grid.Arrow().set(
        tail=formula.last().pos-1.5j,
        width=6, color=violet, headSize=0
        )
    arrow1.length = 0
    arrow1 = mo.Actor(arrow1)
    mainlayer.append(arrow1)
    arrow1.newendkey(20).set(headSize=30).head -= 6j - 3j

    integ = mo.graphics.Image("./resources/integ-mini.png")
    integ.set(pos=arrow1.last().midpoint(), height=1.25, alpha=0)
    integ = mo.Actor(integ)
    mainlayer.merge(integ, atFrame=time)
    integ.newendkey(20).set(alpha=1).pos += 1

    time = mation.lastID()
    formula2 = mo.graphics.Image("./resources/integ-f(x)-formula.png")
    formula2.set(
        pos=formula.last().pos, height=0.9*formula.last().height, alpha=0
        )
    formula2 = mo.Actor(formula2)
    mainlayer.merge(formula2, atFrame=time)
    formula2.newendkey(20).set(alpha=1).pos -= 6j

    mation.endDelayUntil(16*30)
    print("Show next integral:", mation.seconds())

    time = mation.lastID()
    arrow2 = mo.grid.Arrow().set(
        tail=formula2.last().pos-1.5j,
        width=6, color=violet, headSize=0
        )
    arrow2.length = 0
    arrow2 = mo.Actor(arrow2)
    mainlayer.append(arrow2)
    arrow2.newendkey(20).set(headSize=30).head -= 6j - 3j

    integ2 = integ.last().copy()
    integ2.set(pos=arrow2.last().midpoint(), alpha=0)
    integ2 = mo.Actor(integ2)
    mainlayer.merge(integ2, atFrame=time)
    integ2.newendkey(20).set(alpha=1).pos += 1

    time = mation.lastID()
    formula3 = mo.graphics.Image("./resources/integ2-f(x)-formula.png")
    formula3.set(
        pos=formula2.last().pos, height=formula2.last().height, alpha=0
        )
    formula3 = mo.Actor(formula3)
    mainlayer.merge(formula3, atFrame=time)
    formula3.newendkey(20).set(alpha=1).pos -= 6j

    mation.endDelayUntil(20*30)
    print("Show shortcut:", mation.seconds())

    carrow = mo.shapes.Spline()
    carrow.newNode((6.15+4.44j)) \
        .outhandleRel(-1, 2*(1-1j)) \
        .newNode((6.06-6.93j)) \
        .inhandleRel(-1, 2*(1+1j))
    carrow.set(
        width=arrow1.last().width, color=arrow1.last().color[:], end=0
        )
    carrow = carrow.toPath()
    carrow = mo.Actor(carrow)
    mainlayer.append(carrow)
    carrow.newendkey(30).set(end=1, headSize=30)

    imystery = mo.graphics.Image("./resources/integ-mystery.png")
    imystery.set(
        pos=mean(carrow.last().seq), height=2, alpha=0
        )
    imystery = mo.Actor(imystery)
    mainlayer.append(imystery)
    imystery.newendkey(20).set(alpha=1, align=[-1,0]).pos += 1

    mation.endDelayUntil(34.7*30)
    print("Say 'Yes':", mation.seconds())

    time = mation.lastID()
    yes = mo.Actor(mo.text.Text)
    yes.newkey(time).set(text="Yes!",
        pos=imystery.last().center,
        size=64, color=[1,0,0], alpha=0
        )
    yes.newendkey(20).set(alpha=1).pos += 2j
    mainlayer.merge(yes)

    mation.endDelayUntil()
    print("Show multiple integral equal to single integral:", mation.seconds())

    time = mation.lastID(36.5*30)
    actors = [actor for actor in mainlayer.actors if actor not in [title, imystery]]
    mo.actions.rollback(actors[::-1], stagger=3, duration=20)

    time = mation.lastID() - 15
    imystery.newkey(time)
    imystery.newendkey(30).set(pos=3).height *= 1.25

    nfold = mo.graphics.Image("./resources/n-fold-integ-eq.png")
    nfold.set(
        pos=imystery.last().pos-0.5, align=[1,0],
        height=imystery.last().height, alpha=0
        )
    nfold = mo.Actor(nfold)
    mainlayer.merge(nfold, atFrame=time)
    nfold.newendkey(30).alpha = 1




    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    # mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./00_intro.mp4", scale=1)


main()
