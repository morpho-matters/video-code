
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "11_playtime"


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # gridlayer.camera.first().moveBy(-(-13.06-2.5j)).zoomIn(4, focus=0)
    view = [-2,3/2*tau, -1,1]
    gridlayer.camera.first().view = view
    gridlayer.camera.first().rescaleHeight(16/9).moveBy(0.5+1.35j).zoomOut(1.15, focus=0)
    gridview = roundOut(gridlayer.camera.first().view)
    gridview[0] -= 3
    gridview[1] -= 5
    gridview[-1] += 1

    # Create mask for gridlayer
    gridlayer.mask = gridlayer.copy()
    gridlayer.mask.camera.first().visible = False
    mask = mo.grid.rect(gridview).set(width=2)
    mask = mo.Actor(mask)
    gridlayer.mask.merge(mask)

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid)
    grid.growIn(30)

    axes = mo.grid.axes(gridview,
        width=10, color=[0,0,0],
        ).set(zdepth=10)
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    axes.growIn(30)

    # time = mation.lastID()
    # box = gridview[:]
    # gridBG = mo.grid.rect(box).set(
    #     width=0, fill=[1,1,1], alphaFill=1
    #     )
    # gridBG = mo.Actor(gridBG)
    # gridlayer.merge(gridBG, atFrame=0, beforeActor=0)
    # gridBG.fadeIn(30)

    mation.endDelayUntil(3.25*30)
    print("Show polynomials:", mation.seconds())



    time = mation.lastID()
    red = (0.8,0,0)
    line = mo.graph.realgraph(lambda x: 2*x, 0, 3, steps=1).set(
        width=7, color=red
        )
    line = mo.Actor(line)
    gridlayer.merge(line)

    quad = mo.graph.realgraph(lambda x: x**2, 0, 3).set(
        width=7, color=redorange
        )
    quad = mo.Actor(quad)
    gridlayer.merge(quad)

    cubic = mo.graph.realgraph(lambda x: x**3/3, 0, 3, steps=75).set(
        width=7, color=violet
        )
    cubic = mo.Actor(cubic)
    gridlayer.merge(cubic)

    graphs = [line, quad, cubic]
    duration = 20
    stagger = 5
    for n, graph in enumerate(graphs):
        graph.newkey(time+n*stagger).end = graph.first().start
        graph.newendkey(duration).end = 1
        graph.first().visible = False

    mation.endDelay(10)

    pcurve = FuncFrac().set(
        p=0, func=lambda x: x**3/3, domain=[0,3],
        width=7, color=cubic.last().color[:],
        interpMethod=None, dash=(20,10)
        )
    pcurve.transition = drop
    pcurve = mo.Actor(pcurve)
    gridlayer.append(pcurve, timeOffset=1)
    pcurve.newendkey(25).set(
        p=1, color=quad.last().color, transition=toss
        )
    pcurve.newendkey(25).set(
        p=2, color=line.last().color, transition=drop
        )
    pcurve.newendkey(25, pcurve.key[-2].copy())
    pcurve.newendkey(25, pcurve.first().copy()).visible = False

    mation.endDelayUntil(8*30)
    print("Clean up polys and show sin(t) curve:", mation.seconds())

    time = mation.lastID()
    mo.action.shrinkOut([cubic, quad, line],
        atFrame=time, duration=20, stagger=4
        )

    mation.endDelay(10)

    time = mation.lastID()
    flabel = mo.graphics.MultiImage("./resources/f(t)-eq-sin(t).png").set(
        pos=(12.25+7.22j), height=1.1
        )
    flabel = mo.Actor(flabel)
    mainlayer.merge(flabel, atFrame=time)
    flabel.fadeIn(20, jump=2j)

    xruler = 12
    yticks = [4, -1]
    pad = 1

    base = mo.graphics.MultiImage("./resources/sin(t).png").set(
        pos=xruler+pad+1j*yticks[0], align=[-1,0], height=1
        )
    base = mo.Actor(base)
    mainlayer.merge(base)

    deriv = mo.graphics.MultiImage("./resources/cos(t).png").set(
        pos=xruler+pad+1j*yticks[1], align=[-1,0], height=base.last().height
        )
    deriv = mo.Actor(deriv)
    mainlayer.merge(deriv)

    # xcubed = mo.graphics.MultiImage("./resources/x3-over-3-violet.png").set(
    #     pos=xruler+pad+1j*yticks[2], align=[-1,0], height=1.45
    #     )
    # xcubed = mo.Actor(xcubed)
    # mainlayer.merge(xcubed)

    formulas = [base, deriv]
    mo.action.fadeIn(formulas, atFrame=time, duration=20, jump=2, stagger=5)

    ruler = mo.grid.Path([1j*yticks[0]+1j, 1j*yticks[-1]-1j])
    ruler.set(origin=xruler, width=4, color=[0,0,0])
    ruler = mo.Actor(ruler)
    mainlayer.merge(ruler, atFrame=time)
    ruler.growIn(30)

    ticks = ruler.last().copy()
    dx = 0.25
    ticks.seq = []
    for y in yticks:
        ticks.seq += [-dx+1j*y, dx+1j*y]
    ticks.origin = xruler
    ticks.deadends = {1,3,5}
    ticks = mo.Actor(ticks)
    mainlayer.merge(ticks, atFrame=time)
    ticks.growIn(30)


    Dbase = mo.graphics.MultiImage("./resources/0Dt-f(t).png").set(
        align=[1,0]
        )
    Dbase = mo.Actor(Dbase)
    Dbase.visible = False
    mainlayer.merge(Dbase)
    xruler2 = ruler.last().origin
    ymin, ymax = yticks[0], yticks[-1]
    grad = mo.color.Gradient({0:goodblue, 1:(0,0.6,0)})
    @mo.SkitParameters(p=3, alpha=0)
    class DerivTracker(mo.Skit):
        def makeFrame(self, index=None):
            p = self.p
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            color = grad.value(p)
            D = Dbase.time(index).copy()
            for img in D.figures:
                img.set(
                    pos=xruler2-0.75+1j*mo.lerp(ymin, ymax, p, start=0, end=1),
                    height=1).alpha *= alpha
            power = mo.text.Text(mo.text.formatNumber(p, decimal=2, rightDigits=2),
                pos=D.pos-2.7+0.57j, anchor_x=-1,
                size=38, color=redderorange, alpha=alpha
                )
            arrow = mo.grid.Arrow()
            arrow.head = xruler2+1j*D.pos.imag
            arrow.tail = arrow.head-1
            arrow.set(width=0, headSize=30, color=color, alpha=alpha)

            return mo.Frame([D, power, arrow])

    dtracker = DerivTracker(p=0)
    dtracker = mo.Actor(dtracker)
    mainlayer.merge(dtracker, atFrame=time)
    dtracker.fadeIn(20)

    sinebase = mo.graph.realgraph(math.sin, 0, gridview[1], steps=100).set(
        width=7, color=grad.value(0)
        )
    sinebase = mo.Actor(sinebase)
    gridlayer.merge(sinebase, atFrame=time)
    sinebase.growIn(30)

    mation.endDelayUntil(14.5*30)
    print("Encircle the lowerbound:", mation.seconds())

    time = mation.lastID()
    circ0 = mo.grid.ellipse((7.39+3.74j), 0.4, phase=pi/2, relative=True).edge().set(
        width=4, color=[0,0,1]
        )
    circ0 = mo.Actor(circ0)
    mainlayer.merge(circ0, atFrame=time)
    circ0.newendkey(20)
    circ0.first().set(alpha=0, transform=[[4,0],[0,4]])

    mation.endDelayUntil(18.5*30)
    print("Start varying the order:", mation.seconds())

    time = mation.lastID() + 1
    # mation.start = time   # BOOKMARK
    sinebase.newkey(time).alpha = 0.5
    sinebase.key(-2).static = True

    circ0.fadeOut(15, atFrame=time)

    # Puppet skit reacts to dtracker state
    fcurve = FuncFrac().set(
        p=0, func=math.sin, domain=[0,tau], width=7,
        interpMethod=None
        )
    @mo.SkitParameters(func=math.sin, domain=(0,tau), steps=100)
    class DerivCurve(mo.Skit):
        def makeFrame(self, index=None):
            func = self.func
            domain = self.domain
            steps = self.steps
            if index is None:
                index = mation.currentIndex

            p = dtracker.time(index).p
            color = tuple(grad.value(mo.lerp(0,1, p, start=0, end=1)))
            curve = fcurve.copy()
            curve.set(
                func=func, p=p, color=color, domain=domain, steps=steps
                )

            return curve

    dcurve = DerivCurve(domain=[0,gridview[1]])
    dcurve = mo.Actor(dcurve)
    gridlayer.merge(dcurve, atFrame=time)

    dtracker.newkey(time)
    dtracker.newendkey(75).p = 1

    time = mation.lastID() + 16.25*30  # TEMP
    while mation.lastID() < time:
        dtracker.newendkey(75, dtracker.key[-2].copy())

    print("Move over to the half-derivative:", mation.seconds())

    dtracker.newendkey(60).p = 0.5

    mation.endDelayUntil(47*30)
    print("Highlight the different peaks:", mation.seconds())

    time = mation.lastID()
    # Temp hide the sinebase
    sinebase.fadeOut(15, atFrame=time)

    peak1 = mo.grid.Path(gridview[:2]).set(
        width=5, color=[1,0,0], dash=[20,10],
        origin=0.85j
        )
    peak1 = mo.Actor(peak1)
    gridlayer.merge(peak1, atFrame=time)

    peak2 = peak1.last().copy().set(
        color=[0,0,1], origin=0.98j
        )
    peak2 = mo.Actor(peak2)
    gridlayer.merge(peak2, atFrame=time)

    mo.action.growIn([peak1, peak2], duration=30)

    mation.endDelayUntil(52*30)
    print("Switch to exponential:", mation.seconds())

    time = mation.lastID()
    mo.action.rollback([peak1, peak2], duration=20)

    dtracker.newkey(time)
    dtracker.newendkey(30).p = 0

    dcurve.newkey(dtracker.lastID()).visible = False
    sinebase.newkey(dtracker.lastID()).set(
        visible=True, alpha=1
        )

    mation.endDelay(15)

    time = mation.lastID()
    expbase = sinebase
    expbase.newkey(time)
    expbase.newendkey(30,
        mo.graph.realgraph(math.exp, 0, 2, steps=50).set(
            width=7, color=grad.value(0)
            )
        )

    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(30).moveBy(1.5j)

    flabel.newkey(time)
    flabel.newendkey(30).newSource("./resources/f(t)-eq-et.png").scaleByHeight()

    for label in [base, deriv]:
        label.newkey(time)
        label.newendkey(30).newSource("./resources/et.png").scaleByHeight()

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    fboxer = mo.gadgets.enbox(flabel.last().box(pad=0.25),
        width=5, color=[0,0,1], duration=20
        )
    mainlayer.merge(fboxer, atFrame=time)
    fboxer.shrinkOut(20, reverse=True)

    mation.endDelayUntil(30*minsec(1.015))
    print("Simult enbox both 'e^t' formulas:", mation.seconds())

    time = mation.lastID()
    boxers = []
    for label in [base, deriv]:
        boxer = mo.gadgets.enbox(label.last().box(pad=0.25),
            width=5,
            color=goodblue if label == base else [0,0.6,0],
            duration=20
            )
        mainlayer.merge(boxer, atFrame=time)
        boxers.append(boxer)

    mation.endDelayUntil(30*minsec(1.1225))
    print("Debox and zoom in:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut(boxers, duration=20)

    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(30).zoomIn(2, focus=(0.69+2.01j))

    # Enable mask
    gridlayer.mask.camera.newkey(time).visible = True

    time = mation.lastID()
    expbase.newkey(time).alpha = 0.5
    expbase.key(-2).static = True
    dcurve.newkey(time).set(
        func=math.exp, domain=[0,2], steps=100, visible=True
        )

    dtracker.newkey(time)
    dtracker.newendkey(90).p = 1

    mation.endDelay(10)

    dtracker.newendkey(90).p = 0

    mation.endDelay(10)

    dtracker.newendkey(45).p = 1/2

    time = mation.lastID()
    vasm = mo.text.paragraph("Vertical\nasymptote??",
        mainlayer.camera.last().view, mation.windowShape,
        pos=(-11.78+6.69j), align=[-1,0], flush=-1,
        size=56, color=[1,0,0],
        background=mation.background, backAlpha=0.65, backPad=0.25
        )
    vasm = mo.Actor(vasm)
    mainlayer.merge(vasm, atFrame=time)
    print("Highlight vertical asymptote:", mation.seconds())
    vasm.fadeIn(20, jump=3-2j)

    arrow = mo.shapes.Spline() \
        .newNode(-12.3+6.57j, oo, -1) \
        .newNode((-14.54+9.85j), 0.25-3j) \
        .toPath().set(
            width=5, color=[1,0,0], headSize=25
            )
    arrow = mo.Actor(arrow)
    mainlayer.append(arrow)
    arrow.growIn(20)

    mation.endDelayUntil(30*minsec(1.2575))
    print("Return to p = 0 and zoom back out:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([arrow, vasm], duration=20, atFrame=time)

    dtracker.newkey(time)
    dtracker.newendkey(45).p = 0

    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(45, gridlayer.camera.key[-3].copy())

    time = mation.lastID()
    gridlayer.mask.camera.newkey(time).visible = False

    mation.endDelayUntil(30*minsec(1.29))
    print("Encircle the zero lowerbound:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    circ0.newkey(time, circ0.first().copy())
    circ0.newendkey(20, circ0.key[1].copy())

    mation.endDelayUntil(30*minsec(1.40))
    print("Show integral curve:", mation.seconds())

    time = mation.lastID()
    integ = mo.graphics.MultiImage("./resources/integ0-exp.png").set(
        pos=xruler-4.6j, height=2.25
        )
    integ = mo.Actor(integ)
    mainlayer.merge(integ, atFrame=time)
    integ.fadeIn(20, jump=2j)

    iboxer = mo.gadgets.enbox(integ.last().box(pad=0.25),
        width=5, color=[1,0,0], duration=20
        )
    mainlayer.append(iboxer)

    mation.endDelay(15)

    time = mation.lastID()
    area = mo.calculus.IntegralArea(math.exp, 0, 0,
        strokeWeight=0, fill=violet, alpha=0.5
        )
    area = mo.Actor(area)
    gridlayer.merge(area, atFrame=time, beforeActor=dcurve)
    area.newendkey(60).end = 2.25

    igraph = mo.graph.realgraph(lambda x: math.exp(x)-1, 0, area.last().end).set(
        width=7, color=[1,0,0]
        )
    igraph = mo.Actor(igraph)
    gridlayer.merge(igraph, atFrame=time)
    igraph.growIn(60)

    mation.endDelayUntil(30*minsec(1.4915))
    print("Show higher integrals:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([area, iboxer, circ0], 20, atFrame=time)

    time = mation.lastID()
    iigraph = mo.graph.realgraph(lambda x: math.exp(x)-x-1, 0, 3).set(
        width=7, color=redderorange
        )
    iigraph = mo.Actor(iigraph)
    gridlayer.merge(iigraph, atFrame=time)
    iigraph.growIn(30)

    iiigraph = mo.graph.realgraph(lambda x: math.exp(x)-x**2/2-x-1, 0, 3).set(
        width=7, color=violet
        )
    iiigraph = mo.Actor(iiigraph)
    gridlayer.append(iiigraph)
    iiigraph.growIn(30)

    mation.endDelayUntil(30*minsec(1.56))
    print("Fade away integral curves:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([iiigraph, iigraph, igraph], 20, atFrame=time)

    mation.endDelayUntil(30*minsec(2.00))
    print("Extend the graph to -oo:", mation.seconds())

    time = mation.lastID()
    # Re-enable the mask
    gridlayer.mask.camera.newkey(time).visible = True

    # Scoot the view
    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(45).moveBy(-3)

    # Extend graph
    dcurve.newkey(time)
    dcurve.newendkey(45).domain[0] = -5

    integ.newkey(time)
    integ.newendkey(20).newSource("./resources/integ-exp.png").scaleByHeight()

    time = mation.lastID()
    circoo = mo.grid.ellipse(10.3-5.56j, 0.8, 0.4, phase=pi/2, relative=True).edge().set(
        width=4, color=[0,0,1]
        )
    circoo = mo.Actor(circoo)
    mainlayer.merge(circoo, atFrame=time)
    circoo.newendkey(20)
    circoo.key[-2].set(end=0, transform=[[5,0],[0,5]]).width *= 1.5

    mation.endDelayUntil(30*minsec(2.1475))
    print("Change derivative symbol lowerbound to -oo:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([circoo, integ], 20, atFrame=time)

    # Morph Derivative symbol to have lowerbound -oo
    time = mation.lastID()
    Dbase.newkey(time)
    Dbase.newendkey(20).newSource("./resources/-ooDt-f(t).png").scaleByHeight()

    time = mation.lastID()
    circ0.newkey(time,
        mo.grid.ellipse((6.94+3.7j), 0.8, 0.4, phase=pi/2, relative=True).edge().set(
            width=4, color=[0,0,1]
            )
        )
    circ0.newendkey(20)
    circ0.key[-2].set(end=0, transform=[[5,0],[0,5]]).width *= 1.5

    mation.endDelayUntil(30*minsec(2.195))
    print("Start varying p again:", mation.seconds())

    circ0.fadeOut(20)

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    dtracker.newkey(time)
    dtracker.newendkey(60).p = 1
    dtracker.newendkey(60).p = 0





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./11_playtime.mp4", scale=1)


main()
