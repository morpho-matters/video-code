
import morpholib as morpho
mo = morpho
import morpholib.graph
from morpholib.tools.basics import *

import math, cmath, random
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import fsolve
from scipy.misc import derivative
from scipy.interpolate import interp1d
from scipy.special import gamma

from derivagrals import *

@mo.SkitParameters(
    p=0, func=math.sin, domain=(0,tau), graphDomain=(0,tau),
    interpSteps=100, steps=50, offset=0,
    abspad=0, relpad=0.004,
    width=5, color=(0,0.6,0), alpha=1, dash=(),
    outlineWidth=0, outlineColor=(0,0,0), outlineAlpha=1
    )
class FuncFrac(mo.Skit):
    def __init__(self):
        super().__init__()

        self.NonTweenable("linkDomains", True)
        self.NonTweenable("interpMethod", "cubic")
        self.NonTweenable("points", None)

    def makeFrame(self):
        p = self.p
        func = self.func
        domain = self.domain
        interpSteps = round(self.interpSteps)
        steps = round(self.steps)
        offset = round(self.offset)
        abspad = self.abspad
        relpad = self.relpad
        width = self.width
        color = self.color
        alpha = self.alpha
        dash = self.dash
        outlineWidth = self.outlineWidth
        outlineColor = self.outlineColor
        outlineAlpha = self.outlineAlpha
        interpMethod = self.interpMethod
        # Adjust domain according to padding values
        tmin, tmax = domain
        pad = abspad + relpad*(tmax-tmin)
        domain = (tmin+pad, tmax)
        if self.linkDomains:
            graphDomain = domain
        else:
            graphDomain = self.graphDomain

        # df = derivagral(func, p=p, a=tmin, domain=domain,
        #     steps=interpSteps, offset=offset, interpMethod=interpMethod)
        df = self.makeFunc()
        graph = mo.graph.realgraph(df, *graphDomain, steps=steps).set(
            width=width, color=color, alpha=alpha, dash=dash,
            outlineWidth=outlineWidth, outlineColor=outlineColor,
            outlineAlpha=outlineAlpha
            )

        return graph

    def makeFunc(self):
        p = self.p
        func = self.func
        domain = self.domain
        interpSteps = round(self.interpSteps)
        offset = round(self.offset)
        interpMethod = self.interpMethod
        points = self.points

        return derivagral(func, p=p, a=domain[0], domain=domain,
            steps=interpSteps, offset=offset, interpMethod=interpMethod,
            points=points)
