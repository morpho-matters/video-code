
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad
from scipy.special import gamma

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))
darkgreen = dgreen = tuple(mo.color.parseHexColor("008000"))
beet = tuple(mo.color.parseHexColor("80003a"))
brown = tuple(mo.color.parseHexColor("5c2912"))


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "19_counterpoint1"



def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    gridlayer2 = mainlayer.copy()
    mation = morpho.Animation([gridlayer, gridlayer2, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightgreen

    LABELSIZE = 0.7

    movement = (-5-6.5j)
    gridlayer.camera.first().moveBy(-movement).zoomIn(1.25, focus=0)
    gridlayer2.camera.first().zoomIn(1.25, focus=0)
    gridview = [0,9, 0,7]

    # gridtop = gridlayer.copy()
    # gridtop.mask = None
    # mation.merge(gridtop, beforeLayer=mainlayer)

    gridlayer.mask = gridlayer.copy()
    gridbox = mo.grid.rect(gridview, pad=1.5)
    gridbox = mo.Actor(gridbox)
    gridlayer.mask.merge(gridbox)
    gridlayer.mask.camera.first().visible = False

    hhformula = mo.graphics.MultiImage("./resources/double-half-integ.png").set(
        pos=3j, height=2.5
        )
    hhformula = mo.Actor(hhformula)
    mainlayer.merge(hhformula)
    hhformula.fadeIn(20, jump=2j)

    mation.endDelayUntil(8.5*30)
    print("Show graph:", mation.seconds())

    time = mation.lastID()
    hhformula.newendkey(30).pos = 7.5j

    curtain = mo.grid.rect(mainlayer.camera.last().view).set(
        width=0, fill=mation.background[:]
        )
    curtain = mo.Actor(curtain)
    mainlayer.merge(curtain, atFrame=time, beforeActor=0)
    curtain.fadeOut(30)

    axes = mo.grid.axes(gridview).set(
        width=10, color=[0,0,0],
        zdepth=10
        )
    axes = mo.Actor(axes)
    gridlayer.merge(axes, atFrame=time)

    flabel = mo.graphics.MultiImage("./resources/f(x).png").set(
        pos=axes.last().seq[-1]+0.25j, align=[0,-1], height=0.9
        )
    flabel = mo.Actor(flabel)
    gridlayer.merge(flabel, atFrame=time)

    tend = 7.5
    delta = 0.001
    graph = mo.grid.line(delta, tend-delta, steps=100).set(
        width=6, color=violet
        )
    graph = mo.Actor(graph)
    graph.visible = False
    gridlayer.merge(graph, atFrame=time)

    rightlabel = mo.graphics.MultiImage("./resources/wave-t.png").set(
        pos=tend, align=[0,1.5],
        height=LABELSIZE*1.35
        )
    rightlabel = mo.Actor(rightlabel)
    rightlabel.visible = False
    gridlayer.merge(rightlabel, atFrame=time)

    rectCount = 20
    rect_strokeWeight = 3
    settings = dict(rectCount=rectCount,
        align=0, strokeWeight=rect_strokeWeight,
        fill=(0,1,0), alphaFill=0.5,
        transition=quadease)
    dx = (tend-2*delta)/rectCount

    def f(x):
        return (4*x**3-51*x**2+180*x)/35

    def xtilde(x0, t):
        return 2/math.sqrt(math.pi)*(math.sqrt(t) - math.sqrt(t-x0))

    def accordion(s, t=tend):
        x,y = s.real, s.imag
        X = xtilde(x, t)
        Y = y
        return complex(X,Y)

    xscale = 2.25
    transform = mo.array([[xscale, 0], [0,1]])

    # Puppet skit updates the right graph reacting to tvalue
    @mo.SkitParameters(t=tend-0.01, accordion=accordion, xtilde=xtilde)
    class LeftGraph(mo.Skit):
        # def __init__(self):
        #     super().__init__()
        #     self.NonTweenable("accordion", accordion)
        #     self.NonTweenable("xtilde", xtilde)

        @staticmethod
        def makePlot(t, xtilde, accordion, dx=dx):
            t_tilde = xtilde(t, t)

            mygraph = mo.grid.line(delta, t-delta, steps=100).set(
                width=6, color=graph.last().color[:]
                )
            mygraph.insertNodesUniformly(10, [0.98,1])
            mygraph = mygraph.fimage(lambda s: complex(s.real, f(s.real)))
            mygraph = mygraph.fimage(lambda s: accordion(s,t))
            mygraph.seq.append(mygraph.seq[-1].real)

            area = mygraph.copy().set(
                width=0, fill=mygraph.color[:], alphaFill=0.5
                )
            area.seq.extend([area.seq[0].real])
            area.close()

            tlabel = rightlabel.last().copy().set(visible=True)
            tlabel.pos = t_tilde + 1j*tlabel.pos.imag

            vlines = mo.grid.mathgrid(
                view=[delta+dx, t-delta, 0, 1],
                dx=dx, dy=1, steps=1,
                vcolor=[0,0,0], vwidth=rect_strokeWeight,
                hwidth=0, axes=False, BGgrid=False, midlines=False
                ).fimage(lambda s: s.real+1j*s.imag*f(s.real))
            vlines = vlines.fimage(lambda s: accordion(s,t))

            frm = mo.Frame([area, vlines, mygraph, tlabel])
            mat = mo.matrix.Mat(transform)
            frm = frm.fimage(lambda s: mat*s)
            return frm

        def makeFrame(self):
            t = self.t

            return self.makePlot(t, xtilde, accordion)


    lgraph = LeftGraph()
    lgraph = mo.Actor(lgraph)
    gridlayer.merge(lgraph, atFrame=time)

    mation.endDelay(30)
    print("Vary t some:", mation.seconds())

    time = mation.lastID()
    lgraph.newkey(time)
    lgraph.newendkey(60).t = 2
    mation.endDelay(20)
    lgraph.newendkey(60).t = lgraph.first().t

    mation.endDelayUntil(20*30)
    print("Morph formula to mu_t(x) formula:", mation.seconds())

    time = mation.lastID()
    formula = hhformula
    formula.newkey(time)
    formula.newendkey(20).newSource("./resources/half-integral-transformed-swapped.png").scaleByHeight()

    time = mation.lastID()
    mutx = mo.graphics.MultiImage("./resources/mutx-def.png").set(
        pos=(7+7.48j), align=[-1,0], height=formula.last().height
        )
    mutx = mo.Actor(mutx)
    mainlayer.merge(mutx, atFrame=time)
    mutx.fadeIn(20, jump=3)

    mation.endDelayUntil(25*30)
    print("'Can be anything':", mation.seconds())

    time = mation.lastID()
    a = 10.78+6j
    b = (15.52+6j)
    ubrace = mo.graphics.MultiImage("./resources/ubrace1.png").set(
        pos=mean([a,b]), align=[0,1],
        width=abs(b-a), scale_x=0, scale_y=1
        )
    ubrace = mo.Actor(ubrace)
    mainlayer.merge(ubrace, atFrame=time)
    ubrace.newendkey(20).scale_x = 1

    canbe = mo.text.Text("can be anything",
        pos=ubrace.last().pos-1.25j,
        size=52, color=beet
        )
    canbe = mo.Actor(canbe)
    mainlayer.merge(canbe, atFrame=time)
    canbe.fadeIn(20, jump=-1j)

    mation.endDelayUntil(28*30)
    print("Morph to Laplace kernel:", mation.seconds())

    def laplaceKernel(t,x):
        return math.exp(-t*x)

    def laplace_xtilde(x0, t, adjust=1/20):
        return (1-math.exp(-t*adjust*x0))/(adjust*t)

    def laplaceAccordion(s, t=tend):
        x,y = s.real, s.imag
        X = laplace_xtilde(x, t)
        Y = y
        return complex(X,Y)

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    lgraph.newkey(time).visible = False
    plot = lgraph.last().makeFrame()
    plot = mo.Actor(plot)
    gridlayer.merge(plot, atFrame=time)
    # dx2 = (8.5)/rectCount
    plot.newendkey(30, LeftGraph.makePlot(tend-0.01, laplace_xtilde, laplaceAccordion))

    # Morph mu formula
    mutx.newkey(time)
    mutx.newendkey(30).newSource("./resources/laplace-kernel.png").scaleByHeight()
    mutx.last().height *= 0.45
    mutx.last().set(align=[0,0]).pos += 5

    # Fade ubrace and label
    mo.action.fadeOut([ubrace, canbe], atFrame=time, duration=20)

    time = mation.lastID()
    klabel = mo.text.Text("Laplace kernel",
        pos=mutx.last().pos-1.25j,
        size=52, color=redderorange
        )
    klabel = mo.Actor(klabel)
    mainlayer.merge(klabel, atFrame=time)
    klabel.fadeIn(20, jump=-1.25j)




    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./19_counterpoint1.mp4", scale=1)


main()
