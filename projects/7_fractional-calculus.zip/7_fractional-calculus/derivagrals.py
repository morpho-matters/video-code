
import math, cmath, random
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import fsolve
from scipy.misc import derivative
from scipy.interpolate import interp1d
from scipy.special import gamma


# Decorator makes a function that returns np.arrays return
# pure python lists or raw datatypes.
def pythonize(f):
    return lambda *args, **kwargs: f(*args, **kwargs).tolist()

# Returns the Riemann-Liouville fractional integral of a function.
#
# INPUTS
# f = Function (real to real)
# domain = Domain [tmin, tmax] on which to compute sample points
#          for the fractional integral if using an interpolation
#          model (see `interpMethod`).
# p = Fractional integration order. Must be positive.
# a = Integration lower limit. Default: lowerbound of domain
# steps = Number of interpolation steps to use in approximating
#         the fractional integral (see `interpMethod`).
#         Default: 50
# KEYWORD-ONLY INPUTS
# intreltol = Integration relative tolerance. Default: 1.49e-08
# intabstol = Integration absolute tolerance. Default: 1.49e-08
# limit = quad() limit parameter. Default: 50.
# interpMethod = Interpolation method.
#       Default: None (meaning don't use an interpolation model)
#       When set to a string like "cubic", the returned
#       function will compute values according to an
#       interpolation of pre-computed (t,y) pairs.
#       When set to None, it will
#       instead perform the numerical integration from scratch
#       each time it's evaluated. This gives a more accurate
#       result, but may be slower. Generally, it should be set
#       to None only if high precision matters, or if you'll
#       be using the fractional integral as an intermediate
#       function in other numerical methods (using the
#       interpolation method seems to really confuse numerical
#       algorithms further down the pipeline).
# _pythonize = Boolean indicating whether to force the outputs
#              of the returned fractional integral function to
#              be pure python types instead of np.arrays.
#              Default: True
def fracIntegrate(f, p, a, domain=None, steps=50,
    *, intreltol=1.49e-08, intabstol=1.49e-08, points=None,
    limit=50, interpMethod=None, _pythonize=True):

    if p == 0:
        return f
    elif p < 0:
        raise ValueError("Fractional order p must be positive.")

    if points is not None and len(points) > 2:
        raise ValueError("`points` must have 2 or fewer elements.")

    # tmin, tmax = domain
    # if a is None:
    #     a = tmin
    # elif a > tmin:
    #     raise ValueError("`a` cannot be higher than the domain lowerbound.")

    coeff = 1/gamma(p)
    def integral(t, a=a):
        if t == a:
            return 0

        return quad(
            f, a, t,
            epsrel=intreltol, epsabs=intabstol, limit=limit,
            weight="alg", wvar=(0, p-1)
            )[0]

    if points is not None:
        minpoint, maxpoint = min(points), max(points)

        integral_orig = integral

        def integral(t):
            if t <= minpoint:
                return integral_orig(t, a=a)

            if minpoint < t < maxpoint:
                m = (minpoint+t)/2
            else:
                m = (maxpoint+t)/2
            val1 = quad(
                lambda x: f(x)*(t-x)**(p-1), a, m,
                epsrel=intreltol, epsabs=intabstol, limit=limit,
                points=points
                # weight="alg", wvar=(0, p-1)
                )[0]
            val2 = integral_orig(t, a=m)
            val2 = quad(
                f, m, t,
                epsrel=intreltol, epsabs=intabstol, limit=limit,
                weight="alg", wvar=(0, p-1)
                )[0]
            return val1 + val2

    if interpMethod is None or steps <= 0:
        def F(t): return coeff*integral(t)
    else:
        # If using interpolation, the `domain` parameter must be specified.
        if domain is None:
            raise TypeError("`domain` must be specified if using interpolation.")
        tmin, tmax = domain
        # Check that a is strictly to the left of the domain
        if a >= tmin:
            raise ValueError("`a` must be strictly less than the domain lowerbound.")

        tspace = np.linspace(tmin, tmax, steps+1)
        yspace = np.zeros(tspace.shape)
        for n,t in enumerate(tspace):
            # def integrand(x, t=t):
            #     return (t-x)**(p-1) * f(x)
            if a == t:
                yspace[n] = 0
                continue
            yspace[n] = integral(t)
        yspace *= coeff
        F = interp1d(tspace, yspace, kind=interpMethod, fill_value="extrapolate")

    if _pythonize:
        F = pythonize(F)
    return F

# Returns the Riemann-Liouville fractional derivative or
# integral of a function.
#
# INPUTS
# f = Function (real to real)
# p = Fractional order
#     (positive p are derivatives, negative p are integrals)
# a = Integration lower limit.
# domain = Domain [tmin, tmax] on which to compute derivagral
#          if using an interpolation model (see `interpMethod`).
# steps = Number of interpolation steps to use in approximating
#         the derivagral (see `interpMethod`). Default: 50
# KEYWORD-ONLY INPUTS
# offset = Nonnegative integer added to the used fractional
#          integral order when computing a fractional derivative.
#          The fractional derivative is computed like this:
#          D^k J^alpha f(t)
#          where k = ceil(p) + offset and alpha = k - p.
#          Using an offset greater than 0 removes a singularity
#          from the fractional integration step (J^alpha) and may
#          reduce artifacts in the returned function at the cost
#          of needing to compute `offset`-many extra derivatives.
#          However, non-zero offsets can break derivagral
#          compositions, and can make subsequent numerical
#          approximations behave unpredictably, so it's probably
#          best to only use a non-zero offset if you notice
#          obvious artifacts in the derivagral.
#          Default: offset = 0
# intreltol = Integration relative tolerance. Default: 1.49e-08
# intabstol = Integration absolute tolerance. Default: 1.49e-08
# limit = quad() limit parameter. Default: 50.
# interpMethod = Interpolation method. Default: None
# _pythonize = Boolean indicating whether to force the outputs
#              of the returned derivagral function to
#              be pure python types instead of np.arrays.
#              Default: True
def derivagral(f, p, a, domain=None, steps=50,
    *, offset=0, dt=1e-6, intreltol=1.49e-08, intabstol=1.49e-08,
    points=None, limit=50, interpMethod=None, _pythonize=True):

    # Compute values of constants
    if p < 0:  # Integral case
        k = offset
        alpha = -p + offset
    elif p == int(p):
        k = int(p)
        alpha = 0
    else:
        if offset != int(offset):
            raise ValueError("offset value must be a integer.")
        k = math.ceil(p) + offset
        alpha = k - p

    if alpha == 0:
        F = f
    else:
        # Calculate fractional integral function first
        F = fracIntegrate(f, alpha, a, domain, steps,
            intreltol=intreltol, intabstol=intabstol, points=points,
            limit=limit, interpMethod=interpMethod, _pythonize=False
            )

    if k > 0:
        # tmin, tmax = domain
        # dt = dfactor*abs(tmax - tmin)
        order = max(k+1, 3)
        if order % 2 == 0:
            order += 1
        df = lambda t: derivative(F, t, dx=dt, n=k, order=order)
    else:
        df = F

    if _pythonize and df != f:
        return lambda t: df(t).tolist()
    else:
        return df
