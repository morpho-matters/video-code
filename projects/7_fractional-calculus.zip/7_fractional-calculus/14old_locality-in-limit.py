
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "14_locality-in-limit"


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # gridlayer.camera.first().moveBy(-(-13.06-2.5j)).zoomIn(4, focus=0)
    view = [-5,5, -1,3]
    gridlayer.camera.first().view = view
    gridlayer.camera.first().rescaleHeight(16/9)
    gridview = roundOut(gridlayer.camera.first().view)
    gridview[-1] += 2

    # # Create mask for gridlayer
    # gridlayer.mask = gridlayer.copy()
    # gridlayer.mask.camera.first().visible = False
    # mask = mo.grid.rect(gridview).set(width=2)
    # mask = mo.Actor(mask)
    # gridlayer.mask.merge(mask)

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid)
    grid.growIn(30)

    axes = mo.grid.axes(gridview,
        width=10, color=[0,0,0],
        ).set(zdepth=10)
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    axes.growIn(30)

    @mo.SkitParameters(func=lambda x: x, start=0, end=1,
        strokeWeight=3, color=(0,0,0), alpha=1, steps=300
        )
    class Graph(mo.Skit):
        def makeFrame(self):
            func = self.func
            start = self.start
            end = self.end
            strokeWeight = self.strokeWeight
            color = self.color
            alpha = self.alpha
            steps = round(self.steps)

            graph = mo.graph.realgraph(func, start, end, steps=steps)
            graph.set(width=strokeWeight, color=color, alpha=alpha)

            return graph

    def basefunc(x):
        return 2.5*math.exp(-(x-1)**2/4)
    basecurve = Graph(
        func=basefunc, start=gridview[0], end=gridview[0],
        strokeWeight=7, color=goodblue
        )
    basecurve = mo.Actor(basecurve)
    gridlayer.append(basecurve)
    basecurve.newendkey(45).end = gridview[1]


    mation.endDelayUntil()
    # print("'d/dt is a local operator':", mation.seconds())

    time = mation.lastID()
    local = mo.graphics.MultiImage("./resources/local-operator.png").set(
        pos=(11.83+6.61j), height=2,
        background=mation.background, backAlpha=0.65, backPad=0.25
        )
    local = mo.Actor(local)
    mainlayer.merge(local, atFrame=time)
    local.fadeIn(20, jump=2j)

    mation.endDelayUntil()
    # print("Show tangent line and curtain:", mation.seconds())

    @mo.SkitParameters(
        func=basefunc,
        t=0, length=0, alpha=1, width=6, color=(1,0,0),
        ptFill=(1,1,0), ptAlpha=0
        )
    class TangentLine(morpho.Skit):
        def makeFrame(self):
            # t will represent the input to the function f
            func = self.func
            t = self.t
            length = self.length
            alpha = self.alpha
            width = self.width
            color = self.color
            ptFill = self.ptFill
            ptAlpha = self.ptAlpha

            figs = []

            x = t
            y = func(t)
            pos = complex(x,y)

            # Initialize tangent line to be a horizontal
            # line segment of length 4 centered at the
            # origin
            if length != 0:
                line = morpho.grid.Path([-length/2, length/2])
                line.color = color
                line.alpha = alpha
                line.width = width

                # Compute derivative
                slope = derivative(func, t, dx=1e-4).tolist()
                # Convert into an angle and set it as the rotation
                # of the line segment
                angle = math.atan(slope)
                line.rotation = angle

                # Position the tangent line at the tangent point
                line.origin = x + 1j*y

                figs.append(line)

            if ptAlpha > 0:
                pt = mo.grid.Point(pos).set(
                    size=15, strokeWeight=2, fill=ptFill,
                    alpha=alpha*ptAlpha
                    )
                figs.append(pt)

            return morpho.Frame(figs)

    time = mation.lastID()
    target = 1.33
    tanline = TangentLine(t=target)
    tanline = mo.Actor(tanline)
    gridlayer.merge(tanline, atFrame=time)
    radius = 0.65
    tanline.newendkey(20).set(length=2*radius, ptAlpha=1)

    mation.endDelay(30)

    time = mation.lastID()
    # Hide the "local operator" label
    local.fadeOut(20, time)

    curtainbox1 = gridview[:]
    curtainbox1[1] = target - radius
    curtain1 = mo.grid.rect(curtainbox1).set(
        width=0, fill=[0,0,0], alpha=0.5, origin=-6.5
        )
    curtain1 = mo.Actor(curtain1)
    gridlayer.merge(curtain1, atFrame=time)
    curtain1.newendkey(30).origin = 0

    curtainbox2 = gridview[:]
    curtainbox2[0] = target + radius
    curtain2 = mo.grid.rect(curtainbox2).set(
        width=0, fill=[0,0,0], alpha=0.5,
        origin=-curtain1.first().origin
        )
    curtain2 = mo.Actor(curtain2)
    gridlayer.merge(curtain2, atFrame=time)
    curtain2.newendkey(30).origin = 0

    mation.endDelayUntil()
    # print("Make curve roil:", mation.seconds())

    def roiler(t, f, phi, amp=0.5, buf=0.25):
        if abs(t-target) <= radius:
            return 0
        amt = amp*math.sin(f/2*t + phi)**2
        if abs(t-target) <= radius+buf:
            amt *= mo.lerp(0, 1, abs(t-target), start=radius, end=radius+buf)
        return amt

    def generateRandomRoiler():
        amp = random.random()*0.8
        f = 5 + 3*random.random()
        phi = tau*random.random()
        return lambda t: roiler(t, f, phi, amp)

    time = mation.lastID()
    basecurve.newkey(time)

    time = mation.lastID() + 4*30  # TBD
    random.seed(18)
    while basecurve.lastID() < time:
        roil1 = generateRandomRoiler()
        roil2 = generateRandomRoiler()
        basecurve.newendkey(10).func = lambda t, roil1=roil1, roil2=roil2: basefunc(t) + roil1(t) + roil2(t)

    # print("Revert to original scene and draw half-deriv:", mation.seconds())

    time = mation.lastID()
    basecurve.newkey(time)
    basecurve.newendkey(10, basecurve.key[1].copy())

    mo.action.rollback([curtain1, curtain2], 30, atFrame=time)
    tanline.fadeOut(30, atFrame=time)

    mation.endDelay(15)

    time = mation.lastID()
    dcurve_base = FuncFrac().set(
        p=0, func=basefunc, domain=gridview[:2], steps=300,
        width=7, color=basecurve.last().color[:],
        interpMethod=None, relpad=0.002
        )
    dcurve_base = mo.Actor(dcurve_base)
    dcurve_base.visible = False
    gridlayer.merge(dcurve_base)

    grad = mo.color.Gradient({
            0: basecurve.last().color[:],
            1: [1,0,0]
        })

    # Puppet skit reacts to basecurve's current function
    @mo.SkitParameters(p=0, alpha=1)
    class DerivCurve(mo.Skit):
        def makeFrame(self, index=None):
            p = self.p
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            func = basecurve.time(index).func
            dcurve = dcurve_base.time(index).copy()
            dcurve.func = func
            dcurve.p = p
            dcurve.color = grad.value(mo.lerp(0,1,p,start=0, end=1/2))
            dcurve.alpha = alpha

            return dcurve

    dcurve = DerivCurve()
    dcurve = mo.Actor(dcurve)
    gridlayer.merge(dcurve, atFrame=time)
    dcurve.newendkey(20).set(p=1/2)







    ### ABOVE IS PRELIM ###

    mation.start = mation.lastID()

    # dcurve.visible = False  ### TEMP!!!

    time = mation.lastID()
    curtains = [curtain1, curtain2]
    for curtain in curtains:
        curtain.newkey(time, curtain.key[1].copy())

    # Puppet skit reacts to current dcurve p-value
    @mo.SkitParameters(pos=(-13+7.69j), alpha=1)
    class PTracker(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex
            pos = self.pos
            alpha = self.alpha

            p = dcurve.time(index).p

            ptxt = mo.text.formatNumber(p, decimal=2, rightDigits=2)
            label = mo.text.paragraph(
                [mo.text.Text("Derivative order", color=[0,0,0]),
                mo.text.Text(" p  ", italic=True, color=redderorange),
                mo.text.Text(f"= {ptxt}", color=redderorange)],
                mainlayer.camera.time(index).view, mation.windowShape,
                pos=pos, align=[-1,0], size=56,
                background=[1,1,1], backPad=0.25, backAlpha=0.85
                )

            return label

    ptracker = PTracker()
    ptracker = mo.Actor(ptracker)
    mainlayer.merge(ptracker, atFrame=time)

    basecurve.newkey(time)
    dcurve_base.newkey(time).points = [target-radius, target+radius]

    time = mation.lastID() + 5.25*30  # TBD
    random.seed(18)
    while basecurve.lastID() < time:
        roil1 = generateRandomRoiler()
        roil2 = generateRandomRoiler()
        basecurve.newendkey(10).func = lambda t, roil1=roil1, roil2=roil2: basefunc(t) + roil1(t) + roil2(t)

    time = mation.lastID()
    print("Start moving p toward 1:", mation.seconds())
    # mation.start = time  # BOOKMARK
    dcurve.newkey(time)
    dcurve.newendkey(90).p = 1

    dcurve_base.newkey(dcurve.lastID()).points = None

    # mation.start = mation.lastID()  # BOOKMARK

    time = mation.lastID() + 3.25*30  # TBD
    while basecurve.lastID() < time:
        roil1 = generateRandomRoiler()
        roil2 = generateRandomRoiler()
        basecurve.newendkey(10).func = lambda t, roil1=roil1, roil2=roil2: basefunc(t) + roil1(t) + roil2(t)




    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./14_locality-in-limit.mp4", scale=1)


main()
