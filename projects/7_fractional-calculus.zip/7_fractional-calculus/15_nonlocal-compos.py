
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "15_nonlocal-compos"


@mo.SkitParameters(func=lambda x: x, start=0, end=1,
    strokeWeight=3, color=(0,0,0), alpha=1, steps=100
    )
class Graph(mo.Skit):
    def makeFrame(self):
        func = self.func
        start = self.start
        end = self.end
        strokeWeight = self.strokeWeight
        color = self.color
        alpha = self.alpha
        steps = round(self.steps)

        graph = mo.graph.realgraph(func, start, end, steps=steps)
        graph.set(width=strokeWeight, color=color, alpha=alpha)

        return graph


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer1 = mainlayer.copy()
    gridlayer2 = mainlayer.copy()
    mation = morpho.Animation([gridlayer1, gridlayer2, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    gridlayer1.mask = mainlayer.copy()
    gridlayer2.mask = mainlayer.copy()

    mainview = mainlayer.camera.first().view
    sep = 0.8
    view1 = mainview[:]
    view1[1] = 0 - sep
    view2 = mainview[:]
    view2[0] = 0 + sep

    box1 = mo.grid.rect(view1)
    box1 = mo.Actor(box1)
    gridlayer1.mask.merge(box1)

    box2 = mo.grid.rect(view2)
    box2 = mo.Actor(box2)
    gridlayer2.mask.merge(box2)

    # gridlayer.camera.first().moveBy(-(-13.06-2.5j)).zoomIn(4, focus=0)
    view = [-3.5*tau, 3.5*tau, -1, 1]
    gridlayer1.camera.first().view = view
    gridlayer1.camera.first().rescaleHeight(16/9).moveBy(view[1]/2).zoomIn(2.5, focus=0)

    gridview1 = roundOut([-5, 5, -5, 5])
    grid1 = mo.grid.mathgrid(
        view=gridview1,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid1 = mo.Actor(grid1)
    # gridlayer1.merge(grid1)

    axes1 = mo.grid.axes(gridview1,
        width=10, color=[0,0,0],
        ).set(zdepth=10)
    axes1 = mo.Actor(axes1)
    gridlayer1.merge(axes1)

    gridlayer2.camera.first().view = view[:]
    gridlayer2.camera.first().rescaleHeight(16/9).moveBy(view[0]/2).zoomIn(2.5, focus=0)

    grid2 = grid1.copy()
    # gridlayer2.merge(grid2)

    axes2 = axes1.copy()
    gridlayer2.merge(axes2)

    # divider = mo.grid.Path([-11j, 11j]).set(
    #     width=15,
    #     color=[0.25]*3
    #     )
    # divider = mo.Actor(divider)
    # mainlayer.merge(divider)

    divider = mo.grid.rect([-2*sep, 2*sep, -11, 11]).set(
        width=0,
        fill=mo.color.LinearGradientFill(
            tail=-2*sep, head=2*sep, gradient=mo.color.Gradient({
                0: mation.background+(0,),
                0.25: mation.background+(1,),
                0.75: mation.background+(1,),
                1: mation.background+(0,)
                })
            )
        )
    divider = mo.Actor(divider)
    mainlayer.merge(divider)

    def basefunc(x):
        return math.sin(x) + 3

    a, b = -4.5, 4.5
    base1 = Graph(
        func=basefunc, start=a, end=b,
        strokeWeight=7, color=goodblue
        )
    base1 = mo.Actor(base1)
    gridlayer1.merge(base1)

    base2 = base1.copy()
    gridlayer2.merge(base2)

    deriv1 = base1.copy()
    deriv1.first().set(
        func=math.cos, color=[0,0.6,0]
        )
    gridlayer1.merge(deriv1)

    deriv2 = deriv1.copy()
    gridlayer2.merge(deriv2)

    # mation.endDelayUntil(1*30)
    print("Show vlines and draw half-derivs:", mation.seconds())

    a1 = -3
    a2 = 0.5

    gridlayers = [gridlayer1, gridlayer2]
    lowerbounds = [a1, a2]

    time = mation.lastID()
    vlines = []
    for lowerbound, gridlayer in zip(lowerbounds, gridlayers):
        vline = mo.grid.Path([-11j, 11j]).set(
            width=6, color=[1,0,0], dash=[20,15],
            origin=lowerbound
            )
        vline = mo.Actor(vline)
        vlines.append(vline)
        gridlayer.merge(vline, atFrame=time)
        vline.growIn(30)

    alabels = []
    for lowerbound, gridlayer in zip(lowerbounds, gridlayers):
        alabel = mo.text.paragraph(
            [mo.text.Text("a  ", italic=True),
            mo.text.Text(f"= {lowerbound}")],
            gridlayer.camera.last().view, mation.windowShape,
            pos=lowerbound-3.5j, size=64, color=[0.8,0,0],
            align=[-1,0],
            background=mo.color.parseHexColor("ffc0cb"),
            backPad=0.05, backAlpha=0.75
            ).set(zdepth=100)
        alabel = mo.Actor(alabel)
        alabels.append(alabel)
        gridlayer.append(alabel)
        alabel.fadeIn(20, jump=0.75j)
    del gridlayer

    mation.endDelay(30)

    time = mation.lastID() + 1
    halfderiv1 = FuncFrac().set(
        p=0, func=basefunc, domain=[a1, b], steps=150,
        width=7, color=goodblue, dash=[40,0],
        interpMethod=None
        )
    halfderiv1 = mo.Actor(halfderiv1)
    gridlayer1.merge(halfderiv1, atFrame=time)
    halfderiv1.newendkey(30).set(p=1/2, color=violet)

    halfderiv2 = FuncFrac().set(
        p=0, func=basefunc, domain=[a2, b], steps=150,
        width=7, color=goodblue, dash=[40,0],
        interpMethod=None
        )
    halfderiv2 = mo.Actor(halfderiv2)
    gridlayer2.merge(halfderiv2, atFrame=time)
    halfderiv2.newendkey(30).set(p=1/2, color=violet)

    arrow1 = mo.grid.Arrow(1.5+3.8j, (1.5+1.81j)).set(
        width=5, color=[1,0,0], headSize=30
        )
    arrow1 = mo.Actor(arrow1)
    gridlayer1.merge(arrow1, atFrame=time)
    arrow1.growIn(30)

    dlabel1 = mo.graphics.MultiImage("./resources/aDt-half.png").set(
        pos=arrow1.key[1].midpoint(), height=70, physical=False,
        background=mation.background, backPad=7, backAlpha=0.65
        )
    dlabel1 = mo.Actor(dlabel1)
    gridlayer1.merge(dlabel1, atFrame=time)
    dlabel1.fadeIn(30, jump=-0.9j)

    arrow2 = arrow1.last().copy().set(tail=2.5+3.38j, head=(2.5+1.3j))
    arrow2 = mo.Actor(arrow2)
    gridlayer2.merge(arrow2, atFrame=time)
    arrow2.growIn(30)

    dlabel2 = dlabel1.last().copy().set(pos=arrow2.key[1].midpoint())
    dlabel2 = mo.Actor(dlabel2)
    gridlayer2.merge(dlabel2, atFrame=time)
    dlabel2.fadeIn(30, jump=-0.9j)

    mation.endDelay(20)

    time = mation.lastID()
    mo.action.shrinkOut([arrow1, arrow2], atFrame=time, duration=30, reverse=True)
    mo.action.fadeOut([dlabel1, dlabel2], atFrame=time, duration=30, jump=-0.9j)

    mation.endDelay(20)
    print("Apply half derivative again:", mation.seconds())

    time = mation.lastID()+1

    arrow1.newkey(time).set(tail=1.5+1.4j, head=(1.5+0.27j), headSize=30)
    # arrow1.key[-2].static = True
    arrow1.growIn(30)

    dlabel1.newkey(time).set(pos=arrow1.last().midpoint()).height *= 0.8
    dlabel1.fadeIn(30, jump=-0.5j)

    arrow2.newkey(time).set(tail=2.5+0.83j, head=2.5-0.61j, headSize=30, zdepth=100)
    # arrow2.key[-2].static = True
    arrow2.growIn(30)

    dlabel2.newkey(time).set(pos=arrow2.last().midpoint(), backAlpha=0.85, zdepth=100).height *= 0.8
    dlabel2.fadeIn(30, jump=-0.5j)


    for fcurve in [halfderiv1, halfderiv2]:
        fcurve.newkey(time)
        fcurve.newendkey(30).set(p=1, color=deriv1.last().color[:])

    mation.endDelay(30)

    time = mation.lastID()
    for fcurve in [halfderiv1, halfderiv2]:
        fcurve.newendkey(15).set(dash=[20,20], color=[0,1,1])

    mo.action.shrinkOut([arrow1, arrow2], atFrame=time, duration=30, reverse=True)
    mo.action.fadeOut([dlabel1, dlabel2], atFrame=time, duration=30, jump=-0.5j)




    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = gridlayer2
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./15_nonlocal-compos.mp4", scale=1)


main()
