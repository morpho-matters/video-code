
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "03_why-integrals"


def Wfunc(x, N):
    ns = np.arange(N+1)
    terms = np.cos(3**ns * pi * x) / 2**(ns+1)

    return np.sum(terms).tolist()


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    colorlayer = mainlayer.copy()
    colorlayer.mask = mainlayer.copy()
    mainview = mainlayer.viewtime(0)
    mation = morpho.Animation([gridlayer, mainlayer, colorlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # Make rainbowy title
    title = morpho.text.Text("FRACTIONAL INTEGRALZ!!!",
        pos=7j, bold=True,
        size=84, anchor_x=0, anchor_y=0,
        color=(0,0,0)
        )
    title = morpho.Actor(title)
    colorlayer.mask.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    box = title.last().box(mainview, mation.windowShape, pad=0)
    grad = mo.color.rainbow()
    gradfill = mo.color.LinearGradientFill(box[-2]*1j, box[-1]*1j, grad)
    rect = mo.grid.rect(box).set(
        width=0, fill=gradfill
        )
    rect = mo.Actor(rect)
    colorlayer.merge(rect)
    gradfill2 = gradfill.copy()
    gradfill2.head, gradfill2.tail = gradfill2.tail, gradfill2.head
    rect.newendkey(30).fill = gradfill2

    kman = mo.graphics.MultiImage("./resources/k-presents.png").set(
        pos=6-5j, align=[0,-1], height=8
        )
    kman = mo.Actor(kman)
    mainlayer.merge(kman)

    time = mation.lastID() + 4*30  # TEMP
    hero = mo.graphics.MultiImage("./resources/hero-oops.png").set(
        pos=-kman.last().pos.conjugate(), align=[0,-1],
        height=kman.last().height*8.5/9
        )
    hero = mo.Actor(hero)
    mainlayer.merge(hero, atFrame=time)
    print("Show hero:", mation.seconds())
    hero.fadeIn(20)

    failed = mo.text.paragraphPhys("But aren't\nintegrals worse?",
        pos=(-1.75+2.96j), align=[0,-1], size=0.55,
        font="Qarmic sans", ygap=0.25, color=[0,0,0]
        )
    failed = mo.Actor(failed)
    mainlayer.append(failed)
    failed.fadeIn(20, jump=2+2j)

    arc = mo.grid.arc(-2.98+2.52j, (-3.81+1.67j), angle=-80*deg).set(
        width=4, color=[0,0,0]
        )
    arc = mo.Actor(arc)
    mainlayer.append(arc)
    arc.growIn(20)

    # Make the title shimmer until time to fade out
    time = mation.lastID() + 2.5*30  # TEMP
    while rect.lastID() < time:
        rect.newendkey(30, rect.key[-2].copy())

    print("Fade out everything:", mation.seconds())

    time = mation.lastID()
    mo.actions.fadeOut([arc, failed, hero, kman, title],
        atFrame=time, duration=30
        )
    colorlayer.camera.newkey(mation.lastID()).visible = False

    mation.endDelayUntil(12.25*30)
    print("Show horrid integral:", mation.seconds())

    horrid = mo.graphics.Image("./resources/horrid-integral.png").set(
        pos=0, height=18
        )
    horrid = mo.Actor(horrid)
    mainlayer.append(horrid)
    horrid.fadeIn(30, jump=5j)

    mation.endDelayUntil(14.75*30)
    print("Remove integral and show serpent:", mation.seconds())

    horrid.fadeOut(30, jump=5j)

    mation.endDelayUntil(17*30)

    print("Show serpent:", mation.seconds())
    serpent = mo.graphics.MultiImage("./resources/serpentine-integral.png").set(
        pos=-3-2j, height=8
        )
    serpent = mo.Actor(serpent)
    mainlayer.append(serpent)
    serpent.fadeIn(20)

    picky = mo.text.paragraphPhys("We're not\npicky eaterssss...",
        pos=(2.258+2.35j), size=0.55, align=[0,-1],
        ygap=0.25, font="Qarmic sans", color=[0,0,0]
        )
    picky = mo.Actor(picky)
    mainlayer.append(picky)
    picky.fadeIn(20, jump=2+2j)

    arc2 = mo.grid.arc(1.39+1.93j, (0.31+0.85j), angle=-60*deg).set(
        width=4, color=[0,0,0]
        )
    arc2 = mo.Actor(arc2)
    mainlayer.append(arc2)
    arc2.growIn(20)

    mation.endDelayUntil(20.75*30)
    print("Fade serpent and show integral continuous:", mation.seconds())

    mo.action.fadeOut([arc2, picky, serpent],
        duration=20,
        )

    goodint = mo.graphics.MultiImage("./resources/integral-cont-func.png").set(
        pos=8+8j, align=[1,0], height=2.5
        )
    goodint = mo.Actor(goodint)
    mainlayer.append(goodint)
    goodint.fadeIn(20, jump=2j)

    mation.endDelayUntil(24.15*30)
    print("Show bad derivative:", mation.seconds())

    baddiff = mo.graphics.MultiImage("./resources/ddx-cont-func.png").set(
        pos=goodint.last().pos-3j, align=[1,0], height=2.25
        )
    baddiff = mo.Actor(baddiff)
    mainlayer.append(baddiff)
    baddiff.fadeIn(20, jump=2j)

    mation.endDelay(15)

    sometimes = mo.text.Text("sometimes",
        pos=baddiff.last().pos+0.65, anchor_x=-1, italic=True,
        size=42, color=[0.8,0,0]
        )
    sometimes = mo.Actor(sometimes)
    mainlayer.append(sometimes)
    sometimes.fadeIn(20, jump=3)

    mation.endDelayUntil(27.75*30)
    print("Show Weierstrass curve:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    gridlayer.camera.first().zoomIn(3).moveBy(1.2j).zoomIn(1.5, focus=0)
    viewbox = [-2,2,-1,1]
    grid = mo.grid.mathgrid(
        view=viewbox,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid, atFrame=time)
    grid.growIn(30)

    axes = mo.grid.axes(viewbox,
        width=10, color=[0,0,0],
        )
    axes = mo.Actor(axes)
    gridlayer.merge(axes, atFrame=time)
    axes.growIn(30)

    bg = mo.grid.rect(viewbox).set(width=0, fill=[1,1,1])
    bg = mo.Actor(bg)
    gridlayer.merge(bg, atFrame=time, beforeActor=grid)
    bg.fadeIn(30)

    mation.endDelay(10)

    time = mation.lastID()
    x1 = 0.1
    x2 = 0.23
    style = dict(width=3, color=(1,0,0), transition=uniform)

    order = 30
    wcurve0 = morpho.graph.realgraph(lambda x: Wfunc(x, order), -2, x1, steps=1000)
    wcurve0.set(**style)
    wcurve0 = mo.Actor(wcurve0)
    gridlayer.merge(wcurve0, atFrame=time)
    wcurve0.growIn(15)

    wcurve1 = mo.graph.realgraph(lambda x: Wfunc(x, order), x1, x2, steps=2000)
    wcurve1.set(**style)
    wcurve1 = mo.Actor(wcurve1)
    gridlayer.append(wcurve1)
    wcurve1.growIn(2)

    wcurve2 = morpho.graph.realgraph(lambda x: Wfunc(x, order), x2, 2, steps=1000)
    wcurve2.set(**style)
    wcurve2 = mo.Actor(wcurve2)
    gridlayer.append(wcurve2)
    wcurve2.growIn(15)

    label = mo.text.PText("Weierstrass function",
        pos=1.1j, anchor_y=-1,
        size=0.17, color=[1,0,0]
        )
    label = mo.Actor(label)
    gridlayer.append(label)
    label.fadeIn(20, jump=0.35j)

    mation.endDelayUntil(33*30)
    print("Zoom in on curve:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([goodint, baddiff, sometimes, label],
        atFrame=time, duration=15)

    m = mean([x1,x2])
    wm = Wfunc(m, order)
    target = m + 1j*wm
    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(75).view = [x1, x2, wm-1, wm+1]
    gridlayer.camera.last().rescaleHeight(16/9)

    for path in [wcurve0, wcurve1, wcurve2]:
        path.newkey(time)
        path.newkey(mation.lastID()).width *= 1.5

    sigma = mo.graphics.Image("./resources/sigma-monster.png").set(
        pos=(0.23603+0.33565j), align=[0,-1], height=0.01
        )
    sigma = mo.Actor(sigma)
    gridlayer.merge(sigma, atFrame=time+1)





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = gridlayer
    mation.clickRound = 5
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./03_why-integrals.mp4", scale=1)


main()
