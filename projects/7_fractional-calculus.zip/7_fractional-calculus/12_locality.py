
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "12_locality"


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # gridlayer.camera.first().moveBy(-(-13.06-2.5j)).zoomIn(4, focus=0)
    view = [-5,5, -1,3]
    gridlayer.camera.first().view = view
    gridlayer.camera.first().rescaleHeight(16/9)
    gridview = roundOut(gridlayer.camera.first().view)
    gridview[-1] += 2

    # # Create mask for gridlayer
    # gridlayer.mask = gridlayer.copy()
    # gridlayer.mask.camera.first().visible = False
    # mask = mo.grid.rect(gridview).set(width=2)
    # mask = mo.Actor(mask)
    # gridlayer.mask.merge(mask)

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid)
    grid.growIn(30)

    axes = mo.grid.axes(gridview,
        width=10, color=[0,0,0],
        ).set(zdepth=10)
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    axes.growIn(30)

    @mo.SkitParameters(func=lambda x: x, start=0, end=1,
        strokeWeight=3, color=(0,0,0), alpha=1, steps=300
        )
    class Graph(mo.Skit):
        def makeFrame(self):
            func = self.func
            start = self.start
            end = self.end
            strokeWeight = self.strokeWeight
            color = self.color
            alpha = self.alpha
            steps = round(self.steps)

            graph = mo.graph.realgraph(func, start, end, steps=steps)
            graph.set(width=strokeWeight, color=color, alpha=alpha)

            return graph

    def basefunc(x):
        return 2.5*math.exp(-(x-1)**2/4)
    basecurve = Graph(
        func=basefunc, start=gridview[0], end=gridview[0],
        strokeWeight=7, color=goodblue
        )
    basecurve = mo.Actor(basecurve)
    gridlayer.append(basecurve)
    basecurve.newendkey(45).end = gridview[1]


    mation.endDelayUntil(6.5*30)
    print("'d/dt is a local operator':", mation.seconds())

    time = mation.lastID()
    local = mo.graphics.MultiImage("./resources/local-operator.png").set(
        pos=(11.83+6.61j), height=2,
        background=mation.background, backAlpha=0.65, backPad=0.25
        )
    local = mo.Actor(local)
    mainlayer.merge(local, atFrame=time)
    local.fadeIn(20, jump=2j)

    mation.endDelayUntil(10*30)
    print("Show tangent line and curtain:", mation.seconds())

    @mo.SkitParameters(
        func=basefunc,
        t=0, length=0, alpha=1, width=6, color=(1,0,0),
        ptFill=(1,1,0), ptAlpha=0
        )
    class TangentLine(morpho.Skit):
        def makeFrame(self):
            # t will represent the input to the function f
            func = self.func
            t = self.t
            length = self.length
            alpha = self.alpha
            width = self.width
            color = self.color
            ptFill = self.ptFill
            ptAlpha = self.ptAlpha

            figs = []

            x = t
            y = func(t)
            pos = complex(x,y)

            # Initialize tangent line to be a horizontal
            # line segment of length 4 centered at the
            # origin
            if length != 0:
                line = morpho.grid.Path([-length/2, length/2])
                line.color = color
                line.alpha = alpha
                line.width = width

                # Compute derivative
                slope = derivative(func, t, dx=1e-4).tolist()
                # Convert into an angle and set it as the rotation
                # of the line segment
                angle = math.atan(slope)
                line.rotation = angle

                # Position the tangent line at the tangent point
                line.origin = x + 1j*y

                figs.append(line)

            if ptAlpha > 0:
                pt = mo.grid.Point(pos).set(
                    size=15, strokeWeight=2, fill=ptFill,
                    alpha=alpha*ptAlpha
                    )
                figs.append(pt)

            return morpho.Frame(figs)

    time = mation.lastID()
    target = 1.33
    tanline = TangentLine(t=target)
    tanline = mo.Actor(tanline)
    gridlayer.merge(tanline, atFrame=time)
    radius = 0.65
    tanline.newendkey(20).set(length=2*radius, ptAlpha=1)

    mation.endDelayUntil(13*30)
    print("Draw in curtains:", mation.seconds())

    time = mation.lastID()
    # Hide the "local operator" label
    local.fadeOut(20, time)

    curtainbox1 = gridview[:]
    curtainbox1[1] = target - radius
    curtain1 = mo.grid.rect(curtainbox1).set(
        width=0, fill=[0,0,0], alpha=0.5, origin=-6.5
        )
    curtain1 = mo.Actor(curtain1)
    gridlayer.merge(curtain1, atFrame=time)
    curtain1.newendkey(30).origin = 0

    curtainbox2 = gridview[:]
    curtainbox2[0] = target + radius
    curtain2 = mo.grid.rect(curtainbox2).set(
        width=0, fill=[0,0,0], alpha=0.5,
        origin=-curtain1.first().origin
        )
    curtain2 = mo.Actor(curtain2)
    gridlayer.merge(curtain2, atFrame=time)
    curtain2.newendkey(30).origin = 0

    mation.endDelayUntil(19*30)
    print("Make curve roil:", mation.seconds())

    def roiler(t, f, phi, amp=0.5, buf=0.25):
        if abs(t-target) <= radius:
            return 0
        amt = amp*math.sin(f*t + phi)
        if abs(t-target) <= radius+buf:
            amt *= mo.lerp(0, 1, abs(t-target), start=radius, end=radius+buf)
        return amt

    def generateRandomRoiler():
        f = 5 + 3*random.random()
        phi = tau*random.random()
        return lambda t: roiler(t, f, phi)

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    basecurve.newkey(time)

    time = mation.lastID() + 11*30  # TBD
    random.seed(18)
    while basecurve.lastID() < time:
        roil1 = generateRandomRoiler()
        roil2 = generateRandomRoiler()
        basecurve.newendkey(10).func = lambda t, roil1=roil1, roil2=roil2: basefunc(t) + roil1(t) + roil2(t)

    print("Revert to original scene and draw half-deriv:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    basecurve.newkey(time)
    basecurve.newendkey(10, basecurve.key[1].copy())

    mo.action.rollback([curtain1, curtain2], 30, atFrame=time)
    tanline.fadeOut(30, atFrame=time)

    mation.endDelay(15)

    time = mation.lastID()
    dcurve_base = FuncFrac().set(
        p=0, func=basefunc, domain=gridview[:2], steps=300,
        width=7, color=basecurve.last().color[:],
        interpMethod=None, relpad=0.002
        )
    dcurve_base = mo.Actor(dcurve_base)
    dcurve_base.visible = False
    gridlayer.merge(dcurve_base)

    grad = mo.color.Gradient({
            0: basecurve.last().color[:],
            1: [1,0,0]
        })

    # Puppet skit reacts to basecurve's current function
    @mo.SkitParameters(p=0, alpha=1)
    class DerivCurve(mo.Skit):
        def makeFrame(self, index=None):
            p = self.p
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            func = basecurve.time(index).func
            dcurve = dcurve_base.time(index).copy()
            dcurve.func = func
            dcurve.p = p
            dcurve.color = grad.value(mo.lerp(0,1,p,start=0, end=1/2))
            dcurve.alpha = alpha

            return dcurve

    dcurve = DerivCurve()
    dcurve = mo.Actor(dcurve)
    # dcurve.visible = False  ### TEMP!!!
    gridlayer.merge(dcurve, atFrame=time)
    dcurve.newendkey(20).set(p=1/2)

    dlabel = mo.graphics.MultiImage("./resources/aDt-half-f(t).png").set(
        pos=1.5+dcurve.last().makeFrame(index=mation.lastID()).makeFunc()(1.5)*1j, align=[-0.8,0],
        height=80, physical=False,
        background=mation.background, backAlpha=0.75, backPad=10
        )
    dlabel = mo.Actor(dlabel)
    gridlayer.append(dlabel)
    dlabel.fadeIn(15, jump=0.75)

    mation.endDelay(30)
    print("Prepare to do minor roiling:", mation.seconds())

    # Rollback dlabel
    dlabel.rollback(15)

    # Highlight target points
    time = mation.lastID()
    basept = tanline
    basept.newkey(time).set(
        length=0, ptAlpha=1
        )
    basept.fadeIn(20)

    def derivFunc(t, index=None):
        if index is None:
            index = mation.currentIndex
        return dcurve.time(index).makeFrame(index).makeFunc()(t)

    derivpt = TangentLine(
        func=derivFunc, t=target, ptFill=[0.3,1,0.3], ptAlpha=1
        )
    derivpt = mo.Actor(derivpt)
    gridlayer.merge(derivpt, atFrame=time)
    derivpt.fadeIn(20)

    mation.currentIndex = mation.lastID()
    derivGhost = derivpt.last().makeFrame().figures[-1].set(alpha=0.5)
    mation.currentIndex = 0
    derivGhost = mo.Actor(derivGhost)
    gridlayer.append(derivGhost, beforeActor=derivpt)

    vline = mo.grid.Path([-2j, 4j]).set(
        width=4, color=[0,0,0], dash=[20,15],
        origin=target
        )
    vline = mo.Actor(vline)
    gridlayer.merge(vline, atFrame=time, beforeActor=basept)
    vline.growIn(30)

    # for curtain in [curtain1, curtain2]:
    #     curtain.newkey(time).visible = True
    #     curtain.newendkey(30, curtain.key[1].copy())

    mation.endDelayUntil(35.5*30)
    print("Start roiling the half-derivative:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK

    basecurve.newkey(time)

    amp = 2.5
    focus = -3.5
    fradius = 1

    dcurve_base.newkey(time).points = [focus-fradius, focus+fradius]

    def bump(x, center=0, radius=1):
        if abs(x-center) < radius:
            return math.exp(1-1/(1-((x-center)/radius)**2))
        else:
            return 0

    # def newRoiler(t, f, phi, amp=0.5, buf=0.1):
    #     if abs(t-focus) > fradius:
    #         return 0
    #     amt = amp*math.sin(f*t + phi)
    #     if abs(t-focus) > fradius-buf:
    #         amt *= mo.lerp(0, 1, abs(t-focus), start=fradius, end=fradius-buf)
    #     return amt

    # def newGenerateRandomRoiler():
    #     f = 5 + 3*random.random()
    #     phi = tau*random.random()
    #     return lambda t: newRoiler(t, f, phi)

    time = mation.lastID() + 2.5*30  # TBD
    sign = 1
    while basecurve.lastID() < time:
        def newfunc(t, sign=sign):
            return basefunc(t) + sign*amp*bump(t, center=focus, radius=fradius)
        basecurve.newendkey(20).func = newfunc
        sign *= -1

    # def test(t):
    #     f1 = derivagral(basefunc, 1/2, -10)
    #     fbump = derivagral(lambda x: bump(x, center=focus, radius=fradius), 1/2, focus-fradius)
    #     def f2(t):
    #         if t <= focus-fradius:
    #             return 0
    #         return fbump(t)

    #     return f1(t) + -sign*amp*f2(t)

    # testgraph = mo.graph.realgraph(test, *gridview[:2], steps=200).set(
    #     width=7, color=[1,1,0], dash=[15]
    #     )
    # gridlayer.append(testgraph)

    basecurve.newendkey(12).func = basefunc

    mation.endDelayUntil(39*30)
    print("Move the lowerbound around:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    dcurve_base.newkey(time).points = None

    basecurve.newkey(time)
    basecurve.newendkey(80).start = 0.25

    dcurve_base.newkey(time)
    dcurve_base.newendkey(80).domain[0] = basecurve.last().start

    mation.endDelay(15)

    basecurve.newendkey(65).start = -1
    dcurve_base.newendkey(65).domain[0] = basecurve.last().start

    mation.endDelay(10)

    basecurve.newendkey(65).start = basecurve.first().start
    dcurve_base.newendkey(65).domain[0] = basecurve.last().start

    mation.endDelayUntil(50.4*30)
    print("Show 'nonlocal' label:", mation.seconds())

    time = mation.lastID()
    nonloc = mo.graphics.MultiImage("./resources/nonlocal.png").set(
        pos=(-14+6.2j), height=1, align=[-1,0],
        background=mation.background, backPad=0.35, backAlpha=0.85
        )
    nonloc = mo.Actor(nonloc)
    mainlayer.merge(nonloc, atFrame=time)
    nonloc.fadeIn(20, jump=2j)

    mation.endDelayUntil(53.65*30)
    print("Morph to 'has memory' label:", mation.seconds())

    nonloc.newendkey(20).newSource("./resources/has-memory.png").scaleByHeight()

    mation.endDelayUntil(55.4*30)
    print("Start some minor roiling again:", mation.seconds())

    time = mation.lastID()
    basecurve.newkey(time)

    dcurve_base.newkey(time).points = [focus-fradius, focus+fradius]


    time = mation.lastID() + 5.5*30  # TBD
    sign = 1
    while basecurve.lastID() < time:
        def newfunc(t, sign=sign):
            return basefunc(t) + sign*amp*bump(t, center=focus, radius=fradius)
        basecurve.newendkey(20).func = newfunc
        sign *= -1

    print("Clear the scene and draw a sinewave:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    mo.action.fadeOut(
        [basecurve, dcurve, vline, derivpt, derivGhost, basept, nonloc],
        atFrame=time, duration=30)

    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(30).moveBy(1.4j)

    time = mation.lastID()
    # mation.start = time  # BOOKMARK

    def sinewave(x):
        return 1.25+0.5*math.sin(2*x)
    def sinewaveIntegral(t, a):
        return quad(sinewave, a, t, points=[0])[0]
        # return -(math.cos(2*t) - 6*t - math.cos(4) - 12)/4
    sinecurve = Graph(
        func=sinewave, start=gridview[0], end=gridview[0],
        strokeWeight=7, color=[0,0.6,0]
        )
    sinecurve = mo.Actor(sinecurve)
    gridlayer.append(sinecurve)
    sinecurve.newendkey(30).end = gridview[1]

    mation.endDelay(15)
    print("Draw the integral curve and area:", mation.seconds())

    a,b = -2, 2

    time = mation.lastID()
    area = mo.calculus.IntegralArea(
        sinewave, start=a, end=a,
        strokeWeight=0, fill=goodblue, alpha=0.5, steps=100
        )
    area = mo.Actor(area)
    gridlayer.merge(area, atFrame=time, beforeActor=sinecurve)
    area.newendkey(45).end = b

    # Puppet skit reacts to sinecurve's func
    @mo.SkitParameters(start=a, end=a)
    class IntegralCurve(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex
            start = self.start
            end = self.end

            func = sinecurve.time(index).func
            def ifunc(t):
                return quad(func, start, t, points=[0])[0]
            icurve = Graph(func=ifunc,
                start=start, end=end,
                strokeWeight=7, color=violet, steps=100
                )

            return icurve

    icurve = IntegralCurve()
    icurve = mo.Actor(icurve)
    gridlayer.merge(icurve, atFrame=time)
    icurve.newendkey(45).end = b

    mation.endDelayUntil(66.4*30)
    print("Alter the early part of the function:", mation.seconds())

    def sineTrunc(x):
        if a <= x <= 0:
            return 0.25
        else:
            return sinewave(x)

    time = mation.lastID()
    sinecurve.newkey(time)
    sinecurve.newendkey(45).func = sineTrunc

    area.newkey(time)
    area.newendkey(45).func = sineTrunc






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./12_locality.mp4", scale=1)


main()
