
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "06_fracints-visualized"


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    colorlayer = mainlayer.copy()
    toplayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer, colorlayer, toplayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightgreen

    colorlayer.mask = mainlayer.copy()
    colorlayer.camera.first().visible = False

    # gridlayer.camera.first().view = [-1.5,2.5, -2, 8]
    gridlayer.camera.first().moveBy(-(-13.06-2.5j)).zoomIn(4, focus=0)
    gridview = [-1,3, -2,3]

    gridlayer.camera.first().zoomOut(1.2)

    gridlayer.mask = gridlayer.copy()
    gridbox = mo.grid.rect(gridview, pad=0.25)
    gridbox = mo.Actor(gridbox)
    gridlayer.mask.merge(gridbox)

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid)
    # grid.growIn(30)

    axes = mo.grid.axes([-2,9,-3,9],
        width=10, color=[0,0,0],
        ).set(zdepth=10)
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    # axes.growIn(30)

    time = mation.lastID()
    box = gridview[:]
    gridBG = mo.grid.rect(box).set(
        width=0, fill=[1,1,1], alphaFill=1
        )
    gridBG = mo.Actor(gridBG)
    gridlayer.merge(gridBG, atFrame=0, beforeActor=0)
    # gridBG.fadeIn(30)

    time = mation.lastID()
    red = (0.8,0,0)
    line = mo.graph.realgraph(lambda x: 2*x, 0, 2, steps=1).set(
        width=7, color=red
        )
    line = mo.Actor(line)
    gridlayer.merge(line)

    quad = mo.graph.realgraph(lambda x: x**2, 0, 3).set(
        width=7, color=redorange
        )
    quad = mo.Actor(quad)
    gridlayer.merge(quad)

    cubic = mo.graph.realgraph(lambda x: x**3/3, 0, 3, steps=75).set(
        width=7, color=violet
        )
    cubic = mo.Actor(cubic)
    gridlayer.merge(cubic)

    graphs = [line, quad, cubic]
    # duration = 20
    # stagger = 5
    # for n, graph in enumerate(graphs):
    #     graph.newkey(time+n*stagger).end = graph.first().start
    #     graph.newendkey(duration).end = 1
    #     graph.first().visible = False
    # mo.action.growIn(graphs, atFrame=time, duration=20, stagger=5)

    xruler = 8
    yticks = [-4, 0, 4]
    pad = 1

    twox = mo.graphics.MultiImage("./resources/2x-red.png").set(
        pos=xruler+pad+1j*yticks[0], align=[-1,0], height=0.9
        )
    twox = mo.Actor(twox)
    mainlayer.merge(twox)

    xsquared = mo.graphics.MultiImage("./resources/x2-redorange.png").set(
        pos=xruler+pad+1j*yticks[1], align=[-1,0], height=1.25
        )
    xsquared = mo.Actor(xsquared)
    mainlayer.merge(xsquared)

    xcubed = mo.graphics.MultiImage("./resources/x3-over-3-violet.png").set(
        pos=xruler+pad+1j*yticks[2], align=[-1,0], height=1.45
        )
    xcubed = mo.Actor(xcubed)
    mainlayer.merge(xcubed)

    formulas = [twox, xsquared, xcubed]
    # mo.action.fadeIn(formulas, atFrame=time, duration=20, jump=2, stagger=5)

    ruler = mo.grid.Path([1j*yticks[0]-1j, 1j*yticks[2]+1j])
    ruler.set(origin=xruler, width=4, color=[0,0,0])
    ruler = mo.Actor(ruler)
    mainlayer.merge(ruler, atFrame=time)
    # ruler.growIn(30)

    ticks = ruler.last().copy()
    dx = 0.25
    ticks.seq = []
    for y in yticks:
        ticks.seq += [-dx+1j*y, dx+1j*y]
    ticks.origin = xruler
    ticks.deadends = {1,3,5}
    ticks = mo.Actor(ticks)
    mainlayer.merge(ticks, atFrame=time)
    # ticks.growIn(30)


    integ_base = mo.graphics.MultiImage("./resources/integ-0t-f.png")
    integ_base = mo.Actor(integ_base)
    integ_base.visible = False
    mainlayer.merge(integ_base)
    xruler2 = ruler.last().origin
    ymin, ymax = yticks[0], yticks[-1]
    grad = mo.color.Gradient({0:red, 1/2:redorange, 1:violet})
    @mo.SkitParameters(p=3, alpha=0)
    class IntegTracker(mo.Skit):
        def makeFrame(self, index=None):
            p = self.p
            alpha = self.alpha
            if index is None:
                index = mation.currentIndex

            color = (0,0,0)
            integ = integ_base.time(index).copy()
            for img in integ.figures:
                img.set(
                    pos=xruler2-1.75+1j*mo.lerp(ymin, ymax, p, start=0, end=2),
                    height=2).alpha *= alpha
            power = mo.text.Text(mo.text.formatNumber(p, decimal=2, rightDigits=2),
                pos=integ.pos-0.84-0.57j, anchor_x=1,
                size=38, color=color, alpha=alpha
                )
            arrow = mo.grid.Arrow()
            arrow.head = xruler2+1j*integ.pos.imag
            arrow.tail = arrow.head-1
            arrow.set(width=0, headSize=30, color=color, alpha=alpha)

            return mo.Frame([integ, power, arrow])

    jtracker = IntegTracker(p=0, alpha=1)
    jtracker = mo.Actor(jtracker)
    colorlayer.mask.merge(jtracker, atFrame=time)
    # jtracker.fadeIn(20)

    rectbase = mo.grid.rect(mainlayer.viewtime(0)).set(width=0)
    # Puppet skit reacts to jtracker's p-value and changes its
    # color accordingly.
    class BG(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex

            p = jtracker.time(index).p
            color = tuple(grad.value(mo.lerp(0,1, p, start=0, end=2)))
            rect = rectbase.copy().set(fill=color)
            return rect

    bg = BG()
    bg = mo.Actor(bg)
    colorlayer.merge(bg, atFrame=time)
    colorlayer.camera.newkey(time).visible = True

    mation.endDelayUntil(2.75*30)
    print("Vary p from 0 to 1:", mation.seconds())

    time = mation.lastID() + 1
    jtracker.newkey(time)
    jtracker.newendkey(60).p = 1
    for n in range(3):
        jtracker.newendkey(60).p = 0
        jtracker.newendkey(60).p = 1

    # Puppet skit reacts to jtracker state
    fcurve = FuncFrac().set(
        p=0, func=lambda x: 2*x, domain=[0,2.25], width=7,
        interpMethod=None, dash=(20,10)
        )
    @mo.SkitParameters(domain=(0,2.25), steps=50)
    class IntegCurve(mo.Skit):
        def makeFrame(self, index=None):
            domain = self.domain
            steps = self.steps
            if index is None:
                index = mation.currentIndex

            p = jtracker.time(index).p
            color = tuple(grad.value(mo.lerp(0,1, p, start=0, end=2)))
            a = 0.05
            b = 2.25
            curve = fcurve.copy()
            curve.set(p=-p, color=color, domain=domain, steps=steps)

            return curve

    jcurve = IntegCurve()
    jcurve = mo.Actor(jcurve)
    gridlayer.merge(jcurve, atFrame=time)

    mation.endDelayUntil(18*30)
    print("Vary p from 1 to 2:", mation.seconds())

    jtracker.newendkey(60).p = 2
    for n in range(1):
        jtracker.newendkey(60).p = 1
        jtracker.newendkey(60).p = 2
    jtracker.newendkey(60).p = 1

    mation.endDelayUntil(27.5*30)
    print("Return to p = 0:", mation.seconds())

    jtracker.newendkey(45).p = 0
    jcurve.newkey(mation.lastID()).visible = False  # Temporarily hide

    mation.endDelayUntil(30*30)
    print("Change a from 0 to -1:", mation.seconds())

    time = mation.lastID()
    # mation.start = time   # BOOKMARK

    # Encircle the current lowerbound of 0
    circ = mo.grid.ellipse((6-4.78j), 0.4, phase=pi/2, relative=True).edge().set(
        width=4, color=violet,
        outlineWidth=1.5, outlineColor=[1,1,1]
        )
    circ = mo.Actor(circ)
    toplayer.merge(circ, atFrame=time)
    circ.newendkey(20)
    circ.first().set(transform=[[5,0],[0,5]], alpha=0)

    arrow = mo.grid.Arrow(circ.last().origin-0.5j)
    arrow.head = arrow.tail - 1.5j
    arrow.set(width=4, color=red, headSize=25)
    arrow = mo.Actor(arrow)
    toplayer.append(arrow)
    arrow.growIn(15)

    neg1 = mo.text.Text("-1",
        pos=arrow.last().head-0.5j,
        size=44, color=red
        )
    neg1 = mo.Actor(neg1)
    toplayer.append(neg1)
    neg1.fadeIn(15, jump=-1j)

    mation.endDelayUntil(33*30)
    print("Morph to -1:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([neg1, arrow, circ], atFrame=time, duration=30)

    integ_base.newkey(time)
    integ_base.newendkey(30).newSource("./resources/integ-neg1t-f.png").scaleByHeight()

    line.newkey(time)
    line.newendkey(30,
        mo.graph.realgraph(lambda x: 2*x, -1, 3).set(width=7, color=red)
        )

    quad.newkey(time)
    quad.newendkey(30,
        mo.graph.realgraph(lambda x: x**2-1, -1, 2.5).set(width=7, color=redorange)
        )

    cubic.newkey(time)
    cubic.newendkey(30,
        mo.graph.realgraph(lambda x: ((x-2)*(x+1)**2)/3, -1, 3, steps=75).set(
            width=7, color=violet
            )
        )

    xsquared.newkey(time)
    xsquared.newendkey(30).newSource("./resources/x2-1-redorange.png").scaleByHeight()

    xcubed.newkey(time)
    xcubed.newendkey(30).newSource("./resources/complex-cubic.png").scaleByHeight()

    mation.endDelayUntil(36.5*30)
    print("Enbox the changed integrals:", mation.seconds())

    time = mation.lastID()
    squareboxer = mo.gadgets.enbox(xsquared.last().box(pad=0.4),
        width=5, color=redorange
        )
    mainlayer.merge(squareboxer, atFrame=time)

    cuboxer = mo.gadgets.enbox(xcubed.last().box(pad=0.4),
        width=5, color=violet
        )
    mainlayer.merge(cuboxer, atFrame=time+15)

    mation.endDelayUntil(44*30)
    print("Start varying p again:", mation.seconds())

    time = mation.lastID() + 1
    # mation.start = time  # BOOKMARK
    jcurve.newkey(time).set(
        domain=[-1,3], visible=True
        )

    jtracker.newkey(time)
    jtracker.newendkey(150).set(p=2)





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./06_fracints-visualized.mp4", scale=1)


main()
