
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad
from scipy.special import gamma

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))
darkgreen = dgreen = tuple(mo.color.parseHexColor("008000"))
beet = tuple(mo.color.parseHexColor("80003a"))
brown = tuple(mo.color.parseHexColor("5c2912"))


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "21_exp-definitions"



def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mation.endDelayUntil(2*30)
    print("Start morphing exponentials:", mation.seconds())

    explabel = mo.graphics.MultiImage("./resources/e-def1.png").set(
        pos=0, height=2.75
        )
    explabel = mo.Actor(explabel)
    mainlayer.merge(explabel)

    delay = 45

    scalars = [1, 0.45, 0.45, 0.8, 1]
    for n in range(2,6):
        explabel.newendkey(20).newSource(f"./resources/e-def{n}.png").scaleByHeight()
        explabel.last().height = explabel.first().height * scalars[n-1]
        mation.endDelay(delay)

    mation.endDelay(0)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./21_exp-definitions.mp4", scale=1)


main()
