
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "17_nobody-knows"


@mo.SkitParameters(
        func=lambda x: x,
        t=0, length=0, alpha=1, width=6, color=(1,0,0),
        ptFill=(1,1,0), ptAlpha=0
        )
class TangentLine(morpho.Skit):
    def positionAt(self, t=None):
        if t is None:
            t = self.t
        func = self.func

        return complex(t, func(t))

    def makeFrame(self):
        # t will represent the input to the function f
        func = self.func
        t = self.t
        length = self.length
        alpha = self.alpha
        width = self.width
        color = self.color
        ptFill = self.ptFill
        ptAlpha = self.ptAlpha

        figs = []

        x = t
        y = func(t)
        pos = complex(x,y)

        # Initialize tangent line to be a horizontal
        # line segment of length 4 centered at the
        # origin
        if length != 0:
            line = morpho.grid.Path([-length/2, length/2])
            line.color = color
            line.alpha = alpha
            line.width = width

            # Compute derivative
            slope = derivative(func, t, dx=1e-4).tolist()
            # Convert into an angle and set it as the rotation
            # of the line segment
            angle = math.atan(slope)
            line.rotation = angle

            # Position the tangent line at the tangent point
            line.origin = x + 1j*y

            figs.append(line)

        if ptAlpha > 0:
            pt = mo.grid.Point(pos).set(
                size=15, strokeWeight=2, fill=ptFill,
                alpha=alpha*ptAlpha
                )
            figs.append(pt)

        return morpho.Frame(figs)

def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mation.endDelayUntil(1.5*30)
    print("Show my character shrugging:", mation.seconds())

    ks = mo.graphics.MultiImage("./resources/k-shrug.png").set(
        pos=0, height=10
        )
    ks = mo.Actor(ks)
    mainlayer.merge(ks)
    ks.fadeIn(20)

    mation.endDelayUntil(4.15*30)
    print("Show graph and label derivative and integral:", mation.seconds())

    ks.fadeOut(20)

    time = mation.lastID()
    gridlayer.camera.first().moveBy(-(-8-9.33j)).zoomIn(2.25, focus=0)
    gridview = [0,8, 0,8]

    gridlayer.camera.first().zoomOut(1.2)

    gridtop = gridlayer.copy()
    gridtop.mask = None
    mation.merge(gridtop, beforeLayer=mainlayer)

    gridlayer.mask = gridlayer.copy()
    gridbox = mo.grid.rect(gridview, pad=0.25)
    gridbox = mo.Actor(gridbox)
    gridlayer.mask.merge(gridbox, atFrame=time)

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid, atFrame=time)
    grid.growIn(30)

    axes = mo.grid.Path([0,10,0,10j]).set(
        width=10, color=[0,0,0], deadends={1},
        zdepth=10
        )
    axes = mo.Actor(axes)
    gridlayer.merge(axes, atFrame=time)
    axes.growIn(30)

    # time = mation.lastID()
    box = gridview[:]
    gridBG = mo.grid.rect(box).set(
        width=0, fill=[1,1,1], alphaFill=1
        )
    gridBG = mo.Actor(gridBG)
    gridlayer.merge(gridBG, atFrame=time, beforeActor=0)
    gridBG.fadeIn(30)

    time = mation.lastID()
    def f(x):
        return (4*x**3-51*x**2+180*x)/35
    graph = mo.graph.realgraph(f, 0, 8.5, steps=100).set(
        width=7, color=goodblue
        )
    graph = mo.Actor(graph)
    gridlayer.merge(graph, atFrame=time)
    graph.growIn(30)

    tanline = TangentLine(func=f, t=2)
    tanline = mo.Actor(tanline)
    gridlayer.append(tanline)
    tanline.newendkey(20).set(length=3, ptAlpha=1)

    ddt = mo.graphics.MultiImage("./resources/ddt-f(t).png").set(
        pos=tanline.last().positionAt()-0.1+0.25j, align=[1,-0.5],
        height=110, physical=False
        )
    ddt = mo.Actor(ddt)
    gridlayer.append(ddt)
    ddt.fadeIn(20, jump=-0.5+0.5j)

    area = mo.calculus.IntegralArea(
        func=f, start=0, end=0,
        strokeWeight=0, fill=goodblue, alpha=0.5
        )
    area = mo.Actor(area)
    gridlayer.append(area, beforeActor=graph)
    area.newendkey(30).end = 8

    integ = mo.graphics.MultiImage("./resources/integ-f(t).png").set(
        pos=4+2j, height=130, physical=False,
        background=[1,1,1], backPad=7, backAlpha=0.5
        )
    integ = mo.Actor(integ)
    gridlayer.append(integ)
    integ.fadeIn(20, jump=0j)

    mation.endDelayUntil(11*30)
    print("Show frac deriv symbol meandering:", mation.seconds())

    time = mation.lastID()
    fracder = mo.graphics.MultiImage("./resources/aDt-questions.png").set(
        pos=tanline.last().positionAt(4), height=65, physical=False,
        background=[1,1,1], backPad=7, backAlpha=0.75
        )
    fracder = mo.Actor(fracder)
    gridtop.merge(fracder, atFrame=time)
    fracder.fadeIn(15, jump=0.5j)








    print("Animation length:", mation.seconds())
    mation.endDelay(15*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = gridlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./17_nobody-knows.mp4", scale=1)


main()
