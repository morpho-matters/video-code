
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
brown = tuple(mo.color.parseHexColor("5c2912"))

dash = "\u2012"

morpho.anim.exportSignature = "09_divergent-integrals"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    colorlayer = mainlayer.copy()
    toplayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer, colorlayer, toplayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    colorlayer.mask = colorlayer.copy()
    colorlayer.mask.camera.first().visible = False

    gridlayer.camera.first().zoomIn(2.25, focus=0).moveBy(-(-2.5-3.5j))
    gridlayer.mask = gridlayer.copy()

    pformula = mo.graphics.MultiImage("./resources/p-integral-formula.png").set(
        pos=7j, height=2.25
        )
    pformula = mo.Actor(pformula)
    mainlayer.merge(pformula)

    mation.endDelayUntil(2.25*30)
    print("Show 'p = -1/2':", mation.seconds())

    neghalf = mo.graphics.MultiImage("./resources/p-eq-neg-half.png").set(
        pos=(-10.56+6.94j), height=1.25, align=[1,0]
        )
    neghalf = mo.Actor(neghalf)
    mainlayer.merge(neghalf)
    neghalf.fadeIn(20, jump=-3)

    arrow = mo.grid.Arrow(neghalf.last().pos+0.5)
    arrow.head = arrow.tail + 2
    arrow.set(width=5, color=[1,0,0], headSize=25)
    arrow = mo.Actor(arrow)
    mainlayer.append(arrow)
    arrow.growIn(20)

    mation.endDelayUntil(5*30)
    print("Morph into -1/2 integral formula:", mation.seconds())

    time = mation.lastID()
    pformula.newkey(time)
    pformula.newendkey(20).newSource("./resources/neg-half-integral-formula.png").scaleByHeight()

    # mo.action.fadeOut([arrow, neghalf], atFrame=time, duration=20)
    neghalf.fadeOut(20, atFrame=time, jump=5)
    arrow.shrinkOut(20, atFrame=time, reverse=True)


    mation.endDelayUntil(7.5*30)
    print("Enbox the integral portion:", mation.seconds())

    iboxer = mo.gadgets.enbox([0.89, 10.37, 5.59, 8.41],
        width=5, color=[1,0,0], duration=30
        )
    mainlayer.append(iboxer)

    mation.endDelay(15)
    print("Show graph:", mation.seconds())

    time = mation.lastID()
    gridview = [0,5, 0,5]
    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid, atFrame=time)
    grid.growIn(30)

    axes = mo.grid.axes(gridview, width=10, color=[0,0,0]).set(zdepth=10)
    axes = mo.Actor(axes)
    gridlayer.merge(axes, atFrame=time)
    axes.growIn(30)

    bg = mo.grid.rect(gridview).set(width=0, fill=[1,1,1])
    bg = mo.Actor(bg)
    gridlayer.merge(bg, atFrame=time, beforeActor=0)
    bg.fadeIn(30)

    maskview = gridview[:]
    maskview[-2] -= 1
    mask = mo.grid.rect(maskview, pad=0.2).set(width=0)
    mask = mo.Actor(mask)
    gridlayer.mask.merge(mask)
    gridlayer.mask.camera.newkey(time)
    gridlayer.mask.camera.first().visible = False

    b = 4
    delta = 0.01
    def f(x): return (b-x)**(-1/2-1)
    curve = mo.graph.realgraph(f, 0, b-delta, steps=150).set(
        width=7, color=violet
        )
    curve = mo.Actor(curve)
    gridlayer.append(curve)
    curve.growIn(20)

    asm = mo.grid.Path([5.25j, 0j]).set(
        width=6, color=[0,0,1], dash=[20,15],
        origin=4, # zdepth=100,
        outlineWidth=1.5, outlineColor=[1,1,1]
        )
    asm = mo.Actor(asm)
    gridlayer.append(asm)
    asm.growIn(20)

    time = mation.lastID()

    tlabel = mo.text.Text("t",
        pos=4-0.4j, italic=True,
        size=64, color=violet
        )
    tlabel = mo.Actor(tlabel)
    gridlayer.append(tlabel)
    tlabel.fadeIn(20, jump=-0.5j)

    # mation.endDelay(10)

    def f_modified(x):
        return f(x) if x <= b-delta else 10
    area = mo.calculus.IntegralArea(f_modified, 0, 0,
        strokeWeight=0, fill=violet, alpha=0.45,
        steps=50
        )
    area = mo.Actor(area)
    gridlayer.merge(area, atFrame=time, beforeActor=curve)
    area.newendkey(30).end = 4

    badinteg = mo.graphics.MultiImage("./resources/bad-integral.png").set(
        pos=(7.09+2.22j), align=[-1,0], height=2.25
        )
    badinteg = mo.Actor(badinteg)
    mainlayer.merge(badinteg, atFrame=time)
    badinteg.fadeIn(20, jump=-2j)

    div = mo.graphics.MultiImage("./resources/diverges-for.png").set(
        pos=badinteg.last().pos-2j, align=[-1,0], height=0.8
        )
    div = mo.Actor(div)
    mainlayer.append(div, timeOffset=-10)
    div.fadeIn(20, jump=-2j)


    # time = mation.lastID()
    oolabel = mo.graphics.MultiImage("./resources/oo.png").set(
        pos=(3.41+0.53j), height=50, physical=False
        )
    oolabel = mo.Actor(oolabel)
    gridlayer.merge(oolabel, atFrame=time)
    oolabel.fadeIn(20, jump=0j)

    mation.endDelayUntil(18.5*30)
    print("Revert and state condition 'p > 0':", mation.seconds())

    time = mation.lastID()
    mo.action.rollback([oolabel, div, badinteg, area, tlabel,
        asm, curve, bg, axes, grid],
        atFrame=time, duration=20, stagger=3)

    gridlayer.mask.camera.newkey(mation.lastID()).visible = False

    iboxer.fadeOut(30, atFrame=time)

    pformula.newkey(time)
    pformula.newendkey(30, pformula.first().copy())

    time = mation.lastID()
    onlyfor = mo.graphics.MultiImage("./resources/only-for.png").set(
        pos=(8.02+4.59j), align=[1,0], height=48, physical=False
        )
    onlyfor = mo.Actor(onlyfor)
    mainlayer.merge(onlyfor, atFrame=time)
    onlyfor.fadeIn(20, jump=-2j)

    mation.endDelayUntil(25.5*30)
    print("Remove 'p > 0':", mation.seconds())

    onlyfor.fadeOut(20)

    mation.endDelayUntil(32.5*30)
    print("Show integral and d/dx creatures:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    serpent = mo.graphics.Image("./resources/serpentine-integral.png").set(
        pos=(-5.2-4j), align=[0,-1], height=6
        )
    serpent = mo.Actor(serpent)
    mainlayer.merge(serpent, atFrame=time)
    serpent.fadeIn(20)

    mation.endDelay(20)

    time = mation.lastID()
    ddx = mo.graphics.Image("./resources/ddx.png").set(
        pos=-serpent.last().pos.conjugate(), align=[0,-1], height=4
        )
    ddx = mo.Actor(ddx)
    mainlayer.merge(ddx, atFrame=time)
    ddx.fadeIn(20)

    mation.endDelayUntil(38.25*30)
    print("Move them together to collide:", mation.seconds())

    time = mation.lastID()
    collidepos = serpent.last().pos.imag*1j
    for creature in [serpent, ddx]:
        creature.newkey(time).transition = drop
        creature.newendkey(20).set(transition=toss).pos = collidepos
    serpent.newendkey(20).set(
        transform=[[1,1],[1,1]], alpha=0.5, align=[0,0], visible=False
        ).pos += 2j
    ddx.newendkey(20).set(
        transform=mo.array([[1,-1],[-1,1]]).T, alpha=0.5, align=[0,0],
        visible=False
        ).pos += 2j

    mation.endDelayUntil(43*30)
    print("Show cancellation formula:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    cancel = mo.graphics.MultiImage("./resources/cancellation.png").set(
        pos=2.35j, height=2
        )
    cancel = mo.Actor(cancel)
    mainlayer.append(cancel)
    cancel.fadeIn(20, jump=2j)

    mation.endDelayUntil(53.25*30)
    print("Fade cancellation formula:", mation.seconds())

    cancel.fadeOut(20)

    mation.endDelayUntil(58*30)
    print("Show half-integral notation:", mation.seconds())

    hformula = mo.Actor(pformula.last().copy())
    mainlayer.append(hformula, timeOffset=1)
    hformula.newendkey(20).newSource("./resources/half-integral-expression.png") \
        .scaleByHeight().pos -= 4j

    mation.endDelayUntil(61*30)
    print("Apply d/dt:", mation.seconds())

    hformula.newendkey(20).newSource("./resources/deriv-of-half-integ.png") \
        .scaleByHeight().height = 2.7

    mation.endDelayUntil(64.25*30)
    print("Tack on half-deriv symbol to LHS:", mation.seconds())

    time = mation.lastID()
    hformula.newendkey(20).align = [-1,0]

    halfderiv = mo.graphics.MultiImage("./resources/half-deriv-f(t)-eq.png").set(
        pos=hformula.last().pos-0.5, align=[1,-0.1], height=2.5
        )
    halfderiv = mo.Actor(halfderiv)
    mainlayer.merge(halfderiv, atFrame=time)
    halfderiv.fadeIn(20, jump=-3)

    mation.endDelayUntil(66.25*30)
    print("Show 'order = 1/2':", mation.seconds())

    left = 0.89+1.14
    right = 6.31+1.14
    vert = 1.22
    orderhalf = mo.graphics.MultiImage("./resources/order-half.png").set(
        pos=mean([left, right])+1j*vert, align=[0,1],
        width=right-left, scale_x=0
        )
    orderhalf = mo.Actor(orderhalf)
    mainlayer.append(orderhalf)
    orderhalf.newendkey(20).scale_x = 1

    mation.endDelayUntil(69*30)
    print("Show 'effective order':", mation.seconds())

    left = -1.19+1.14
    right = 7.04+1.14
    vert = -0.26
    efforder = mo.graphics.MultiImage("./resources/effective-order.png").set(
        pos=mean([left, right])+1j*vert, align=[0,1],
        width=1.07*(right-left), scale_x=0
        )
    efforder = mo.Actor(efforder)
    mainlayer.append(efforder)
    efforder.newendkey(20).scale_x = 1

    mation.endDelayUntil(30*minsec(1.195))
    print("Expand 1/2-integral and highlight orders:", mation.seconds())

    time = mation.lastID()
    hformula.newkey(time)
    hformula.newendkey(20).newSource("./resources/ddt-half-integral-formula.png").scaleByHeight()
    hformula.last().set(height=2.25).pos -= 3.5

    halfderiv.newkey(time)
    halfderiv.newendkey(20).pos -= 3.5

    mo.action.fadeOut([efforder, orderhalf], atFrame=time, duration=20)

    mation.endDelay(10)

    time = mation.lastID()
    circ1 = mo.grid.ellipse(-0.3+2.37j, 0.75).edge().set(
        width=4, color=goodblue
        )
    circ1 = mo.Actor(circ1)
    mainlayer.merge(circ1, atFrame=time)
    circ1.growIn(20)

    circ2 = mo.grid.ellipse((5.04+3.33j), 0.5).edge().set(
        width=4, color=goodblue
        )
    circ2 = mo.Actor(circ2)
    mainlayer.merge(circ2, atFrame=time)
    circ2.growIn(20)

    mation.endDelayUntil(30*minsec(1.315))
    print("Fade encirclings:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([circ1, circ2, pformula], atFrame=time, duration=20)

    mation.endDelayUntil(30*minsec(1.335))
    print("'Legit!':", mation.seconds())

    boxer = mo.gadgets.enbox([-10.5,10.5, 1.31,4.63],
        width=5, color=goodblue, fill=[1,1,1]
        )
    mainlayer.append(boxer, beforeActor=0)
    boxer.newendkey(20).alphaFill = 1

    legit = mo.text.Text("Legit!",
        pos=(5.1j), align=[0,-1],
        size=64, color=goodblue
        )
    legit = mo.Actor(legit)
    mainlayer.append(legit, timeOffset=-20, beforeActor=0)
    legit.fadeIn(20, jump=2j)

    mation.endDelayUntil(30*minsec(1.405))
    print("Prepare to do example:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    legit.rollback(20)

    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(20).moveBy(-2.5j)

    # mation.endDelayUntil(30*minsec(1.425))
    mation.endDelay(10)
    print("Show f(x) = x^2:", mation.seconds())

    fdef = mo.graphics.MultiImage("./resources/fdef.png").set(
        pos=legit.key[1].pos, align=[0,-1], height=1.1
        )
    fdef = mo.Actor(fdef)
    mainlayer.append(fdef)
    fdef.fadeIn(20, jump=2j)

    # mation.endDelayUntil(30*minsec(1.445))
    mation.endDelay(15)
    print("Compute the half-derivative:", mation.seconds())

    test1 = halfderiv.last().copy()
    test1 = mo.Actor(test1)
    mainlayer.append(test1, timeOffset=1)
    test1.newendkey(20, mo.graphics.MultiImage("./resources/half-deriv-test1.png")).set(
        pos=-1.5j, height=2.5
        )

    mation.endDelay(5)

    test2 = test1.last().copy()
    test2 = mo.Actor(test2)
    mainlayer.append(test2, timeOffset=1)
    test2.newendkey(20).newSource("./resources/half-deriv-test2.png").scaleByHeight()
    test2.last().set(pos=(-5.09-4.65j), align=[-1,0]).height *= 0.9

    mation.endDelay(5)

    test3 = test2.last().copy()
    test3 = mo.Actor(test3)
    mainlayer.append(test3, timeOffset=1)
    test3.newendkey(20).newSource("./resources/half-deriv-test3.png").scaleByHeight()
    test3.last().pos -= 3j
    test3.last().height *= 0.95

    mation.endDelayUntil(30*minsec(1.505))
    print("Compare to half-integral of 2x:", mation.seconds())

    # test3.newendkey(20).newSource("./resources/half-deriv-test4.png").scaleByHeight()
    # test3.last().height *= 1.1

    test4 = mo.graphics.MultiImage("./resources/eq-half-integral.png").set(
        pos=test3.last().pos+test3.last().width+0.5, align=[-1,0],
        height=test3.last().height*1.1
        )
    test4 = mo.Actor(test4)
    mainlayer.append(test4)
    test4.fadeIn(20, jump=3)

    # mation.endDelayUntil()
    # print("Convert t to x:", mation.seconds())

    # time = mation.lastID()
    # mo.action.fadeOut([test4, test2, test1, fdef], duration=20)

    # time = mation.lastID()
    # xformula = mo.graphics.MultiImage("./resources/pi-x32.png").set(
    #     pos=test3.last().pos.real+1-1j, align=[-1,0],
    #     height=test3.last().height
    #     )
    # xformula = mo.Actor(xformula)
    # mainlayer.merge(xformula, atFrame=time)
    # xformula.fadeIn(20, jump=5j)

    # darrow = mo.grid.Arrow().set(
    #     headSize=30, width=5, color=[0,0.6,0]
    #     )
    # darrow.tail = test3.last().pos+test3.last().width/2 + 1.5j
    # darrow.head = darrow.tail.real + 1j*xformula.last().pos.imag - 1.5j
    # darrow = mo.Actor(darrow)
    # mainlayer.merge(darrow, atFrame=time)
    # darrow.growIn(20)
    # darrow.shrinkOut(20, reverse=True)

    mation.endDelayUntil(30*minsec(1.5575))
    print("Plug into formula:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([test4, test2, test1, fdef], atFrame=time, duration=20)
    xformula = test3

    time = mation.lastID()
    xformula.newkey(time)
    xformula.newendkey(20).newSource("./resources/half-deriv-complex.png") \
        .scaleByHeight().set(pos=test1.last().pos, align=[0,0])
    xformula.last().height *= 1.1

    mation.endDelay(15)

    derivt2 = mo.graphics.MultiImage("./resources/ddt-t2.png").set(
        pos=-4.83+xformula.last().pos.imag*1j-3.5j, align=[-1,0],
        height=1.85
        )
    derivt2 = mo.Actor(derivt2)
    mainlayer.append(derivt2)
    derivt2.fadeIn(20, jump=-3.5j)

    mation.endDelay(10)

    twot = mo.graphics.MultiImage("./resources/eq-2t.png").set(
        pos=derivt2.last().pos+derivt2.last().width+0.5,
        align=[-1,0], height=0.65
        )
    twot = mo.Actor(twot)
    mainlayer.append(twot)
    print("Show 2t:", mation.seconds())
    twot.fadeIn(20, jump=2)

    mation.endDelay(10)

    twoboxer = mo.gadgets.enbox(twot.last().box(pad=0.25),
        width=4, color=goodblue, duration=20
        )
    mainlayer.append(twoboxer)

    mation.endDelayUntil(30*minsec(2.045))
    print("Flourish the half-derivative formula:", mation.seconds())

    time = mation.lastID()
    boxer.newkey(time)
    boxer.newendkey(15).set(color=[1,1,0]).width *= 2
    boxer.newendkey(15, boxer.key[-2].copy())

    mation.endDelayUntil(30*minsec(2.085))
    print("Rollback all but the half-deriv formula:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    mo.action.fadeOut([twoboxer, twot, derivt2, xformula],
        atFrame=time, duration=20, stagger=4, jump=2j
        )
    mo.action.rollback(boxer, atFrame=time, duration=30)

    mation.endDelayUntil(30*minsec(2.10))
    print("Show p-derivative symbol:", mation.seconds())

    time = mation.lastID()
    halfderiv.newkey(time).visible = False
    hformula.newkey(time).visible = False

    pderiv = mo.graphics.MultiImage()
    pderiv.figures = halfderiv.last().figures + hformula.last().figures
    pderiv = mo.Actor(pderiv)
    mainlayer.append(pderiv)
    pderiv.newendkey(20, mo.graphics.MultiImage("./resources/p-ddt-f(t).png").set(
        pos=halfderiv.last().pos+1, align=[1,0],
        height=0.9*halfderiv.last().height
        ))

    mation.endDelayUntil(30*minsec(2.17))
    print("Show alpha-integral:", mation.seconds())

    rhs = mo.graphics.MultiImage("./resources/eq-alpha-integ.png").set(
        pos=pderiv.last().pos+0.5, align=[-1,0],
        height=pderiv.last().height
        )
    rhs = mo.Actor(rhs)
    mainlayer.append(rhs)
    rhs.fadeIn(20, jump=3)

    mation.endDelayUntil(30*minsec(2.2025))
    print("'where p + alpha = k':", mation.seconds())

    where = mo.graphics.MultiImage("./resources/p-alpha-k.png").set(
        pos=rhs.last().pos+rhs.last().width+1.5, align=[-1,0],
        height=0.85
        )
    where = mo.Actor(where)
    mainlayer.append(where)
    where.fadeIn(20, jump=3)

    mation.endDelayUntil(30*minsec(2.2515))
    print("Tack on (d/dt)^k:", mation.seconds())

    time = mation.lastID()
    rhs.newkey(time)
    rhs.newendkey(20).newSource("./resources/eq-deriv-integ.png").scaleByHeight()

    where.newkey(time)
    where.newendkey(20).pos += 2

    mation.endDelayUntil(30*minsec(2.325))
    print("Expand the RHS:", mation.seconds())

    rhs2 = rhs.last().copy()
    rhs2 = mo.Actor(rhs2)
    mainlayer.append(rhs2, timeOffset=1)
    rhs2.newendkey(20).newSource("./resources/frac-deriv-rhs.png") \
        .scaleByHeight().pos -= 3j

    mation.endDelay(10)

    time = mation.lastID()
    mainlayer.camera.newkey(time)
    mainlayer.camera.newendkey(20).moveBy(5)

    # mation.endDelay(10)

    mation.endDelayUntil(30*minsec(2.3525))
    print("Label the RL Derivative:", mation.seconds())

    title = mo.text.Text("Riemann-Liouville Fractional Derivative",
        pos=8.25j,
        size=64, color=[0.8,0,0]
        )
    title = mo.Actor(title)
    toplayer.merge(title, atFrame=mation.lastID())
    title.fadeIn(20, jump=2j)

    mation.endDelayUntil(30*minsec(2.4025))
    print("Show special fractional deriv symbol:", mation.seconds())

    time = mation.lastID()
    pderiv.newkey(time)
    pderiv.newendkey(20).newSource("./resources/fracder-f(t).png") \
        .scaleByHeight().height *= 0.45

    symboxer = mo.gadgets.enbox(pderiv.last().box(pad=0.25),
        width=5, color=[1,0,0], duration=20
        )
    mainlayer.append(symboxer)
    symboxer.shrinkOut(20, reverse=True)

    mation.endDelayUntil(30*minsec(2.495))
    print("Show piecewise derivagral formula:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([rhs2, title], atFrame=time, duration=20)

    pderiv.newkey(time)
    pderiv.newendkey(30).pos += 3-3j

    rhs.newkey(time)
    rhs.newendkey(30).newSource("./resources/derivagral-rhs.png").scaleByHeight()
    rhs.last().pos = pderiv.last().pos + 0.5
    rhs.last().height *= 2.25

    where.newkey(time)
    where.newendkey(30).pos = where.last().pos.real - 3.56j

    mation.endDelayUntil(30*minsec(3.09))
    print("Label 'differintegral':", mation.seconds())

    time = mation.lastID()
    differint = mo.text.Text("Differintegral",
        pos=7j,
        size=72, color=[0,0,0]
        )
    differint = mo.Actor(differint)
    colorlayer.mask.merge(differint, atFrame=time)
    differint.fadeIn(20, jump=2j)

    colorlayer.mask.camera.newkey(time).visible = True

    gradfill = mo.color.LinearGradientFill(-4, 4, mo.color.Gradient({
        0: [1,0,0],
        1: violet
        }))
    back = mo.grid.rect(colorlayer.camera.first().view).set(
        width=0, fill=gradfill
        )
    back = mo.Actor(back)
    colorlayer.merge(back, atFrame=time)

    mation.endDelayUntil(30*minsec(3.125))
    print("Show outraged character:", mation.seconds())

    kman = mo.graphics.MultiImage("./resources/k-outraged.png").set(
        pos=(-13.31+7.72j), align=[0,1], height=8, scale_x=-1
        )
    kman = mo.Actor(kman)
    toplayer.merge(kman, atFrame=mation.lastID())
    kman.fadeIn(20)

    mation.endDelayUntil(30*minsec(3.1525))
    print("Label 'Derivagral':", mation.seconds())

    derivagral = mo.text.Text("Derivagral!",
        pos=(-8.37+7.13j), align=[0,-1], font="Qarmic sans",
        size=48, color=[0,0,0]
        )
    derivagral = mo.Actor(derivagral)
    toplayer.append(derivagral)
    derivagral.fadeIn(20, jump=2+2j)

    arc = mo.grid.arc(-10+6.78j, (-11.13+5.54j), angle=-80*deg).set(
        width=4, color=[0,0,0]
        )
    arc = mo.Actor(arc)
    toplayer.append(arc)
    arc.growIn(20)

    # derivagral = mo.text.Text("Derivagral",
    #     pos=-2j,
    #     size=72
    #     )
    # derivagral = mo.Actor(derivagral)
    # colorlayer.mask.append(derivagral)
    # derivagral.fadeIn(20, jump=-2j)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = toplayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./09_divergent-integrals.mp4", scale=1)


main()
