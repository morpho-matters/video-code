
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())

dash = "\u2012"

morpho.anim.exportSignature = "07_to-derivs"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mainlayer.camera.first().moveBy(2j)

    pformula = mo.graphics.MultiImage("./resources/p-integral-formula.png").set(
        pos=7j, height=2.25
        )
    pformula = mo.Actor(pformula)
    mainlayer.merge(pformula)

    mation.endDelayUntil(5.5*30)
    print("Show Cauchy formula:", mation.seconds())

    cauchy = mo.graphics.MultiImage("./resources/cauchy-formula.png").set(
        pos=3.5j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    mainlayer.append(cauchy)
    cauchy.fadeIn(20, jump=-2j)

    mation.endDelayUntil(10.75*30)
    print("Simult enbox factorial and gamma:", mation.seconds())

    time = mation.lastID()
    gbox = [-2.22, -0.31, 5.69, 6.96]
    fbox = [-2.87, 0.48, 2.2, 3.46]
    gboxer = mo.gadgets.enbox(gbox, width=5, color=goodblue)
    fboxer = mo.gadgets.enbox(fbox, width=5, color=[1,0,0])
    mainlayer.merge([gboxer, fboxer], atFrame=time)

    mation.endDelayUntil(18*30)
    print("Fade boxes and Cauchy formula:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([fboxer, gboxer, cauchy], atFrame=time, duration=20)

    mation.endDelayUntil(22.15*30)
    print("Encircle all occurrences of 'p':", mation.seconds())

    pcircs = []
    centers = [(-7.93, 6.28), (-3.63, 7.22), (-0.94, 6.3), (4.37, 7.26)]
    centers = [complex(*v) for v in centers[:]]
    radii = [0.5, 0.5, 0.7, 1]
    yradii = radii[:]
    yradii[-1] = 0.5
    for n in range(len(radii)):
        pcirc = mo.grid.ellipse(centers[n], radii[n], yradii[n]).edge().set(
            width=5, color=[0,0,1]
            )
        pcirc = mo.Actor(pcirc)
        mainlayer.append(pcirc)
        pcircs.append(pcirc)
    mo.action.growIn(pcircs, duration=20, stagger=4)

    mation.endDelayUntil(30.5*30)
    print("Fade out encirclings and show deriv attempt:", mation.seconds())

    mo.action.fadeOut(pcircs, duration=20)

    implies = mo.graphics.MultiImage("./resources/implies.png").set(
        pos=pformula.last().pos-3j, height=1, rotation=-tau/4
        )
    implies = mo.Actor(implies)
    mainlayer.append(implies)

    dguess = mo.graphics.MultiImage("./resources/deriv-as-integ.png").set(
        pos=implies.last().pos-3j, height=2.5
        )
    dguess = mo.Actor(dguess)
    mainlayer.append(dguess)

    mo.action.fadeIn([implies, dguess], duration=20, stagger=15, jump=-2j)

    mation.endDelayUntil(36.25*30)
    print("Morph to half-derivative version:", mation.seconds())

    time = mation.lastID()
    dguess.newkey(time)
    dguess.newendkey(20).newSource("./resources/half-deriv-as-integ.png").scaleByHeight()

    mation.endDelayUntil(42.5*30)
    print("Show negative first integral:", mation.seconds())

    ninteg = mo.graphics.MultiImage("./resources/neg1-integ.png").set(
        pos=dguess.last().pos-4j, height=2.25
        )
    ninteg = mo.Actor(ninteg)
    mainlayer.append(ninteg)
    ninteg.fadeIn(20, jump=-2j)

    mation.endDelayUntil(52.25*30)
    print("Show label:", mation.seconds())

    canwe = mo.text.paragraph(
        [mo.text.Text("Can", color=[0,0,0]),
        mo.text.Text(" integrals  ", bold=True, italic=True, color=violet),
        mo.text.Text("compute", color=[0,0,0]),
        mo.text.Text(" derivatives???", bold=True, italic=True, color=[0.8,0,0])],
        mainlayer.camera.first().view, mation.windowShape,
        pos=10j, size=64
        )
    canwe = mo.Actor(canwe)
    mainlayer.append(canwe)
    canwe.fadeIn(20, jump=2j)

    mation.endDelayUntil(57*30)
    print("Fade and show serpentine integral:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([canwe, ninteg, dguess, implies],
        atFrame=time, duration=20
        )

    # mation.endDelay(10)

    serpent = mo.graphics.MultiImage("./resources/serpentine-integral.png").set(
        pos=-4-5j, align=[0,-1], height=7
        )
    serpent = mo.Actor(serpent)
    mainlayer.append(serpent)
    serpent.fadeIn(20)

    mation.endDelay(10)

    stoop = mo.text.paragraph("I will not stoop\nto such lowssss...",
        mainlayer.camera.first().view, mation.windowShape,
        pos=(0.74+2.46j), size=32, color=[0,0,0], font="Qarmic sans",
        align=[0,-1], ygap=10
        )
    stoop = mo.Actor(stoop)
    mainlayer.append(stoop)
    stoop.fadeIn(15, jump=2+2j)

    arc = mo.grid.arc((-0.04+2.06j), (-1.2-0.28j+1j), angle=-80*deg).set(
        width=4, color=[0,0,0]
        )
    arc = mo.Actor(arc)
    mainlayer.append(arc)
    arc.growIn(15)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./07_to-derivs.mp4", scale=1)


main()
