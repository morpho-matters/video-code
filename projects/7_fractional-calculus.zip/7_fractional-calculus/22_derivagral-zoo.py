
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad
from scipy.special import gamma

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))
darkgreen = dgreen = tuple(mo.color.parseHexColor("008000"))
beet = tuple(mo.color.parseHexColor("80003a"))
brown = tuple(mo.color.parseHexColor("5c2912"))


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "22_derivagral-zoo"



def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    lastthing = mo.text.Text("One last thing!",
        pos=0,
        size=72, color=[0,0,0]
        ).set(transition=drop)
    lastthing = mo.Actor(lastthing)
    mainlayer.merge(lastthing)

    mation.endDelayUntil(5*30)
    print("Remove title:", mation.seconds())

    lastthing.fadeOut(30, jump=3j)

    mation.endDelay(10)

    mation.endDelayUntil(7*30)
    print("Show frac deriv symbol:", mation.seconds())

    fracder = mo.graphics.MultiImage("./resources/fracder-f(t).png").set(
        pos=5j, height=1.3
        )
    fracder = mo.Actor(fracder)
    mainlayer.append(fracder)
    fracder.fadeIn(20, jump=2j)

    mation.endDelayUntil(10.65*30)
    print("Show alpha fractional integral:", mation.seconds())

    fracder.newendkey(20).set(align=[1,0]).pos -= 3

    time = mation.lastID()
    eq = mo.graphics.MultiImage("./resources/eq.png").set(
        pos=fracder.last().pos, align=[-1,0], height=1.25
        )
    eq = mo.Actor(eq)
    mainlayer.append(eq)
    eq.fadeIn(20, jump=2)

    integ = mo.graphics.MultiImage("./resources/alpha-integral-sign.png").set(
        pos=eq.last().pos+eq.last().width, align=[-1,0], height=3
        )
    integ = mo.Actor(integ)
    mainlayer.append(integ, timeOffset=-15)
    integ.fadeIn(20, jump=2)

    integrand = mo.graphics.MultiImage("./resources/f(x)-dx-alpha.png").set(
        pos=integ.last().pos+integ.last().width+0.25, align=[-1,0],
        height=integ.last().height
        )
    integrand = mo.Actor(integrand)
    mainlayer.append(integrand, timeOffset=-15)
    integrand.fadeIn(20, jump=3)

    mation.endDelayUntil(13*30)
    print("Prepend the k-th derivative:", mation.seconds())

    time = mation.lastID()
    # integ.newendkey(20).newSource("./resources/frac-integral-condensed.png").scaleByHeight()
    ddt = mo.graphics.MultiImage("./resources/ddt-k.png").set(
        pos=integ.last().pos, align=[-1,0], height=integ.last().height
        )
    ddt = mo.Actor(ddt)
    mainlayer.merge(ddt, atFrame=time)
    ddt.fadeIn(20, jump=2j)

    for actor in [integ, integrand]:
        actor.newkey(time)
        actor.newendkey(20).pos += ddt.last().width+0.25

    mation.endDelayUntil(20.25*30)
    print("Show effective order:", mation.seconds())

    eff = mo.graphics.MultiImage("./resources/effective-order2.png").set(
        pos=eq.last().pos.imag*1j-3.5j, height=1
        )
    eff = mo.Actor(eff)
    mainlayer.append(eff)
    eff.fadeIn(20, jump=-2j)

    # mation.endDelayUntil()
    # print("Rollback effective order label:", mation.seconds())

    # eff.rollback(20)

    mation.endDelayUntil(32.65*30)
    print("Show swapping arrows:", mation.seconds())

    time = mation.lastID()
    swaptop = mo.grid.arc(0.24+6.8j, (3.69+6.8j), angle=-90*deg).set(
        width=5, color=[1,0,0], headSize=25
        )
    swaptop = mo.Actor(swaptop)
    mainlayer.append(swaptop)

    swapbot = mo.grid.arc((3.69+3.15j), 0.24+3.15j, angle=-90*deg).set(
        width=5, color=[0,0,1], headSize=25
        )
    swapbot = mo.Actor(swapbot)
    mainlayer.append(swapbot)

    mo.action.growIn([swaptop, swapbot], 20)

    mation.endDelay(30)
    print("Animate the swap:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    integ.newkey(time)
    integ.newendkey(20).pos = ddt.last().pos
    integ.key(-2).tweenMethod = integ.figureType.tweenPivot(-100*deg)

    ddt.newkey(time)
    ddt.newendkey(20).pos += integ.last().width + 0.5
    ddt.key(-2).tweenMethod = ddt.figureType.tweenPivot(-100*deg)
    ddt.last().newSource("./resources/ddx-k.png").scaleByHeight()

    mo.action.shrinkOut([swaptop, swapbot], 20, atFrame=time, reverse=True)

    mation.endDelayUntil(49.5*30)
    print("Show not equal to original:", mation.seconds())

    time = mation.lastID()
    eff.rollback(20, atFrame=time)

    time = mation.lastID()
    yshift = -6.5
    fracder2 = mo.Actor(fracder.last().copy())
    mainlayer.merge(fracder2, atFrame=time)
    fracder2.newendkey(30).pos += yshift*1j

    eq2 = mo.Actor(eq.last().copy())
    mainlayer.merge(eq2, atFrame=time)
    eq2.newendkey(30).pos += yshift*1j

    ddt2 = mo.Actor(ddt.last().copy())
    mainlayer.merge(ddt2, atFrame=time)
    ddt2.newendkey(30, ddt.key(-2).copy()).pos += yshift*1j

    integ2 = mo.Actor(integ.last().copy())
    mainlayer.merge(integ2, atFrame=time)
    integ2.newendkey(30, integ.key(-2).copy()).pos += yshift*1j

    integrand2 = mo.Actor(integrand.last().copy())
    mainlayer.merge(integrand2, atFrame=time)
    integrand2.newendkey(30).pos += yshift*1j

    time = mation.lastID()
    neq = mo.graphics.MultiImage("./resources/neq.png").set(
        pos=ddt.last().pos+yshift/2*1j, height=1, alpha=0
        )
    neq = mo.Actor(neq)
    mainlayer.merge(neq, atFrame=time)
    neq.newendkey(20).set(height=1.5, alpha=1, rotation=-90*deg)

    mation.endDelayUntil(56*30)
    print("Order matters!")

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    ordermatters = mo.text.Text("Order matters!",
        pos=(1.63-5.5j),
        size=84, color=[1,0,0]
        )
    ordermatters = mo.Actor(ordermatters)
    mainlayer.append(ordermatters)
    ordermatters.fadeIn(20, jump=-3j)

    mation.endDelayUntil(60*30)
    print("Fade the 'order matters' label:", mation.seconds())

    ordermatters.fadeOut(20)

    mation.endDelayUntil(30*minsec(1.1015))
    print("Enbox ddx:", mation.seconds())

    dboxer = mo.gadgets.enbox([1.2, 4.87, 3.24, 6.69],
        width=5, color=redderorange, duration=20
        )
    mainlayer.append(dboxer)

    mation.endDelayUntil(30*minsec(1.1185))
    print("Enbox integral:", mation.seconds())

    jboxer = mo.gadgets.enbox([-1.22,0.96, 3.33, 6.65],
        width=5, color=goodblue, duration=20
        )
    mainlayer.append(jboxer)

    mation.endDelayUntil(30*minsec(1.135))
    print("Label 'Caputo':", mation.seconds())

    time = mation.lastID()
    fracder.newkey(time)
    fracder.newendkey(20).newSource("./resources/caputo-fracder-f(t).png").scaleByHeight()
    fracder.last().height *= 1.1

    caputo = mo.text.Text("Caputo Fractional Derivative",
        pos=1+7.54j,
        size=64, color=dgreen
        )
    caputo = mo.Actor(caputo)
    mainlayer.merge(caputo, atFrame=time)
    caputo.fadeIn(20, jump=2j)

    mo.action.fadeOut([dboxer, jboxer], 20, atFrame=time)

    mation.endDelayUntil(30*minsec(1.17))
    print("Show the 'slew' of fractional derivatives:", mation.seconds())

    dnames = "Caputo,Riemann-Liouville,Gr\u00fcnwald-Letnikov,Weyl,Marchaud,Hadamard,Chen,Davidson-Essex,Coimbra,Canavati,Jumarie,Riesz,Cossar,Yang,Osler,Hilfer".split(",")
    dnames.sort()
    dnames.remove("Coimbra")
    # for name in dnames: print(name)
    # return

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    actors = [caputo, fracder, eq, integ, ddt, integrand, neq, fracder2, eq2, ddt2, integ2, integrand2]
    for actor in actors:
        actor.last().tweenMethod = actor.figureType.tweenLinear
    mo.action.fadeOut(actors,
        duration=20, atFrame=time, stagger=2, jump=2j
        )

    mation.endDelay(10)

    time = mation.lastID()
    dlabels = []
    pos0 = -15+7.5j
    pos = pos0
    dy = 2
    colmax = 8
    for n,name in enumerate(dnames):
        dlabel = mo.text.Text(name+" derivative",
            pos=pos, align=[-1,0],
            size=56, color=[0,0,0]
            )
        dlabel = mo.Actor(dlabel)
        dlabels.append(dlabel)
        if name == "Riemann-Liouville":
            RLlabel = dlabel
        pos -= dy*1j
        if n+1 == colmax:
            xshift = 3+max(dlabel.last().width(mainlayer.camera.last().view, mation.windowShape) for dlabel in dlabels)
            pos = pos0 + xshift

    voldy = mo.text.paragraph(
        [[mo.text.Text("Voldemort derivative", size=dlabel.last().size)],
        [mo.text.Text("(ok, this one's fake)", size=24, bold=True)]],
        mainlayer.camera.last().view, mation.windowShape,
        pos=pos, color=[0,0,0], align=[-1,0.65], flush=1
        )
    voldy = mo.Actor(voldy)
    dlabels.append(voldy)

    others = dlabel.last().copy().set(
        text="...and others", pos=(-1-8.39j), align=[0,0],
        size=56, italic=True
        )
    others = mo.Actor(others)
    dlabels.append(others)

    mainlayer.append(dlabels)
    mo.action.fadeIn(dlabels, duration=20, stagger=3, jump=2j)

    mation.endDelay(30)

    kman = mo.graphics.MultiImage("./resources/k-screaming.png").set(
        pos=(-1-2.19j), align=[0,-1], height=8, scale_x=1
        )
    kman = mo.Actor(kman)
    mainlayer.append(kman)
    kman.fadeIn(20)

    mation.endDelayUntil(30*minsec(1.25))
    print("Show the formula for the RL derivative:", mation.seconds())

    time = mation.lastID()
    dlabels.remove(RLlabel)
    mo.action.fadeOut(dlabels, 20, atFrame=time)

    kman.fadeOut(20, atFrame=time)

    RLlabel.newkey(time)
    RLlabel.newendkey(30).set(pos=8j, align=[0,0], size=64)

    RLformula = mo.graphics.MultiImage("./resources/frac-deriv-def.png").set(
        pos=5j, height=3
        )
    RLformula = mo.Actor(RLformula)
    mainlayer.append(RLformula)
    RLformula.fadeIn(20, jump=2j)

    boxer = mo.gadgets.enbox(RLformula.last().box(pad=0.3),
        width=5, color=goodblue, fill=[1,1,1]
        )
    mainlayer.append(boxer, beforeActor=RLformula)
    boxer.newendkey(20).alphaFill = 1

    mation.endDelayUntil(30*minsec(1.3075))
    print("Gray it out:", mation.seconds())

    time = mation.lastID()
    boxer.newkey(time)
    boxer.newendkey(20).set(color=[0.25]*3, alpha=0.5)

    RLformula.newkey(time)
    RLformula.newendkey(20).alpha = 0.5

    mation.endDelayUntil(30*minsec(1.3475))
    print("Show potential future topics:", mation.seconds())

    future = mo.text.Text("Future topics?    ",
        pos=-2+0.6j, align=[1,0],
        size=56, color=[0,0,0]
        )
    future = mo.Actor(future)
    mainlayer.append(future)
    future.fadeIn(20, jump=2)

    topics = ["Why so many derivatives?", "Shortcomings of RL derivative", "Applications of Fractional Calculus", "Fractional Differential Equations"]
    labels = []
    timeOffset = -15
    pos = future.last().pos
    yshift = 1.75
    for n, topic in enumerate(topics):
        label = mo.text.Text(topic,
            pos=pos, align=[-1,0],
            size=future.last().size, color=[0,0,0.8]
            )
        label = mo.Actor(label)
        labels.append(label)
        mainlayer.append(label, timeOffset=timeOffset)
        label.fadeIn(20, jump=2j)
        pos -= yshift*1j





    print("Animation length:", mation.seconds())
    mation.endDelay(15*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./22_derivagral-zoo.mp4", scale=1)


main()
