
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "08_gamma-graph"


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightgreen

    gridlayer.camera.first().view = [-4.5, 4.5, -1, 1]
    gridlayer.camera.first().rescaleHeight(1/2)

    gridview = roundOut(gridlayer.camera.first().view)
    grid = mo.grid.mathgrid(
        view=gridview,
        dy=gridview[-1]-gridview[-2],
        vcolor=[0,0,0.8], alpha=0.5,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    # grid = mo.Actor(grid)
    # gridlayer.merge(grid)

    style = dict(width=9, color=[0,0,0], zdepth=10,
        tickWidth=9/2, tickColor=[0,0,0],
        tickLength=25)
    xaxis = mo.grid.Track(gridview[:2]).set(**style).set(
        tickGap=mo.pixelWidth(1, gridlayer.viewtime(0), mation.windowShape)
        )
    yaxis = mo.grid.Track([z*1j for z in gridview[2:]]).set(**style).set(
        tickGap=mo.pixelHeight(1, gridlayer.viewtime(0), mation.windowShape)
        )
    axes = mo.Frame([xaxis, yaxis])
    axes.zdepth = 10
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    axes.newendkey(30)
    for axis in axes.first().figures:
        axis.end = 0



    time = mation.lastID()
    ylabel = mo.graphics.MultiImage("./resources/Gamma(p).png").set(
        pos=(-0.11+8j), align=[1,0], height=72, physical=False
        )
    ylabel = mo.Actor(ylabel)
    gridlayer.merge(ylabel, atFrame=time)
    ylabel.fadeIn(20, jump=-0.5)

    xlabel = mo.text.Text("p",
        pos=(4.21+0.5j), italic=True, align=[0,-1],
        size=72, color=redorange
        )
    xlabel = mo.Actor(xlabel)
    gridlayer.merge(xlabel, atFrame=time)
    xlabel.fadeIn(20, jump=1j)

    mation.endDelay(30)
    print("Show gamma curve:", mation.seconds())

    from scipy.special import gamma
    steps = 18*32
    a,b = -4.5, 4.5
    curve = mo.graph.realgraph(lambda x: gamma(x).tolist(), a, b, steps=steps).set(
        width=7, color=redorange, transition=uniform
        )

    # Adjust for awkward cutoffs around x = -4.5
    for index,z in enumerate(curve.seq):
        if isbadnum(z):
            break
    dx = 0.28*(b-a)/steps
    curve.seq.insert(index+1, -4+dx+1j*gamma(-4+dx).tolist())
    curve.seq.insert(index, -4-dx+1j*gamma(-4-dx).tolist())

    curve = mo.Actor(curve)
    gridlayer.append(curve)
    curve.growIn(90)

    mation.endDelayUntil(9*30)
    print("Show asymptotes:", mation.seconds())

    time = mation.lastID()
    asms = []
    for n in range(-4, 0):
        asm = mo.grid.Path([9j, -9j]).set(
            width=6, color=[0,0,1], dash=[20,15],
            origin=n, # zdepth=100,
            # outlineWidth=2, outlineColor=[0,0,0]
            )
        asm = mo.Actor(asm)
        gridlayer.merge(asm, atFrame=time)
        asms.append(asm)
    mo.action.growIn(asms, duration=30, stagger=4)

    mation.endDelayUntil(13*30)
    print("Show footnote:", mation.seconds())

    footnote = mo.graphics.MultiImage("./resources/footnote2.png").set(
        pos=(17.15-9.35j), align=[1,-1], height=2.5
        )
    footnote = mo.Actor(footnote)
    mainlayer.merge(footnote, atFrame=mation.lastID())
    footnote.newendkey(20)
    footnote.first().pos -= 3.5j

    mation.endDelay(30)

    footnote.rollback(20)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    with np.errstate(all="ignore"):  # Suppress numpy warnings
        pass
        # mation.play()

        mation.newFrameRate(60)
        mation.export("./08_gamma-graph.mp4", scale=1)


main()
