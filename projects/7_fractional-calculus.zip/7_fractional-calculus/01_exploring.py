
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))




# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "01_exploring"

def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    mainview = mainlayer.viewtime(0)
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    mation.endDelayUntil(2*30)
    print("Show x^3 derivative formula:", mation.seconds())

    time = mation.lastID()
    cubicFormula = mo.graphics.MultiImage("./resources/ddx-cubic-formula.png").set(
        pos=6j, height=2.5
        )
    cubicFormula = mo.Actor(cubicFormula)
    mainlayer.merge(cubicFormula)
    cubicFormula.fadeIn(20, jump=2j)

    mation.endDelayUntil(9.25*30)
    print("Show half-derivative:", mation.seconds())

    time = mation.lastID()
    xcubed = mo.graphics.MultiImage("./resources/x3-green.png").set(
        pos=-5+2j, height=1.25
        )
    xcubed = mo.Actor(xcubed)
    mainlayer.append(xcubed)
    xcubed.fadeIn(20, jump=2j)

    time = mation.lastID()
    arrow = mo.grid.Arrow()
    arrow.tail = xcubed.last().pos+1.5
    arrow.head = -arrow.tail.conjugate()
    arrow.set(width=5, headSize=30, color=[0.8,0,0])
    arrow = mo.Actor(arrow)
    mainlayer.append(arrow)
    arrow.growIn(20)

    ddx = mo.graphics.MultiImage("./resources/ddx-half.png").set(
        pos=arrow.last().midpoint()-0.5j, height=2.5, align=[0,1]
        )
    ddx = mo.Actor(ddx)
    mainlayer.merge(ddx, atFrame=time)
    ddx.fadeIn(20, jump=-1.5j)

    mation.endDelayUntil(13*30)
    print("Show x^2.5:", mation.seconds())

    x25 = mo.graphics.MultiImage("./resources/x2.5.png").set(
        pos=-xcubed.last().pos.conjugate(), height=xcubed.last().height
        )
    x25 = mo.Actor(x25)
    mainlayer.append(x25)
    x25.fadeIn(20, jump=2)

    mation.endDelayUntil(19*30)
    print("Enbox x^2.5:", mation.seconds())

    boxer = mo.gadgets.enbox(x25.last().box(pad=0.5),
        width=5, color=[0,0,1], duration=30
        )
    mainlayer.append(boxer)

    mation.endDelayUntil(26*30)
    print("Debox:", mation.seconds())

    boxer.rollback(30)

    mation.endDelayUntil(31.25*30)
    print("'What does this even mean?':", mation.seconds())

    what = mo.text.paragraph(
        [mo.text.Text("What should this even"),
        mo.text.Text("mean", italic=True, bold=True)],
        mainview, mation.windowShape,
        pos=ddx.last().pos-ddx.last().height*1j-1j,
        size=64, color=[0.8,0,0], xgap=15
        )
    what = mo.Actor(what)
    mainlayer.append(what)
    what.fadeIn(20, jump=-2j)

    mation.endDelayUntil(42.25*30)
    print("Fade stuff:", mation.seconds())

    time = mation.lastID()
    mo.action.rollback([what, x25, arrow],
        duration=20, atFrame=time, stagger=4)

    mation.endDelayUntil(45.5*30)
    print("Show double-half equation:", mation.seconds())

    # time = mean([time, mation.lastID()])
    time = mation.lastID()
    ddx.newkey(time)
    ddx2 = ddx.last().copy()
    ddx.newendkey(30).set(
        pos=-2.5+4j, align=[1,0], height=3
        )

    ddx2 = mo.Actor(ddx2)
    mainlayer.merge(ddx2, atFrame=time)
    ddx2.newendkey(30, ddx.last().copy()).set(
        pos=ddx.last().pos-ddx.last().width-0.25
        )

    xcubed.newkey(time)
    xcubed.newendkey(30).set(
        pos=ddx.last().pos+0.25, align=[-1,0]
        )

    # eq = mo.text.PText("=",
    #     pos=xcubed.last().pos+xcubed.last().width+0.5, align=[-1,0], bold=True,
    #     size=1, color=[0,0,0]
    #     )
    eq = mo.graphics.MultiImage("./resources/eq.png").set(
        pos=xcubed.last().pos+xcubed.last().width+0.25, align=[-1,0.25],
        height=1.25, color=[0,0,0]
        )
    eq = mo.Actor(eq)
    mainlayer.merge(eq, atFrame=time)
    eq.fadeIn(30)

    cubicFormula.newkey(time)
    cubicFormula.newendkey(30).set(
        pos=eq.last().pos+eq.last().width+0.25, align=[-1,0]
        )

    mation.endDelayUntil(63.5*30)
    print("Show square root analogy:", mation.seconds())

    analogy = mo.graphics.MultiImage("./resources/sqrt-analogy.png").set(
        pos=0, height=1.25
        )
    analogy = mo.Actor(analogy)
    mainlayer.append(analogy)
    analogy.fadeIn(20, jump=2j)

    mation.endDelay(30)

    footnote = mo.text.paragraph(
        """This is an example of what's more broadly
known as a "functional square root".""",
        mainview, mation.windowShape,
        pos=17-10.5j, align=[1,1], ygap=10,
        flush=1, size=36, color=[0,0,0]
        )
    footnote = mo.Actor(footnote)
    mainlayer.append(footnote)
    footnote.newendkey(15).pos += 2.5j
    mation.endDelay(30)
    footnote.rollback(15)

    mation.endDelayUntil(70.15*30)
    print("Fade analogy and show wrong result:", mation.seconds())

    time = mation.lastID()
    analogy.newkey(time)
    analogy.rollback(20)

    xcubed2 = xcubed.last().copy()
    xcubed2 = mo.Actor(xcubed2)
    mainlayer.append(xcubed2)
    xcubed2.newendkey(20).set(pos=-6.25, align=[0,0])

    arrow1 = arrow.key[1].copy()
    arrow1.set(tail=xcubed2.last().pos+1)
    arrow1.head = arrow1.tail + 4
    arrow1 = mo.Actor(arrow1)
    mainlayer.append(arrow1)
    arrow1.growIn(20)

    half1 = ddx2.last().copy()
    half1.set(
        pos=arrow1.last().midpoint()-0.5j, align=[0,1],
        )
    half1.height *= 0.65
    half1 = mo.Actor(half1)
    mainlayer.append(half1, timeOffset=-20)
    half1.fadeIn(20, jump=-1j)

    x2part = mo.graphics.MultiImage("./resources/x2.5.png").set(
        pos=arrow1.last().head+1.5, height=xcubed2.last().height
        )
    x2part = mo.Actor(x2part)
    mainlayer.append(x2part)
    x2part.fadeIn(20, jump=2)

    mation.endDelayUntil(77.33*30)
    print("Show the next half-deriv:", mation.seconds())

    arrow2 = arrow1.last().copy()
    arrow2.set(tail=x2part.last().pos+1.5)
    arrow2.head = arrow2.tail + 4
    arrow2 = mo.Actor(arrow2)
    mainlayer.append(arrow2)
    arrow2.growIn(20)

    half2 = half1.last().copy()
    half2.pos = arrow2.last().midpoint()-0.5j
    half2 = mo.Actor(half2)
    mainlayer.append(half2, timeOffset=-20)
    half2.fadeIn(20, jump=-1j)

    xsqr = mo.graphics.MultiImage("./resources/x2-green.png").set(
        pos=arrow2.last().head+1, height=x2part.last().height
        )
    xsqr = mo.Actor(xsqr)
    mainlayer.append(xsqr)
    xsqr.fadeIn(20, jump=2)

    mation.endDelayUntil(82*30)
    print("Show =/= 3x^2:", mation.seconds())

    neq = mo.graphics.MultiImage("./resources/neq.png").set(
        pos=(6.67+2j), height=1.5, rotation=pi/2, scale_y=0
        )
    neq = mo.Actor(neq)
    mainlayer.append(neq)
    neq.newendkey(20).scale_y = 1

    mation.endDelayUntil(88.5*30)
    print("Fade away the second half-d/dx:", mation.seconds())

    time = mation.lastID()
    mo.action.rollback([neq, xsqr, half2, arrow2],
        atFrame=time, duration=20, stagger=4
        )

    mation.endDelayUntil(94*30)
    print("Enbox the exponent of 2.5:", mation.seconds())

    expboxer = mo.gadgets.enbox([-0.15,1.44, -0.25,0.78],
        duration=30, width=4, color=[0,0,1]
        )
    mainlayer.append(expboxer)

    mation.endDelayUntil(97*30)
    print("Show empty box for coeff:", mation.seconds())

    time = mation.lastID()
    # Scoot the x^2.5 expression to the side a little bit
    x2part.newkey(time)
    x2part.newendkey(15).pos += 1.75
    expboxer.newkey(time)
    expboxer.fadeOut(15, jump=1.75)

    coeffboxer = mo.gadgets.enbox([-1.2,0.81, -0.83,0.9],
        duration=30, width=5, color=violet
        )
    mainlayer.append(coeffboxer)

    goeshere = mo.text.MultiText("What goes here?",
        pos=(-0.52-2.59j), anchor_x=-0.85,
        size=56, color=violet
        )
    goeshere = mo.Actor(goeshere)
    mainlayer.append(goeshere)
    goeshere.fadeIn(20, jump=-2j)

    garrow = mo.grid.Arrow(-2.1j, (-1j)).set(
        width=5, color=violet, headSize=25, origin=-0.25
        )
    garrow = mo.Actor(garrow)
    mainlayer.append(garrow)
    garrow.growIn(20)

    mation.endDelayUntil(107*30)
    print("Insert root 3:", mation.seconds())

    root3 = mo.graphics.MultiImage("./resources/root3.png").set(
        pos=(-0.22-0.63j), align=[0,-1], height=1.15
        )
    root3 = mo.Actor(root3)
    mainlayer.append(root3)
    root3.fadeIn(20)

    mation.endDelayUntil(111*30)
    print("Show consequences:", mation.seconds())

    arrow3 = arrow2.key[1].copy()
    arrow3.origin += 1.75
    arrow3.commitTransforms()
    arrow3 = mo.Actor(arrow3)
    mainlayer.append(arrow3)
    arrow3.growIn(20)

    badx2 = mo.graphics.MultiImage("./resources/roots-x2.png").set(
        pos=arrow3.last().head+0.5, align=[-1,0], height=1.15
        )
    badx2 = mo.Actor(badx2)
    mainlayer.append(badx2)
    badx2.fadeIn(20, jump=3)

    mation.endDelayUntil(116.75*30)
    print("Rollback and challenge the viewer:", mation.seconds())

    time = mation.lastID()
    mo.action.rollback([badx2, arrow3, root3],
        atFrame=time, duration=20, stagger=4
        )

    tryit = mo.text.Text("Give it a try!",
        pos=8j,
        size=84, color=[0,0,0.8]
        )
    tryit = mo.Actor(tryit)
    mainlayer.append(tryit)
    tryit.fadeIn(20, jump=2j)

    mation.endDelayUntil(124*30)
    print("Fade 'try it':", mation.seconds())

    tryit.fadeOut(20)

    mation.endDelayUntil(127*30)
    print("Bang head here:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    goeshere.newkey(time)
    goeshere.newendkey(20).set(
        text="Bang head here.", color=[0.8,0,0]
        )
    goeshere.newendkey(-10)
    for fig in goeshere.key[-2].figures:
        fig.prescale_x *= 0.5
    garrow.newkey(time)
    garrow.newendkey(20).color = goeshere.last().color[:]

    mation.endDelayUntil(131*30)
    print("Fade the 'bang head' label and arrow:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([garrow, goeshere],
        atFrame=time, duration=30
        )

    mation.endDelayUntil(135.5*30)
    print("Show Hero being suspicious:", mation.seconds())

    hero = mo.graphics.MultiImage("./resources/hero-colbert.png").set(
        pos=(-8-1.83j), align=[0,1], height=7,
        )
    hero = mo.Actor(hero)
    mainlayer.append(hero)
    hero.fadeIn(20)

    weird = mo.text.MultiText("Pretty weird...",
        pos=(-10.24-1j), align=[0,-1], font="Qarmic sans",
        size=36, color=[0,0,0]
        )
    weird = mo.Actor(weird)
    mainlayer.append(weird)
    weird.fadeIn(20, jump=-2+2j)

    arc = mo.grid.arc(-10.26-1.39j, (-9.24-2.5j), angle=60*deg).set(
        width=4, color=[0,0,0]
        )
    arc = mo.Actor(arc)
    mainlayer.append(arc)
    arc.growIn(20)





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./01_exploring.mp4", scale=1)


main()
