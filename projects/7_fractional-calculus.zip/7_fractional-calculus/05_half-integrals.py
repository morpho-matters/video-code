
import morpholib as morpho
morpho.importAll()
mo = morpho

import math, cmath, random
import numpy as np

from morpholib.tools.basics import *
from morpholib.video import standardAnimation, ratioXY, std_view, view169
from morpholib.tools.color import colormap

morpho.transition.default = morpho.transition.quadease
morpho.text.defaultFont = "CMU serif"

uniform = morpho.transitions.uniform
quadease = morpho.transitions.quadease
drop = morpho.transitions.drop
toss = morpho.transitions.toss
sineease = sinease = morpho.transition.sineease
step = morpho.transitions.step

colormap = mo.color.colormap
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])

lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightviolet = tuple(mo.color.parseHexColor(0xcd9be0))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())

dash = "\u2012"

morpho.anim.exportSignature = "05_half-integrals"


def main():
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    title = morpho.text.Text("Cauchy's Formula for Repeated Integration",
        pos=8j,
        size=72, anchor_x=0, anchor_y=0,
        color=(0,0,0)
        )
    title = morpho.Actor(title)
    mainlayer.merge(title)
    # title.fadeIn(duration=20, jump=2j)

    time = mation.lastID()
    cauchy = mo.graphics.MultiImage("./resources/cauchy-formula.png").set(
        pos=4.5j, height=2.25
        )
    cauchy = mo.Actor(cauchy)
    mainlayer.merge(cauchy, atFrame=time)

    mation.endDelayUntil(8*30)
    print("Show 6x example:", mation.seconds())

    cauchy6x = cauchy.last().copy()
    cauchy6x = mo.Actor(cauchy6x)
    mainlayer.append(cauchy6x, timeOffset=1)
    cauchy6x.newendkey(20).newSource("./resources/6x-example.png") \
        .scaleByHeight().pos -= 4j

    mation.endDelayUntil(16*30)
    print("Show '= t^3':", mation.seconds())

    eqt3 = mo.graphics.MultiImage("./resources/eq-t3.png").set(
        pos=cauchy6x.last().pos+cauchy6x.last().width/2+0.4+0.1j,
        align=[-1,0], height=0.85
        )
    eqt3 = mo.Actor(eqt3)
    mainlayer.append(eqt3)
    eqt3.fadeIn(20, jump=2)

    mation.endDelay(20)

    boxer = mo.gadgets.enbox(eqt3.last().box(pad=0.25),
        width=4, color=goodblue
        )
    mainlayer.append(boxer)

    mation.endDelayUntil(26*30)
    print("Rollback:", mation.seconds())

    time = mation.lastID()
    mo.action.rollback([boxer, eqt3],
        atFrame=time, duration=20, stagger=4
        )
    cauchy6x.fadeOut(atFrame=time+8, duration=20)

    title.newkey(time)
    title.fadeOut(20)

    mation.endDelayUntil(36*30)
    print("Enbox Cauchy Formula RHS:", mation.seconds())

    box = [-2.96, 9.17, 3.13, 5.89]
    rhsboxer = mo.gadgets.enbox(box, width=4, color=goodblue)
    mainlayer.append(rhsboxer)

    mation.endDelayUntil(45*30)
    print("Plug in n = 1/2:", mation.seconds())

    nhalf = mo.text.paragraph(
        [mo.text.Text("n  ", italic=True),
        mo.text.Text("= 1/2")],
        mainlayer.viewtime(0), mation.windowShape,
        pos=mean(rhsboxer.last().seq[:4]).real+0.69j,
        size=64, color=violet, align=[-0.27,0]
        )
    nhalf = mo.Actor(nhalf)
    mainlayer.append(nhalf)
    nhalf.fadeIn(20, jump=-2j)

    arrow = mo.grid.Arrow(nhalf.last().pos+0.5j)
    arrow.head = nhalf.last().pos.real + 1j*rhsboxer.last().seq[1].imag
    arrow.set(width=5, color=violet, headSize=30)
    arrow = mo.Actor(arrow)
    mainlayer.append(arrow)
    arrow.growIn(20)

    mation.endDelay(30)
    print("Actually move it in and morph the formula:", mation.seconds())

    # Merge in
    time = mation.lastID()
    nhalf.newkey(time)
    nhalf.newendkey(20).set(
        pos=mean(rhsboxer.last().seq[:4]), alpha=0, visible=False
        )

    arrow.newkey(time)
    arrow.newendkey(20).set(
        tail=arrow.last().head, headSize=0, visible=False
        )

    # Morph to unsimplified half-integral formula
    time = mation.lastID()
    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/half-integral-formula-unsimp.png") \
        .scaleByHeight()

    # Fade away rhsbox
    rhsboxer.newkey(time)
    rhsboxer.fadeOut(20)

    mation.endDelay(30)

    # Simplify
    cauchy.newendkey(20).newSource("./resources/half-integral-formula.png") \
        .scaleByHeight()

    mation.endDelayUntil(52*30)
    print("Enbox the factorial:", mation.seconds())

    box = [-2.26,0.61, 3.24,4.45]
    bangboxer = mo.gadgets.enbox(box, width=5, color=[1,0,0])
    mainlayer.append(bangboxer)

    mation.endDelayUntil(59*30)
    print("Show gamma formula:", mation.seconds())

    gformula = mo.graphics.MultiImage("./resources/gamma-factorial.png").set(
        pos=-3j, height=1.25
        )
    gformula = mo.Actor(gformula)
    mainlayer.append(gformula)
    gformula.fadeIn(20, jump=2j)

    mation.endDelay(20)

    canbe = mo.text.Text("can be non-integer!",
        pos=(2.52-6.19j),
        size=56, color=[1,0,0]
        )
    canbe = mo.Actor(canbe)
    mainlayer.append(canbe)
    canbe.fadeIn(20, jump=-3j)

    carrow = mo.grid.Arrow(canbe.last().pos+0.5j, 2.52-0.59j-3j).set(
        width=5, color=canbe.last().color[:], headSize=30
        )
    carrow = mo.Actor(carrow)
    mainlayer.append(carrow)
    carrow.growIn(20)

    mation.endDelayUntil(66.5*30)
    print("Replace the factorial:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([carrow, canbe], 20, atFrame=time)

    gformula.newkey(time)
    gformula.newendkey(20).newSource("./resources/gamma-half.png").scaleByHeight()

    mation.endDelay(20)

    time = mation.lastID()
    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/half-integral-formula-gamma.png") \
        .scaleByHeight()

    bangboxer.newkey(time)
    bangboxer.newendkey(20).seq = mo.grid.rect([-2.09,0.31,3.24,4.44]).edge().seq

    mation.endDelay(10)

    bangboxer.newendkey(15).color = [0,0.6,0]

    mation.endDelay(30)

    bangboxer.fadeOut(20)

    mation.endDelayUntil(30*minsec(1.206))
    print("Show equality to sqrt(pi):", mation.seconds())

    time = mation.lastID()
    gformula.newkey(time)
    gformula.newendkey(20).newSource("./resources/gamma-half-pi.png").scaleByHeight()

    mation.endDelayUntil(84*30)
    print("Plug into formula:", mation.seconds())

    # mation.start = mation.lastID()  # BOOKMARK
    spline = mo.shapes.Spline()
    spline.newNode(5.98+0.72j-3j)
    spline.newNode(-0.61+3.11j, 0.15-3j)
    # spline.inhandleRel(-1, 0.15-2j)
    spline = spline.toPath()
    spline.set(width=4, color=[0,0.6,0], end=0)
    spline = mo.Actor(spline)
    mainlayer.append(spline)
    spline.newendkey(20).set(end=1, headSize=25)

    mation.endDelay(20)

    time = mation.lastID()
    mo.action.fadeOut([spline, gformula], atFrame=time, duration=20)

    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/half-integral-formula-pi.png").scaleByHeight()

    # mation.start = mation.lastID()  # BOOKMARK
    cboxer = mo.gadgets.enbox(cauchy.last().box(pad=0.5),
        width=4, color=goodblue, fill=[1,1,1]
        )
    # cboxer.last().set(fill=[1,1,1])
    mainlayer.append(cboxer, beforeActor=0)

    halflabel = mo.text.Text("\u00bd-Integral Formula",
        pos=cauchy.last().pos+3j,
        size=72, color=[0,0,0]
        )
    halflabel = mo.Actor(halflabel)
    mainlayer.append(halflabel)
    halflabel.fadeIn(20, jump=2j)

    cboxer.newendkey(20).alphaFill = 1

    mation.endDelayUntil(90.25*30)
    print("Fade the enboxing:", mation.seconds())

    time = mation.lastID()
    cboxer.newkey(time)
    cboxer.fadeOut(30)

    mation.endDelayUntil(94.5*30)
    print("Enbox and WTH pi:", mation.seconds())

    piboxer = mo.gadgets.enbox([-1.61,-0.06,  3.24,4.46],
        width=5, color=[1,0,0], duration=20
        )
    mainlayer.append(piboxer)

    wth = mo.text.Text("???",
        pos=(-0.83+2.85j), anchor_y=1,
        size=56, color=[1,0,0]
        )
    wth = mo.Actor(wth)
    mainlayer.append(wth)
    wth.fadeIn(20, jump=-1.5j)

    mation.endDelayUntil(99.25*30)
    print("Rollback WTH:", mation.seconds())

    mo.action.rollback([wth, piboxer], duration=20, stagger=4)

    mation.endDelayUntil(103.5*30)
    print("Show half-deriv rule:", mation.seconds())

    doublehalfd = mo.graphics.MultiImage("./resources/double-half-deriv.png").set(
        pos=0, height=2.5
        )
    doublehalfd = mo.Actor(doublehalfd)
    mainlayer.append(doublehalfd)
    doublehalfd.fadeIn(20, jump=2j)

    mation.endDelayUntil(108.5*30)
    print("Show half-integ rule:", mation.seconds())

    doublehalfj = mo.graphics.MultiImage("./resources/double-half-integ.png").set(
        pos=doublehalfd.last().pos-3.5j, height=0.85*doublehalfd.last().height
        )
    doublehalfj = mo.Actor(doublehalfj)
    mainlayer.append(doublehalfj)
    doublehalfj.fadeIn(20, jump=2j)

    mation.endDelayUntil(114.75*30)
    print("Show f(x) = 2x test function:", mation.seconds())

    time = mation.lastID()
    # mation.start = mation.lastID()  # BOOKMARK
    mo.action.fadeOut([doublehalfj, doublehalfd],
        atFrame=time, duration=20
        )

    time = mation.lastID()
    test = mo.graphics.MultiImage("./resources/f(x)-eq-2x.png").set(
        pos=1j, height=0.95
        )
    test = mo.Actor(test)
    mainlayer.append(test)
    test.fadeIn(20, jump=2j)

    mation.endDelayUntil(117.5*30)
    print("Show expected result:", mation.seconds())

    expected = mo.graphics.MultiImage("./resources/integ-2x-eq-x2.png").set(
        pos=-2j, height=2
        )
    expected = mo.Actor(expected)
    mainlayer.append(expected)
    expected.fadeIn(20, jump=2j)

    xboxer = mo.gadgets.enbox(expected.last().box(pad=0.25),
        width=5, color=violet, duration=20, fill=[1,1,1]
        )
    mainlayer.append(xboxer, beforeActor=expected)
    xboxer.newendkey(15).alphaFill = 1

    mation.endDelay(30)

    time = mation.lastID()
    expected.newkey(time)
    expected.newendkey(30).set(pos=17+8j, align=[1,0])

    xboxer.newkey(time)
    xboxer.newendkey(30).seq = mo.gadgets.enbox(expected.last().box(pad=0.25)).last().seq

    mation.endDelayUntil(122.5*30)
    print("Fade expected result and highlight lowerbounds:", mation.seconds())

    time = mation.lastID()
    expected.newkey(time)
    # expected.fadeOut(20)

    time = mation.lastID()
    circ1 = mo.grid.ellipse(-7.19+3.54j, 0.4).edge().set(
        width=4, color=[0.8,0,0]
        )
    circ1 = mo.Actor(circ1)
    mainlayer.merge(circ1, atFrame=time)
    circ1.growIn(20)

    circ2 = mo.grid.ellipse((0.72+3.56j), 0.4).edge().set(
        width=4, color=[0.8,0,0]
        )
    circ2 = mo.Actor(circ2)
    mainlayer.merge(circ2, atFrame=time)
    circ2.growIn(20)

    mation.endDelay(40)
    print("Replace lowerbounds with 0:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([circ1, circ2], atFrame=time, duration=20)

    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/half-integral-formula-zeros.png").scaleByHeight()

    mation.endDelayUntil(128.5*30)
    print("Plug in 2x into the formula:", mation.seconds())

    time = mation.lastID()
    tarrow = mo.grid.Arrow().set(
        tail=test.last().pos+0.5j,
        head=cauchy.last().pos-1.5j,
        width=5, headSize=30, color=[0,0.6,0]
        )
    tarrow = mo.Actor(tarrow)
    mainlayer.append(tarrow)
    tarrow.growIn(20)
    mation.endDelay(10)
    time = mation.lastID()
    tarrow.newendkey(20).set(tail=tarrow.last().head, headSize=0, visible=False)

    test.newkey(time)
    test.newendkey(20).set(pos=cauchy.last().pos, alpha=0, visible=False)

    cauchy.newkey(mation.lastID())
    cauchy.newendkey(20).newSource("./resources/half-integral-2x-zeros.png").scaleByHeight()

    mation.endDelayUntil(30*minsec(2,12.15))
    print("Show result:", mation.seconds())

    xeq = -2.8

    result = cauchy.last().copy()
    result = mo.Actor(result)
    mainlayer.append(result, timeOffset=1)
    result.newendkey(20).newSource("./resources/half-integ-2x-result.png").scaleByHeight()
    result.last().set(align=[-1,0]).height *= 0.9
    result.last().pos = xeq + 1j*(result.last().pos.imag-3.5)

    mation.endDelayUntil(30*minsec(2,20.75))
    print("Enbox the exponent of 3/2:", mation.seconds())

    # poxer = mo.gadgets.enbox([0.35,1.39, 0.89, 1.81],
    #     width=4, color=goodblue, duration=20
    #     )
    # mainlayer.append(poxer)

    looksgood = mo.text.Text("Looks good",
        pos=(1.54+1.39j)+2.5, align=[-1,-0.25],
        size=56, color=goodblue
        )
    looksgood = mo.Actor(looksgood)
    mainlayer.append(looksgood)
    looksgood.fadeIn(20, jump=4)

    larrow = mo.grid.Arrow(looksgood.last().pos-0.25, (1.54+1.39j)).set(
        width=4, color=goodblue, headSize=25
        )
    larrow = mo.Actor(larrow)
    mainlayer.append(larrow)
    larrow.growIn(20)

    mation.endDelayUntil(30*minsec(2,28))
    print("Encircle the pi factor:", mation.seconds())

    circpi = mo.grid.ellipse((-0.54+0.44j), 0.75, phase=90*deg).edge().set(
        width=5, color=[1,0,0]
        )
    circpi = mo.Actor(circpi)
    mainlayer.append(circpi)
    circpi.growIn(20)

    mation.endDelayUntil(30*minsec(2,34))
    print("Replace t with x and point into formula:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([circpi, larrow, looksgood],
        atFrame=time, duration=20
        )

    mation.endDelay(10)

    # Replace t with x
    time = mation.lastID()
    result.newkey(time)
    result.newendkey(20).newSource("./resources/half-integ-2x-result-x.png").scaleByHeight()

    mation.endDelay(15)

    time = mation.lastID()
    cauchy.newkey(time)
    cauchy.newendkey(20, cauchy.key[-3].copy())

    arc1 = mo.grid.arc(-3.13+1.02j, (-5.83+3.69j), angle=-90*deg).set(
        width=5, color=[1,0,0], headSize=30
        )
    arc1 = mo.Actor(arc1)
    mainlayer.merge(arc1, atFrame=time)
    arc1.growIn(20)

    arc2 = mo.grid.arc(0.57+1.02j, (6.28+3.69j), angle=60*deg)
    arc2 = mo.shapes.Spline()
    arc2.newNode(0.57+1.02j, oo, 4) \
        .newNode(6.28+3.69j, -2j)
    arc2 = arc2.toPath()
    arc2.set(
        width=5, color=[1,0,0], headSize=30
        )
    arc2 = mo.Actor(arc2)
    mainlayer.merge(arc2, atFrame=time)
    arc2.growIn(20)

    mation.endDelay(30)
    print("Morph formula into step 2:", mation.seconds())

    time = mation.lastID() + 1
    cauchy.newkey(time)
    cauchy.newendkey(30).newSource("./resources/half-integral-example-part2.png").scaleByHeight()

    result.newkey(time)
    result.fadeOut(30)

    # resultcopy = mo.Actor(result.last().copy())
    # mainlayer.merge(resultcopy, atFrame=time)
    # for actor in [result, resultcopy]:
    #     actor.newkey(time)
    #     actor.newendkey(30, cauchy.last().copy()).visible = False

    for arc in [arc1, arc2]:
        arc.newkey(time)
        arc.newendkey(30).set(start=1, headSize=0, visible=False)

    mation.endDelayUntil(30*minsec(2,39))
    print("Show wolfram joke:", mation.seconds())

    xeq = -2.43
    # dots = mo.text.paragraph(
    #     [mo.text.Text("= ... ", size=48),
    #     mo.text.Text("Wolfram|Alpha", size=18),
    #     mo.text.Text("...", size=48)],
    #     mainlayer.camera.last().view, mation.windowShape,
    #     pos=xeq, align=[-1,0], color=[0,0,0]
    #     )
    dots = mo.graphics.MultiImage("./resources/eq-dots.png").set(
        pos=xeq+1j, align=[-1,0], height=0.37
        )
    dots = mo.Actor(dots)
    mainlayer.append(dots)
    dots.fadeIn(20, jump=-3j)
    dots.newendkey(6).rotation = 30*deg
    dots.newendkey(12).rotation *= -1
    for n in range(7):  # TBD
        dots.newendkey(12).rotation *= -1
    dots.last().set(alpha=0, visible=False)

    mation.endDelay(30)
    print("Show final answer:", mation.seconds())

    time = mation.lastID()
    answer = mo.graphics.MultiImage("./resources/eq-t2.png").set(
        pos=dots.last().pos, align=[-1,0], height=0.85
        )
    answer = mo.Actor(answer)
    mainlayer.append(answer)
    answer.fadeIn(20, jump=2)

    mation.endDelayUntil(30*minsec(2,46))
    print("Compare to expected answer:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    expected.newkey(time)  # .tweenMethod = expected.figureType.tweenPivot(90*deg)
    expected.newendkey(30).set(pos=answer.last().pos-3j, align=[-1,0])

    xboxer.newkey(time) # .tweenMethod = xboxer.figureType.tweenPivot(90*deg)
    xboxer.newendkey(30).seq = mo.grid.rect(expected.last().box(pad=0.25)).edge().seq

    mation.endDelay(10)

    # aboxer = mo.gadgets.enbox(answer.last().box(pad=0.25),
    #     width=5, color=[0,0.6,0], fill=[1,1,1], duration=20
    #     )
    # mainlayer.append(aboxer, beforeActor=answer)
    # aboxer.newendkey(15).alphaFill = 1

    footnote = mo.graphics.Image("./resources/footnote.png").set(
        pos=17-9.5j-3j, height=2.5, align=[1,-1]
        )
    footnote = mo.Actor(footnote)
    mainlayer.append(footnote)
    footnote.newendkey(20).pos = 17-9.5j

    mation.endDelay(30)

    footnote.rollback(20)

    mation.endDelayUntil(30*minsec(2.5033))
    print("Re-enbox the general half-integral formula:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([xboxer, expected, answer],
        atFrame=time, duration=20, stagger=4
        )

    time = mation.lastID()
    cauchy.newkey(time)
    cauchy.newendkey(20).newSource("./resources/half-integral-formula-pi.png").scaleByHeight()

    mation.endDelay(10)

    cboxer2 = mo.gadgets.enbox(cauchy.last().box(pad=0.25),
        width=5, color=goodblue, duration=30
        )
    mainlayer.append(cboxer2)

    mation.endDelayUntil(minsec(2,56.5)*30)
    print("Fade box:", mation.seconds())

    # Fade box
    cboxer2.fadeOut(20)

    mation.endDelayUntil(30*minsec(2,59.5))
    print("Show 1/3-integral formula:", mation.seconds())

    third = cauchy.last().copy()
    third = mo.Actor(third)
    mainlayer.append(third)
    third.newendkey(20).newSource("./resources/onethird-integral-formula.png").scaleByHeight()
    third.last().pos -= 4j

    mation.endDelayUntil(30*minsec(3.04))
    print("Show triple 1/3-integral composition:", mation.seconds())

    triple = mo.graphics.MultiImage("./resources/triple-third-integ.png").set(
        pos=third.last().pos-4j, height=third.last().height
        )
    triple = mo.Actor(triple)
    mainlayer.append(triple)
    triple.fadeIn(20, jump=-2j)

    mation.endDelayUntil(30*minsec(3.0925))
    print("Remove triple 1/3-integrals:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([triple, halflabel], atFrame=time, duration=20)

    mation.endDelay(30)
    print("Show the general fractional formula:", mation.seconds())

    pformula = cauchy.last().copy()
    pformula.newSource("./resources/p-integral-formula.png").scaleByHeight()
    pformula.pos = mean([cauchy.last().pos, third.last().pos])

    time = mation.lastID()
    for form in [cauchy, third]:
        form.newkey(time)
        form.newendkey(30, pformula.copy())
    third.last().visible = False

    mation.endDelayUntil(30*minsec(3.17))
    print("Show Semigroup Property:", mation.seconds())

    semigroup = mo.graphics.MultiImage("./resources/semigroup-property.png").set(
        pos=cauchy.last().pos-4j, height=cauchy.last().height
        )
    semigroup = mo.Actor(semigroup)
    mainlayer.append(semigroup)
    semigroup.fadeIn(20, jump=-3j)

    mation.endDelayUntil(30*minsec(3.27))
    print("Fade Semigroup Property and re-enbox formula:", mation.seconds())

    semigroup.fadeOut(20)

    time = mation.lastID()
    finalboxer = mo.gadgets.enbox(cauchy.last().box(pad=0.25),
        width=5, color=goodblue, fill=[1,1,1]
        )
    mainlayer.merge(finalboxer, atFrame=time, beforeActor=cauchy)
    finalboxer.newendkey(20).alphaFill = 1

    mation.endDelayUntil(30*minsec(3.32))
    print("Label the RL Fractional Integral:", mation.seconds())

    label = mo.text.Text("Riemann-Liouville Fractional Integral",
        pos=cauchy.last().pos+2.75j,
        size=64, color=violet
        )
    label = mo.Actor(label)
    mainlayer.append(label)
    label.fadeIn(20, jump=2j)





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./05_half-integrals.mp4", scale=1)


main()
