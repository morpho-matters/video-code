
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))

# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "16_interpret-intro"


def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    # gridlayer.camera.first().moveBy(-(-13.06-2.5j)).zoomIn(4, focus=0)
    view = [-5,5, -1,3]
    gridlayer.camera.first().view = view
    gridlayer.camera.first().rescaleHeight(16/9)
    gridview = roundOut(gridlayer.camera.first().view)
    gridview[-1] += 2

    # # Create mask for gridlayer
    # gridlayer.mask = gridlayer.copy()
    # gridlayer.mask.camera.first().visible = False
    # mask = mo.grid.rect(gridview).set(width=2)
    # mask = mo.Actor(mask)
    # gridlayer.mask.merge(mask)

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid)
    grid.growIn(30)

    axes = mo.grid.axes(gridview,
        width=10, color=[0,0,0],
        ).set(zdepth=10)
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    axes.growIn(30)

    @mo.SkitParameters(func=lambda x: x, start=0, end=1,
        strokeWeight=3, color=(0,0,0), alpha=1, steps=300
        )
    class Graph(mo.Skit):
        def makeFrame(self):
            func = self.func
            start = self.start
            end = self.end
            strokeWeight = self.strokeWeight
            color = self.color
            alpha = self.alpha
            steps = round(self.steps)

            graph = mo.graph.realgraph(func, start, end, steps=steps)
            graph.set(width=strokeWeight, color=color, alpha=alpha)

            return graph

    def basefunc(x):
        return 2.5*math.exp(-(x-1)**2/4)
    basecurve = Graph(
        func=basefunc, start=gridview[0], end=gridview[0],
        strokeWeight=7, color=goodblue
        )
    basecurve = mo.Actor(basecurve)
    gridlayer.append(basecurve)
    basecurve.newendkey(45).end = gridview[1]


    mation.endDelayUntil()
    # print("'d/dt is a local operator':", mation.seconds())

    time = mation.lastID()
    local = mo.graphics.MultiImage("./resources/local-operator.png").set(
        pos=(11.83+6.61j), height=2,
        background=mation.background, backAlpha=0.65, backPad=0.25
        )
    local = mo.Actor(local)
    mainlayer.merge(local, atFrame=time)
    local.fadeIn(20, jump=2j)

    mation.endDelayUntil()
    # print("Show tangent line and curtain:", mation.seconds())

    @mo.SkitParameters(
        func=basefunc,
        t=0, length=0, alpha=1, width=6, color=(1,0,0),
        ptFill=(1,1,0), ptAlpha=0
        )
    class TangentLine(morpho.Skit):
        def makeFrame(self):
            # t will represent the input to the function f
            func = self.func
            t = self.t
            length = self.length
            alpha = self.alpha
            width = self.width
            color = self.color
            ptFill = self.ptFill
            ptAlpha = self.ptAlpha

            figs = []

            x = t
            y = func(t)
            pos = complex(x,y)

            # Initialize tangent line to be a horizontal
            # line segment of length 4 centered at the
            # origin
            if length != 0:
                line = morpho.grid.Path([-length/2, length/2])
                line.color = color
                line.alpha = alpha
                line.width = width

                # Compute derivative
                slope = derivative(func, t, dx=1e-4).tolist()
                # Convert into an angle and set it as the rotation
                # of the line segment
                angle = math.atan(slope)
                line.rotation = angle

                # Position the tangent line at the tangent point
                line.origin = x + 1j*y

                figs.append(line)

            if ptAlpha > 0:
                pt = mo.grid.Point(pos).set(
                    size=15, strokeWeight=2, fill=ptFill,
                    alpha=alpha*ptAlpha
                    )
                figs.append(pt)

            return morpho.Frame(figs)

    time = mation.lastID()
    target = 1.33
    tanline = TangentLine(t=target)
    tanline = mo.Actor(tanline)
    gridlayer.merge(tanline, atFrame=time)
    radius = 0.65
    tanline.newendkey(20).set(length=2*radius, ptAlpha=1)

    # mation.endDelay(30)






    ### ABOVE IS PRELIM ###

    mation.start = mation.lastID()
    local.visible = False

    mation.endDelayUntil(5.15*30)
    print("Show curtains:", mation.seconds())

    time = mation.lastID()

    curtainbox1 = gridview[:]
    curtainbox1[1] = target - radius
    curtain1 = mo.grid.rect(curtainbox1).set(
        width=0, fill=[0,0,0], alpha=0.5, origin=-6.5
        )
    curtain1 = mo.Actor(curtain1)
    gridlayer.merge(curtain1, atFrame=time)
    curtain1.newendkey(30).origin = 0

    curtainbox2 = gridview[:]
    curtainbox2[0] = target + radius
    curtain2 = mo.grid.rect(curtainbox2).set(
        width=0, fill=[0,0,0], alpha=0.5,
        origin=-curtain1.first().origin
        )
    curtain2 = mo.Actor(curtain2)
    gridlayer.merge(curtain2, atFrame=time)
    curtain2.newendkey(30).origin = 0

    mation.endDelayUntil(11*30)
    print("Make curve roil:", mation.seconds())

    def roiler(t, f, phi, amp=0.5, buf=0.25):
        if abs(t-target) <= radius:
            return 0
        amt = amp*math.sin(f*t + phi)
        if abs(t-target) <= radius+buf:
            amt *= mo.lerp(0, 1, abs(t-target), start=radius, end=radius+buf)
        return amt

    def generateRandomRoiler():
        f = 5 + 3*random.random()
        phi = tau*random.random()
        return lambda t: roiler(t, f, phi)

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    basecurve.newkey(time)

    time = mation.lastID() + 12*30  # TBD
    random.seed(18)
    while basecurve.lastID() < time:
        roil1 = generateRandomRoiler()
        roil2 = generateRandomRoiler()
        basecurve.newendkey(10).func = lambda t, roil1=roil1, roil2=roil2: basefunc(t) + roil1(t) + roil2(t)








    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./16_interpret-intro.mp4", scale=1)


main()
