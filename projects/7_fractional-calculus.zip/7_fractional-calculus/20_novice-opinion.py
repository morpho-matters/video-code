
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad
from scipy.special import gamma

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))
darkgreen = dgreen = tuple(mo.color.parseHexColor("008000"))
beet = tuple(mo.color.parseHexColor("80003a"))
brown = tuple(mo.color.parseHexColor("5c2912"))


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "20_novice-opinion"



def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    mation = morpho.Animation([mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lighttan

    dsymbol = mo.graphics.MultiImage("./resources/fracder-f(t).png").set(
        pos=5j, height=1.6
        )
    dsymbol = mo.Actor(dsymbol)
    mainlayer.merge(dsymbol)

    mation.endDelayUntil(6*30)
    print("Show my character shrugging:", mation.seconds())

    kman = mo.graphics.MultiImage("./resources/k-shrug.png").set(
        pos=dsymbol.last().pos-3j, align=[0,1], height=8.5
        )
    kman = mo.Actor(kman)
    mainlayer.append(kman)
    kman.fadeIn(20)

    mation.endDelayUntil(8*30)
    print("'Novice opinion incoming'", mation.seconds())

    opin = mo.text.Text("Novice opinion incoming",
        pos=kman.last().pos-kman.last().height*1j-0.75j,
        size=56, color=[1,0,0]
        )
    opin = mo.Actor(opin)
    mainlayer.append(opin)
    opin.fadeIn(20, jump=-2j)

    mation.endDelayUntil(10*30)
    print("Fade cartoon and draw arrows to classic operators:", mation.seconds())

    mo.action.fadeOut([kman, opin], duration=20)

    time = mation.lastID()
    deriv = mo.graphics.MultiImage("./resources/ddt-f(t).png").set(
        pos=dsymbol.last().pos-6-6j, height=2.5,
        )
    deriv = mo.Actor(deriv)
    mainlayer.append(deriv)

    integ = mo.graphics.MultiImage("./resources/integ-f(t).png").set(
        pos=-deriv.last().pos.conjugate(), height=deriv.last().height
        )
    integ = mo.Actor(integ)
    mainlayer.append(integ)

    darrow = mo.grid.Arrow(dsymbol.last().pos-1.5*(1+1j), deriv.last().pos+1.35*(1+1j)).set(
        width=7, color=[1,0,0], headSize=30
        )
    darrow = mo.Actor(darrow)
    mainlayer.append(darrow)

    jarrow = darrow.last().fimage(lambda s: -s.conjugate())
    jarrow.set(color=violet)
    jarrow = mo.Actor(jarrow)
    mainlayer.append(jarrow)

    deriv.fadeIn(30, jump=-5-5j)
    integ.fadeIn(30, jump=5-5j)
    mo.action.growIn([darrow, jarrow], 30)

    mation.endDelayUntil(16.15*30)
    print("Damage the arrows:", mation.seconds())

    time = mation.lastID()
    for arrow in [darrow, jarrow]:
        arrow.newkey(time)
        arrow.newendkey(30).set(dash=[10], color=[0]*3, alpha=0.5)

    for formula in [deriv, integ]:
        formula.newkey(time)
        formula.newendkey(30).alpha = 0.5

    mation.endDelayUntil(27.15*30)
    print("Fade and show Euler's identity:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([deriv, integ, darrow, jarrow], 20, atFrame=time)

    euler = mo.graphics.MultiImage("./resources/euler-identity.png").set(
        pos=-1j, height=1.3
        )
    euler = mo.Actor(euler)
    mainlayer.append(euler)
    euler.fadeIn(20, jump=2j)

    mation.endDelayUntil(32.75*30)
    print("Morph to bad identity:", mation.seconds())

    euler.newendkey(20).newSource("./resources/bad-euler-identity.png").scaleByHeight()
    euler.last().height *= 2

    mation.endDelayUntil(35.25*30)
    print("Cross out bad identity:", mation.seconds())

    cross = mo.gadgets.crossout(euler.last().box(pad=1),
        width=6, color=[1,0,0], duration=20
        )
    mainlayer.append(cross)





    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./20_novice-opinion.mp4", scale=1)


main()
