
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac
from derivagrals import fracIntegrate, derivagral
from scipy.misc import derivative
from scipy.integrate import quad
from scipy.special import gamma

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))
redderorange = tuple(mo.color.parseHexColor("ff4400"))
darkgreen = dgreen = tuple(mo.color.parseHexColor("008000"))
beet = tuple(mo.color.parseHexColor("80003a"))
brown = tuple(mo.color.parseHexColor("5c2912"))


# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "21half-derivagrals-revisited"



def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    gridlayer2 = mainlayer.copy()
    mation = morpho.Animation([gridlayer, gridlayer2, mainlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightgreen

    LABELSIZE = 0.7

    title = mo.text.paragraph(
        [mo.text.Text("A visualization for", color=[0,0,0]),
        mo.text.Text(" fractional integrals", color=violet, italic=True)],
        mainlayer.camera.last().view, mation.windowShape,
        pos=0, size=72
        ).set(transition=drop)
    title = mo.Actor(title)
    mainlayer.merge(title)

    mation.endDelayUntil()
    # print("Remove title and show graph:", mation.seconds())

    title.fadeOut(30, jump=4j)

    mation.endDelay(20)

    time = mation.lastID()
    movement = (-5-6.5j)
    gridlayer.camera.first().moveBy(-movement).zoomIn(1.25, focus=0)
    gridlayer2.camera.first().zoomIn(1.25, focus=0)
    gridview = [0,9, 0,7]

    # gridtop = gridlayer.copy()
    # gridtop.mask = None
    # mation.merge(gridtop, beforeLayer=mainlayer)

    gridlayer.mask = gridlayer.copy()
    gridbox = mo.grid.rect(gridview, pad=1.5)
    gridbox = mo.Actor(gridbox)
    gridlayer.mask.merge(gridbox, atFrame=time)
    gridlayer.mask.camera.first().visible = False

    # grid = mo.grid.mathgrid(
    #     view=gridview,
    #     hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
    #     midWidth=2,
    #     steps=1,
    #     axesColor=[0,0,0], axisWidth=10,
    #     axes=False,
    #     )
    # grid = mo.Actor(grid)
    # gridlayer.merge(grid, atFrame=time)
    # grid.growIn(30)

    axes = mo.grid.axes(gridview).set(
        width=10, color=[0,0,0],
        zdepth=10
        )
    axes = mo.Actor(axes)
    gridlayer.merge(axes, atFrame=time)
    axes.growIn(20)

    time = mation.lastID()
    tend = 7.5
    delta = 0.001
    def f(x):
        return (4*x**3-51*x**2+180*x)/35
    # graph = mo.graph.realgraph(f, delta, tend-delta, steps=100).set(
    #     width=6, color=goodblue
    #     )
    graph = mo.grid.line(delta, tend-delta, steps=100).set(
        width=6, color=goodblue
        )
    graph.insertNodesUniformly(10, [0.98,1])
    graph = graph.fimage(lambda s: complex(s.real, f(s.real)))
    graph = mo.Actor(graph)
    gridlayer.merge(graph, atFrame=time)
    graph.growIn(30)

    time = mation.lastID()
    xlabel = mo.graphics.MultiImage("./resources/x-dgreen.png").set(
        pos=axes.last().seq[1]+0.25, align=[-1,0],
        height=0.63*LABELSIZE, color=dgreen
        )
    xlabel = mo.Actor(xlabel)
    gridlayer.merge(xlabel, atFrame=time)
    xlabel.fadeIn(15, jump=0.5)

    flabel = mo.graphics.MultiImage("./resources/f(x).png").set(
        pos=axes.last().seq[-1]+0.25j, align=[0,-1], height=0.9
        )
    flabel = mo.Actor(flabel)
    gridlayer.merge(flabel, atFrame=time)
    flabel.fadeIn(15, jump=0.5j)

    mation.endDelayUntil()
    # print("Sweep in area and label:", mation.seconds())

    time = mation.lastID()
    area = mo.calculus.IntegralArea(
        f, delta, 0,
        strokeWeight=graph.last().width, color=goodblue, fill=goodblue,
        alphaFill=0.5
        )
    area = mo.Actor(area)
    gridlayer.merge(area, atFrame=time, beforeActor=graph)
    area.newendkey(30).end = tend-delta

    time = mation.lastID()
    leftlabel = mo.text.PText("0",
        pos=0, align=[1.5,1.5],
        size=LABELSIZE, color=[0.8,0,0]
        )
    leftlabel = mo.Actor(leftlabel)
    gridlayer.merge(leftlabel, atFrame=time)
    leftlabel.fadeIn(15, jump=-0.25-0.25j)

    rightlabel = mo.graphics.MultiImage("./resources/t.png").set(
        pos=tend, align=[0,1.5],
        height=LABELSIZE
        )
    rightlabel = mo.Actor(rightlabel)
    gridlayer.merge(rightlabel, atFrame=time)
    rightlabel.fadeIn(15, jump=-0.25j)

    mation.endDelayUntil()
    # print("Show standard integral formula:", mation.seconds())

    time = mation.lastID()
    formula = mo.graphics.MultiImage("./resources/integ-0t-f(x)-dx.png").set(
        pos=7j, height=2.5
        )
    formula = mo.Actor(formula)
    mainlayer.merge(formula, atFrame=time)
    formula.fadeIn(20, jump=2j)

    mation.endDelayUntil()
    # print("Scoot and show half-integral formula:", mation.seconds())

    time = mation.lastID()
    formula.newkey(time)
    formula.newendkey(20).set(align=[-1,0]).pos += 6

    hformula = mo.graphics.MultiImage("./resources/half-integral-f(x)-formula.png").set(
        pos=formula.last().pos-7, align=[1,0],
        height=formula.last().height
        )
    hformula = mo.Actor(hformula)
    mainlayer.merge(hformula, atFrame=time)
    hformula.fadeIn(20, jump=-4)

    mation.endDelayUntil()
    # print("Add 'transforms' text:", mation.seconds())

    transforms = mo.text.Text("transforms",
        pos=mean([formula.last().pos, hformula.last().pos]),
        align=[0,-0.25], italic=True,
        size=60, color=[0,0,0]
        )
    transforms = mo.Actor(transforms)
    mainlayer.append(transforms)
    transforms.fadeIn(20, jump=3)

    mation.endDelayUntil()
    # print("Pull 1/gamma(1/2) inside:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([transforms, formula], atFrame=time, duration=20)

    hformula.newkey(time)
    hformula.newendkey(20).set(pos=hformula.last().pos.imag*1j, align=[0,0])

    mation.endDelay(15)

    arc = mo.grid.arc(-4.8+8.35j, (-1.46+8.35j), angle=-90*deg).set(
        width=4, color=goodblue, headSize=25
        )
    arc = mo.Actor(arc)
    mainlayer.append(arc)
    arc.growIn(15)

    mation.endDelay(20)

    time = mation.lastID()
    hformula.newkey(time)
    hformula.newendkey(15).newSource("./resources/gamma-inside.png").scaleByHeight()

    arc.newkey(time)
    arc.shrinkOut(15, reverse=True)

    mation.endDelayUntil()
    # print("Rescale the graph:", mation.seconds())

    def mu(t,x):
        return 1/(math.sqrt(pi*(t-x)))

    def muTransform(s, t=tend):
        x = s.real
        y = s.imag

        X = x
        Y = mu(t,x)*y
        # if Y > ymax:
        #     Y = nan

        return complex(X,Y)

    time = mation.lastID() + 1
    gridlayer.mask.camera.newkey(time).visible = True

    graph.newkey(time)
    graph.newendkey(30, graph.last().fimage(muTransform))
    graph.last().set(color=redderorange)

    area.newkey(time).alphaEdge = 0
    area.key[-2].static = True
    area.newendkey(30).set(
        func=lambda x: f(x)*mu(tend,x),
        color=redderorange, fill=redderorange
        )

    mation.endDelayUntil()
    # print("Enbox the scale factor in the integrand:", mation.seconds())

    time = mation.lastID()
    sboxer = mo.gadgets.enbox([-3.39,1.44, 5.56,8.46],
        width=5, color=beet
        )
    mainlayer.merge(sboxer, atFrame=time)

    mation.endDelayUntil()
    # print("Label mu_t(x):", mation.seconds())

    mutx = mo.graphics.MultiImage("./resources/mutx.png").set(
        pos=(-1.04+5.31j), align=[0,1], height=1
        )
    mutx = mo.Actor(mutx)
    mainlayer.append(mutx)
    mutx.fadeIn(20, jump=-1j)

    mation.endDelayUntil()
    # print("Move mu_t(x) into the formula:", mation.seconds())

    time = mation.lastID()
    hformula.newkey(time)
    hformula.newendkey(20).newSource("./resources/half-integral-transformed.png").scaleByHeight()

    sboxer.fadeOut(20, atFrame=time)

    mutx.newkey(time)
    mutx.newendkey(20).newSource("./resources/mutx-def.png").scaleByHeight().set(
        pos=16.2+hformula.last().pos.imag*1j, align=[1,0]
        ).height = 2.25

    mation.endDelayUntil()
    # print("Show ghost of the original graph:", mation.seconds())

    time = mation.lastID()
    ghost = graph.key[1].copy()
    ghost = mo.Actor(ghost)
    gridlayer.merge(ghost, atFrame=time)
    ghost.fadeIn(15, alpha=0.5)

    mation.endDelayUntil()
    # print("Label the asymptote:", mation.seconds())

    time = mation.lastID()
    asmtext = mo.text.paragraph(
        [[mo.text.Text("There's a frickin'", color=[0,0,0])],
        [mo.text.Text("asymptote  ", color=[1,0,0], bold=False, italic=True),
        mo.text.Text("now!", color=[0,0,0])]],
        mainlayer.camera.last().view, mation.windowShape,
        pos=(4.74+1.7j), align=[-1,0], flush=-1,
        size=48, ygap=15
        )
    asmtext = mo.Actor(asmtext)
    mainlayer.merge(asmtext, atFrame=time)
    asmtext.fadeIn(20, jump=2)

    mation.endDelayUntil()
    # print("Revert to original graph:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([asmtext, ghost], 20, atFrame=time)
    for actor in [graph, area]:
        actor.newkey(time)
        actor.newendkey(30, actor.key[1].copy())

    time = mation.lastID()
    gridlayer.mask.camera.newkey(time).visible = False

    mation.endDelayUntil()
    # print("Show vertical arrows:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    varrows = []
    N = 5
    ypad = 0.2
    for n in range(N):
        x = mo.lerp(0, tend, (n+1)/(N+1))
        varrow = mo.grid.Arrow().set(
            tail=ypad*1j, head=(f(x)-ypad)*1j, origin=x,
            width=5, color=[0,0,0], headSize=0
            )
        varrow = mo.Actor(varrow)
        varrows.append(varrow)
        gridlayer.merge(varrow, atFrame=time)
        varrow.newendkey(20).tipSize = 25
        varrow.first().head = varrow.first().tail = varrow.last().midpoint()

    mation.endDelayUntil()
    # print("Fade vertical arrows and show horz arrow:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut(varrows, atFrame=time, duration=20)

    time = mation.lastID()
    harrow = mo.grid.Arrow().set(
        tail=(0.68), head=tend-0.25, origin=1.84j,
        width=5, color=[0,0,0], tipSize=0
        )
    harrow = mo.Actor(harrow)
    gridlayer.merge(harrow, atFrame=time)
    harrow.newendkey(20).tipSize = 25
    harrow.first().tail = harrow.first().head = harrow.last().midpoint()

    mation.endDelayUntil()
    # print("Hide horz arrow and cut up the graph:", mation.seconds())

    harrow.fadeOut(20)

    time = mation.lastID()
    rectCount = 20
    rect_strokeWeight = 3
    settings = dict(rectCount=rectCount,
        align=0, strokeWeight=rect_strokeWeight,
        fill=(0,1,0), alphaFill=0.5,
        transition=quadease)
    riemann = mo.calculus.RiemannSum(f, [delta, tend-delta], **settings)
    riemann = mo.Actor(riemann)
    gridlayer.append(riemann)
    riemann.newendkey(30)
    riemann.beg = mo.calculus.RiemannSum(
        lambda x: 0, [delta, tend-delta], **settings
        )

    mation.endDelayUntil()
    # print("Take a rect out of context:", mation.seconds())

    time = mation.lastID() + 1
    rect = riemann.last().figures[-4].polygon.copy()
    rect_x = mean(rect.vertices).real
    rect = mo.Actor(rect)
    gridlayer.merge(rect, atFrame=time)
    rect.newendkey(30)
    rect.last().origin -= mean(rect.last().vertices)
    rect.last().commitTransforms()
    rect.last().set(origin=(11.5+5j), transform=[[2,0],[0,2]])
    center = rect.last().origin
    rect.last().commitTransforms()

    xmin = min(z.real for z in rect.last().vertices)
    xmax = max(z.real for z in rect.last().vertices)
    ymin = min(z.imag for z in rect.last().vertices)
    ymax = max(z.imag for z in rect.last().vertices)
    rectbox = [xmin,xmax, ymin,ymax]

    time = mation.lastID()
    baselabel = mo.graphics.MultiImage("./resources/dx.png").set(
        pos=center.real+1j*ymin-0.25j,
        align=[0,1], height=45, physical=False
        )
    baselabel = mo.Actor(baselabel)
    gridlayer.merge(baselabel, atFrame=time)
    baselabel.fadeIn(20, jump=-1j)

    heightlabel = mo.graphics.MultiImage("./resources/f(x).png").set(
        pos=xmax+0.25+1j*center.imag,
        align=[-1,0], height=60, physical=False
        )
    heightlabel = mo.Actor(heightlabel)
    gridlayer.merge(heightlabel, atFrame=time)
    heightlabel.fadeIn(20, jump=1)

    mation.endDelayUntil()
    # print("Rescale the rect:", mation.seconds())

    time = mation.lastID() + 1
    rect.newkey(time)
    rect.newendkey(20).origin = -center
    rect.last().commitTransforms()
    rect.last().transform = [[mu(tend, rect_x), 0], [0,1]]
    rect.last().origin += center
    rect.last().commitTransforms()

    baselabel2 = baselabel.last().copy()
    baselabel2 = mo.Actor(baselabel2)
    gridlayer.merge(baselabel2, atFrame=time)
    baselabel2.newendkey(20).pos -= 2.75j

    baselabel.newkey(time)
    baselabel.newendkey(20).newSource("./resources/dx-tilde.png").scaleByHeight()

    basearrow = mo.grid.Arrow().set(
        tail=baselabel2.last().pos+0.25j,
        head=baselabel.last().pos-mo.physicalHeight(baselabel.last().height, gridlayer.camera.last().view, mation.windowShape)*1j-0.25j,
        width=5,
        color=mo.color.Gradient({0: dgreen, 1: brown}),
        headSize=25
        ).toPath()
    basearrow = mo.Actor(basearrow)
    gridlayer.merge(basearrow, atFrame=time)
    basearrow.growIn(20, reverse=True)

    mation.endDelayUntil()
    # print("Show dx~ equation:", mation.seconds())

    time = mation.lastID()
    baselabel.newkey(time)
    baselabel.newendkey(20).newSource("./resources/dx-tilde-equation.png").scaleByHeight()
    baselabel.last().height *= 1.42
    baselabel.last().set(anchor_x=-0.8)

    mation.endDelay(15)

    time = mation.lastID()
    # Morph the hformula so that mu_t(x) is with dx
    hformula.newkey(time)
    hformula.newendkey(20).newSource("./resources/half-integral-transformed-swapped.png").scaleByHeight()

    mation.endDelayUntil()
    # print("Apply the accordion transform to the whole graph:", mation.seconds())

    time = mation.lastID()
    mo.action.fadeOut([baselabel, baselabel2, basearrow, rect, heightlabel],
        duration=20, atFrame=time
        )

    riemann.newkey(time)
    riemann.key[-2].static = True  # Makes the animation a little more efficient
    riemann.newendkey(20).visible = False
    for rect in riemann.last().figures:
        rect.alpha = 0

    dx = (tend-2*delta)/rectCount
    vlines = mo.grid.mathgrid(
        view=[delta+dx, tend-delta-dx, 0, 1],
        dx=dx, dy=1, steps=1,
        vcolor=[0,0,0], vwidth=rect_strokeWeight,
        hwidth=0, axes=False, BGgrid=False, midlines=False
        )
    vlines = vlines.fimage(lambda s: s.real+1j*s.imag*f(s.real))
    vlines = mo.Actor(vlines)
    gridlayer.merge(vlines, atFrame=time, beforeActor=graph)
    vlines.fadeIn(20)

    mation.endDelay(20)

    def xtilde(x0, t):
        return 2/math.sqrt(math.pi)*(math.sqrt(t) - math.sqrt(t-x0))

    def accordion(s, t=tend):
        x,y = s.real, s.imag
        X = xtilde(x, t)
        Y = y
        return complex(X,Y)

    time = mation.lastID()
    area.newkey(time).visible = False
    area.key[-2].static = True
    # arealast = area.last().copy()
    # arealast.steps = 75
    # arealast.updatePolygon()
    # region = arealast.polygon
    region = graph.last().copy()
    region.seq.extend([tend-delta, delta])
    region.close()
    region.set(fill=area.last().fill[:], alphaFill=area.last().alphaFill)
    region = mo.Actor(region)
    gridlayer.merge(region, atFrame=time, beforeActor=vlines)

    newcolor = violet
    newfill = newcolor[:]
    for actor in [graph, vlines, region]:
        actor.newkey(time)
        actor.newendkey(60, actor.last().fimage(accordion)).set(
            color=newcolor, fill=newfill
            )

    rightlabel.newkey(time)
    rightlabel.newendkey(60, rightlabel.last().fimage(accordion))
    rightlabel.last().newSource("./resources/wave-t.png").scaleByHeight()
    rightlabel.last().height *= 1.35

    xlabel.newkey(time)
    xlabel.newendkey(60).newSource("./resources/wave-x.png").scaleByHeight()
    xlabel.last().height *= 1.5

    mation.endDelayUntil()
    # print("Show half-integral formula inside the region:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    halfinteg = mo.graphics.MultiImage("./resources/half-integral-expression0.png").set(
        pos=2/math.sqrt(pi)*math.sqrt(tend)+0.25+1j*f(tend)/2,
        align=[-1,0], height=1.8,
        background=[1,1,1], backAlpha=0.75, backPad=0.25
        )
    halfinteg = mo.Actor(halfinteg)
    gridlayer.merge(halfinteg, atFrame=time)
    halfinteg.fadeIn(20, jump=2.5)

    mation.endDelayUntil()
    # print("Setup integral comparisons:", mation.seconds())

    time = mation.lastID()
    halfinteg.rollback(20)

    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(30).moveBy(7)

    hformula.newkey(time)
    hformula.newendkey(30).pos = -14.65+8j
    hformula.last().align = [-1,0]

    mutx.newkey(time)
    mutx.newendkey(30).set(pos=(-11.02+6.3j), align=[-1,0]).height *= 0.8

    time = mation.lastID()
    gridlayer2.camera.first().moveBy(-(2.49-5.19j))

    axes2 = axes.key[1].copy()
    axes2 = mo.Actor(axes2)
    gridlayer2.merge(axes2, atFrame=time)
    axes2.growIn(20)

    time = mation.lastID()
    newactors = []
    for actor in [xlabel, flabel, area, graph]:
        actor2 = actor.segment(actor.keyID(0), actor.keyID(1))
        gridlayer2.merge(actor2, atFrame=time)
        newactors.append(actor2)
    xlabel2, flabel2, area2, graph2 = newactors
    for fig in area2.keys():
        fig.strokeWeight = 0

    time = mation.lastID()
    newactors = []
    for actor in [leftlabel, rightlabel]:
        actor2 = actor.segment(actor.keyID(0), actor.keyID(1))
        gridlayer2.merge(actor2, atFrame=time)
        newactors.append(actor2)
    leftlabel2, rightlabel2 = newactors

    formula2 = formula.key[1].copy().set(
        pos=(5.15+7.46j), align=[-1,0]
        )
    formula2 = mo.Actor(formula2)
    mainlayer.merge(formula2, atFrame=time)
    formula2.fadeIn(20, jump=2j)

    vlines2 = mo.grid.mathgrid(
        view=[delta+dx, tend-delta-dx, 0, 1],
        dx=dx, dy=1, steps=1,
        vcolor=[0,0,0], vwidth=rect_strokeWeight,
        hwidth=0, axes=False, BGgrid=False, midlines=False
        ).fimage(lambda s: s.real+1j*s.imag*f(s.real))
    vlines2 = mo.Actor(vlines2)
    gridlayer2.merge(vlines2, atFrame=time, beforeActor=graph2)
    vlines2.growIn(30)

    @mo.SkitParameters(t=tend, pos=0, alpha=0)
    class Tracker(mo.Skit):
        def makeFrame(self):
            t = self.t
            pos = self.pos
            alpha = self.alpha

            tnum = mo.text.formatNumber(t, decimal=2, rightDigits=2)
            txt = mo.text.paragraph(
                [mo.text.Text("t  ", italic=True),
                mo.text.Text(f"= {tnum}")],
                mainlayer.camera.last().view, mation.windowShape,
                pos=pos, size=64, color=violet, alpha=alpha,
                background=[1,1,1], backAlpha=1, backPad=0.4
                )
            rect = mo.grid.rect(txt.totalBox(mainlayer.camera.last().view, mation.windowShape, pad=txt.backPad)).edge().set(
                width=4, color=violet, alpha=alpha, origin=txt.pos
                )

            return mo.Frame([txt, rect])

    tvalue = Tracker(pos=6j)
    tvalue = mo.Actor(tvalue)
    mainlayer.merge(tvalue, atFrame=time)
    tvalue.fadeIn(20, jump=2j)

    mation.endDelayUntil()
    # print("Stretch the left graph a little:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    xscale = 2.25
    transform = mo.array([[xscale, 0], [0,1]])
    for actor in [graph, region, rightlabel, vlines]:
        actor.newkey(time)
        actor.newendkey(30, actor.last().fimage(lambda s: mo.matrix.Mat(transform)*s))

    # mation.endDelayUntil()
    # print("Start varying t:", mation.seconds())







    ### ABOVE IS PRELIM ###

    time = mation.lastID()
    mation.start = time
    for actor in [graph, region, vlines, area2, vlines2, rightlabel, rightlabel2]:
        actor.newkey(time).visible = False

    graph2.newkey(time).alpha = 0.5
    graph2.key[-2].static = True

    # Puppet skit updates the right graph reacting to tvalue
    class RightGraph(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex
            t = tvalue.time(index).t

            graph = mo.grid.line(delta, t-delta, steps=100).set(
                width=6, color=goodblue
                )
            graph.insertNodesUniformly(10, [0.98,1])
            graph = graph.fimage(lambda s: complex(s.real, f(s.real)))

            area = graph.copy().set(
                width=0, fill=graph.color[:], alphaFill=0.5
                )
            area.seq.extend([t-delta, delta])
            area.close()

            tlabel = rightlabel2.last().copy().set(visible=True)
            tlabel.pos = t + 1j*tlabel.pos.imag


            buf = dx if t == tend else 0
            vlines = mo.grid.mathgrid(
                view=[delta+dx, t-delta-buf, 0, 1],
                dx=dx, dy=1, steps=1,
                vcolor=[0,0,0], vwidth=rect_strokeWeight,
                hwidth=0, axes=False, BGgrid=False, midlines=False
                ).fimage(lambda s: s.real+1j*s.imag*f(s.real))

            return mo.Frame([area, vlines, graph, tlabel])

    # Puppet skit updates the right graph reacting to tvalue
    class LeftGraph(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex
            t = tvalue.time(index).t
            t_tilde = 2*math.sqrt(t/pi)

            mygraph = mo.grid.line(delta, t-delta, steps=100).set(
                width=6, color=graph.last().color[:]
                )
            mygraph.insertNodesUniformly(10, [0.98,1])
            mygraph = mygraph.fimage(lambda s: complex(s.real, f(s.real)))
            mygraph = mygraph.fimage(lambda s: accordion(s,t))
            mygraph.seq.append(mygraph.seq[-1].real)

            area = mygraph.copy().set(
                width=0, fill=mygraph.color[:], alphaFill=0.5
                )
            area.seq.extend([area.seq[0].real])
            area.close()

            tlabel = rightlabel.last().copy().set(visible=True)
            tlabel.pos = t_tilde + 1j*tlabel.pos.imag


            buf = dx if t == tend else 0
            vlines = mo.grid.mathgrid(
                view=[delta+dx, t-delta-buf, 0, 1],
                dx=dx, dy=1, steps=1,
                vcolor=[0,0,0], vwidth=rect_strokeWeight,
                hwidth=0, axes=False, BGgrid=False, midlines=False
                ).fimage(lambda s: s.real+1j*s.imag*f(s.real))
            vlines = vlines.fimage(lambda s: accordion(s,t))

            frm = mo.Frame([area, vlines, mygraph, tlabel])
            mat = mo.matrix.Mat(transform)
            frm = frm.fimage(lambda s: mat*s)
            return frm

    rgraph = RightGraph()
    rgraph = mo.Actor(rgraph)
    gridlayer2.merge(rgraph, atFrame=time)

    lgraph = LeftGraph()
    lgraph = mo.Actor(lgraph)
    gridlayer.merge(lgraph, atFrame=time)

    mation.endDelay(10)

    tvalue.newkey(time)
    tvalue.newendkey(55).t = 2

    mation.endDelay(20)

    tvalue.newendkey(55).t = 6

    mation.endDelay(20)

    tvalue.newendkey(55).t = 1

    mation.endDelay(20)

    tvalue.newendkey(55).t = tvalue.first().t







    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./21half_derivagrals-revisited.mp4", scale=1)


main()
