
import morpholib as morpho
morpho.importAll()
mo = morpho  # Allows the shorthand "mo" to be used instead of "morpho"

# Import particular transition functions into the main namespace
from morpholib.transitions import uniform, quadease, drop, toss, sineease, step
# Import useful functions and constants into the main namespace
from morpholib.tools.basics import *

from funcfrac import FuncFrac

# Import various other libraries
import math, cmath, random
import numpy as np

# Set default transition to quadease
morpho.transition.default = quadease
# Set default font to be the LaTeX font
morpho.text.defaultFont = "CMU serif"

# Particular colors are named here.
# Feel free to customize to your heart's content.
orange = tuple(mo.color.parseHexColor("ff6300"))
violet = (mo.color.colormap["violet"])
lighttan = tuple(mo.color.parseHexColor("f4f1c1"))
lightgreen = tuple(mo.color.parseHexColor("c1f4c2"))
goodblue = tuple((mo.array([0,0.5,1])*0.75).tolist())
lightblue = tuple(mo.color.parseHexColor("c1c1f4"))
redorange = tuple(mo.color.parseHexColor("ff6600"))




# Give it a name unique to this scene file.
# It's used to allow this scene file to export a video file
# in parallel with other scene files.
morpho.anim.exportSignature = "00_intro"

def main():
    # Define layers here
    mainlayer = morpho.Layer(view=mo.video.view169())
    gridlayer = mainlayer.copy()
    colorlayer = mainlayer.copy()
    mation = morpho.Animation([gridlayer, mainlayer, colorlayer])
    mation.windowShape = (1920, 1080)
    mation.fullscreen = True
    mation.background = lightgreen

    colorlayer.mask = mainlayer.copy()
    colorlayer.camera.first().visible = False

    # gridlayer.camera.first().view = [-1.5,2.5, -2, 8]
    gridlayer.camera.first().moveBy(-(-17.29-9.33j)).zoomIn(2.25, focus=0)
    gridview = [0,8, 0,8]

    gridlayer.camera.first().zoomOut(1.2)

    gridlayer.mask = gridlayer.copy()
    gridbox = mo.grid.rect(gridview, pad=0.25)
    gridbox = mo.Actor(gridbox)
    gridlayer.mask.merge(gridbox)

    mation.endDelay(30)  # Start of video pause

    grid = mo.grid.mathgrid(
        view=gridview,
        hcolor=[0,0,0.8], vcolor=[0,0.6,0], alpha=0.4,
        midWidth=2,
        steps=1,
        axesColor=[0,0,0], axisWidth=10,
        axes=False,
        )
    grid = mo.Actor(grid)
    gridlayer.merge(grid)
    grid.growIn(30)

    axes = mo.grid.Path([0,10,0,10j]).set(
        width=10, color=[0,0,0], deadends={1},
        zdepth=10
        )
    axes = mo.Actor(axes)
    gridlayer.merge(axes)
    axes.growIn(30)

    time = mation.lastID()
    box = gridview[:]
    gridBG = mo.grid.rect(box).set(
        width=0, fill=[1,1,1], alphaFill=1
        )
    gridBG = mo.Actor(gridBG)
    gridlayer.merge(gridBG, atFrame=0, beforeActor=0)
    gridBG.fadeIn(30)

    # mation.endDelayUntil()
    print("Draw x^3 curve and formula:", mation.seconds())

    time = mation.lastID()
    feq = mo.graphics.MultiImage("./resources/f-eq.png").set(
        pos=(12.3+4.7j), height=1.25, align=[1,0]
        )
    feq = mo.Actor(feq)
    mainlayer.merge(feq, atFrame=time)
    feq.fadeIn(20, jump=2j)

    xcubed = mo.graphics.MultiImage("./resources/x3.png").set(
        pos=feq.last().pos+0.5+0.2j, height=1.1,
        align=[-1,0]
        )
    xcubed = mo.Actor(xcubed)
    mainlayer.merge(xcubed, atFrame=time)
    xcubed.fadeIn(20, jump=2j)

    # Curve
    cubic = mo.graph.realgraph(lambda x: x**3, 0, 2.2).set(
        width=7, color=violet
        )
    cubic = mo.Actor(cubic)
    gridlayer.merge(cubic, atFrame=time)
    cubic.growIn(30)

    mation.endDelayUntil(4*30)
    print("Draw derivatives:", mation.seconds())

    time = mation.lastID()
    formulas = [feq, xcubed]

    dfeq = feq.last().copy()
    dfeq = mo.Actor(dfeq)
    formulas.append(dfeq)
    dfeq.newendkey(20).newSource("./resources/df-eq.png") \
        .scaleByHeight().pos -= 2j
    mainlayer.merge(dfeq, atFrame=time)

    threex2 = xcubed.last().copy()
    threex2 = mo.Actor(threex2)
    formulas.append(threex2)
    threex2.newendkey(20).newSource("./resources/3x2.png") \
        .scaleByHeight().pos -= 2j
    mainlayer.merge(threex2, atFrame=time)

    quad = mo.graph.realgraph(lambda x: 3*x**2, 0, 1.8).set(
        width=cubic.last().width, color=redorange
        )
    quad = mo.Actor(quad)
    gridlayer.merge(quad, atFrame=time)
    quad.growIn(20)

    time = mation.lastID()
    ddfeq = dfeq.last().copy()
    ddfeq = mo.Actor(ddfeq)
    formulas.append(ddfeq)
    ddfeq.newendkey(20).newSource("./resources/ddf-eq.png") \
        .scaleByHeight().pos -= 2j
    mainlayer.merge(ddfeq, atFrame=time)

    sixx = threex2.last().copy()
    sixx = mo.Actor(sixx)
    formulas.append(sixx)
    sixx.newendkey(20).newSource("./resources/6x.png") \
        .scaleByHeight().pos -= 2j+0.15j
    sixx.last().height *= 0.74
    mainlayer.merge(sixx, atFrame=time)

    line = mo.graph.realgraph(lambda x: 6*x, 0, 1.5, steps=1).set(
        width=cubic.last().width, color=[0.8,0,0]
        )
    line = mo.Actor(line)
    gridlayer.merge(line, atFrame=time)
    line.growIn(20)

    time = mation.lastID()
    dddfeq = ddfeq.last().copy()
    dddfeq = mo.Actor(dddfeq)
    formulas.append(dddfeq)
    dddfeq.newendkey(20).newSource("./resources/dddf-eq.png") \
        .scaleByHeight().pos -= 2j
    mainlayer.merge(dddfeq, atFrame=time)

    six = sixx.last().copy()
    six = mo.Actor(six)
    formulas.append(six)
    six.newendkey(20).newSource("./resources/6.png") \
        .scaleByHeight().pos -= 2j
    mainlayer.merge(six, atFrame=time)

    const = mo.graph.realgraph(lambda x: 6, 0, 8.5, steps=1).set(
        width=cubic.last().width, color=[0,0.6,0]
        )
    const = mo.Actor(const)
    gridlayer.merge(const, atFrame=time)
    const.growIn(20)

    mation.endDelayUntil(7.33*30)
    print("Remove coeffs and adjust graphs:", mation.seconds())

    time = mation.lastID()
    stagger = 0

    # Adjust formulas
    files = ["x2", "x", "1"]
    for n, formula in enumerate([threex2, sixx, six]):
        formula.newkey(time+n*stagger)
        formula.newendkey(30).newSource(f"./resources/{files[n]}.png")
        formula.last().scaleByHeight()
    sixx.last().height *= 0.7
    xsquared = threex2
    x_ = sixx
    one = six

    # Adjust curves
    funcs = [lambda x: x**2, lambda x: x, lambda x: 1]
    xlims = [3, 8.5, 8.5]
    for n, curve in enumerate([quad, line, const]):
        curve.newkey(time+n*stagger)
        func = funcs[n]
        xlim = xlims[n]
        steps = 50 if n == 0 else 1
        graph = mo.graph.realgraph(func, 0, xlim, steps=steps)
        graph.set(width=cubic.last().width, color=curve.last().color[:])
        curve.newendkey(30, graph)

    # Remove f labels
    mo.action.fadeOut([feq, dfeq, ddfeq, dddfeq], duration=30)

    mation.endDelayUntil(14.5*30)
    print("Arrows one formula to the next:", mation.seconds())

    pause = 18
    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    myformulas = [xcubed, xsquared, x_, one]
    for n, formula in enumerate(myformulas[:-1]):
        nextFormula = myformulas[n+1]
        arrow = mo.grid.arc(
            formula.last().pos+formula.last().width+0.5,
            nextFormula.last().pos+nextFormula.last().width+0.5,
            angle=-90*deg
            )
        arrow.set(width=4, headSize=25, color=goodblue)
        arrow = mo.Actor(arrow)
        mainlayer.merge(arrow, atFrame=time)
        arrow.growIn(20)
        arrow.newendkey(20).set(start=1, headSize=0, visible=False)
        mation.endDelay(pause)
        time = mation.lastID()

    mation.endDelayUntil(21.15*30)
    print("Add '= x^0':", mation.seconds())

    time = mation.lastID()
    eqx0 = mo.graphics.MultiImage("./resources/eq-x0.png").set(
        pos=one.last().pos+one.last().width+0.5+0.15j, align=[-1,0],
        height=xsquared.last().height
        )
    eqx0 = mo.Actor(eqx0)
    mainlayer.merge(eqx0, atFrame=time)
    eqx0.fadeIn(20, jump=2)

    mation.endDelayUntil(25.15*30)
    print("Insert power function tracker:", mation.seconds())

    # Draw ruler
    # mation.start = mation.lastID()  # BOOKMARK
    time = mation.lastID()
    xruler = 12
    ruler = mo.grid.Path([1j*feq.last().pos.imag+1j, 1j*dddfeq.last().pos.imag-1j])
    ruler.set(origin=xruler, width=4, color=[0,0,0])
    ruler = mo.Actor(ruler)
    mainlayer.merge(ruler, atFrame=time)
    ruler.growIn(30)

    ticks = ruler.last().copy()
    dx = 0.25
    # dx = 0
    ticks.seq = []
    for formula in [feq, dfeq, ddfeq, dddfeq]:
        ticks.seq += [-dx+1j*formula.last().pos.imag, dx+1j*formula.last().pos.imag]
    ticks.origin = xruler
    ticks.deadends = {1,3,5}
    ticks = mo.Actor(ticks)
    mainlayer.merge(ticks, atFrame=time)
    ticks.growIn(30)

    # Draw tracker
    time = mation.lastID()
    y3 = ticks.last().seq[0].imag
    y0 = ticks.last().seq[-1].imag
    grad = mo.color.Gradient({0:violet, 1/3:redorange, 2/3:(0.8,0,0), 1:(0,0.6,0)})
    @mo.SkitParameters(p=3, alpha=0)
    class PowerTracker(mo.Skit):
        def makeFrame(self):
            p = self.p
            alpha = self.alpha

            color = tuple(grad.value(mo.lerp(0,1, p, start=3, end=0)))
            x = mo.text.Text("x",
                pos=xruler-3+1j*mo.lerp(y3,y0, p, start=3, end=0),
                size=64, italic=True, color=color, alpha=alpha
                )
            power = mo.text.Text(mo.text.formatNumber(p, decimal=2, rightDigits=2),
                pos=x.pos+complex(0.5,0.5), anchor_x=-1,
                size=48, color=color, alpha=alpha
                )
            arrow = mo.grid.Arrow()
            arrow.head = xruler-dx*0+1j*x.pos.imag
            arrow.tail = arrow.head-1
            arrow.set(width=0, headSize=30, color=color, alpha=alpha)

            return mo.Frame([x, power, arrow])

    ptracker = PowerTracker()
    ptracker = mo.Actor(ptracker)
    mainlayer.merge(ptracker, atFrame=time)
    ptracker.fadeIn(20)

    mation.endDelay(30)

    time = mation.lastID() + 1
    # Puppet skit reacts to ptracker state
    class PowerCurve(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex

            p = ptracker.time(index).p
            color = tuple(grad.value(mo.lerp(0,1, p, start=3, end=0)))
            # curve = mo.graph.realgraph(lambda x: x**p, 0.05, mo.lerp(2.2, 8.5, p, start=3, end=1)).set(
            #     width=7, color=color
            #     )
            a = 0.05
            b = mo.lerp(2.2, 8.5, p, start=3, end=1)
            curve = mo.grid.line(a, b)
            curve = curve.fimage(lambda x: b*(x/b)**2)
            curve = curve.fimage(lambda x: x + 1j*x**p).set(
                width=7, color=color, dash=[20,10]
                )

            return curve

    pcurve = PowerCurve()
    pcurve = mo.Actor(pcurve)
    gridlayer.merge(pcurve, atFrame=time)

    # Start varying p
    ptracker.newkey(time)
    ptracker.newendkey(75).p = 0
    ptracker.newendkey(60).p = 2
    ptracker.newendkey(50).p = 1/2

    mation.endDelayUntil(34.15*30)
    print("Highlight square root of x:", mation.seconds())

    time = mation.lastID()
    brownroot = mo.graphics.MultiImage("./resources/brown-rootx.png").set(
        pos=(1.54-2.35j), height=1, align=[-1,0]
        )
    brownroot = mo.Actor(brownroot)
    mainlayer.merge(brownroot, atFrame=time)
    brownroot.fadeIn(20, jump=2)

    mation.endDelayUntil(35.25*30)
    print("Morph 0.5 to 1/2:", mation.seconds())

    # Morph the 0.50 into 1/2
    time = mation.lastID()
    ptracker.newkey(time)
    ptracker.last().visible = False
    frame = ptracker.last().makeFrame()
    xpow = mo.text.MultiText()
    xpow.figures = frame.figures[:2]
    pointer = frame.figures[-1]
    xpow = mo.Actor(xpow)
    pointer = mo.Actor(pointer)
    mainlayer.merge([xpow, pointer], atFrame=time)
    xpow.newendkey(20).figures[1].text = "1/2"

    mation.endDelayUntil(42.5*30)
    print("Return to a decimal tracker and scoot some more:", mation.seconds())

    time = mation.lastID()
    xpow.newkey(time)
    xpow.newendkey(20, xpow.first().copy())

    brownroot.newkey(time)
    brownroot.rollback(20)

    time = mation.lastID()
    for actor in [xpow, pointer]:
        actor.newkey(time).visible = False
    ptracker.newkey(time).visible = True

    ptracker.newendkey(90).p = 3

    mation.endDelayUntil(50.15*30)
    print("Morph back to deriv chain:", mation.seconds())

    time = mation.lastID()
    # mation.start = time  # BOOKMARK
    pcurve.newkey(time).visible = False
    ptracker.newkey(time)
    ptracker.fadeOut(20)

    mo.action.fadeIn([feq, dfeq, ddfeq, dddfeq],
        duration=20, atFrame=time, stagger=4, jump=1j)

    ruler.newkey(time)
    ruler.newendkey(20).origin = 7.46
    ticks.newkey(time)
    ticks.newendkey(20).origin = 7.46

    for actor in [quad, line, const]:
        actor.newkey(time)
        actor.newkey(mation.lastID(), actor.key[1].copy())
    for n, actor in enumerate([xsquared, x_, one]):
        actor.newkey(time+n*stagger)
        actor.newendkey(20, actor.key[1].copy())
    eqx0.newkey(six.keyID(-2))
    eqx0.fadeOut(20)

    time = ptracker.lastID()
    ddx_base = mo.graphics.Image("./resources/ddx-x3.png")
    xruler2 = ruler.last().origin
    @mo.SkitParameters(p=3, alpha=0)
    class DerivTracker(mo.Skit):
        def makeFrame(self):
            p = self.p
            alpha = self.alpha

            color = (0,0,0)
            ddx = mo.graphics.Image(ddx_base).set(
                pos=xruler2-2.75+1j*mo.lerp(y3,y0, 3-p, start=3, end=0),
                height=2, alpha=alpha
                )
            power = mo.text.Text(mo.text.formatNumber(p, decimal=2, rightDigits=2),
                pos=ddx.pos+complex(0.15,1), anchor_x=-1,
                size=38, color=color, alpha=alpha
                )
            arrow = mo.grid.Arrow()
            arrow.head = xruler2-dx*0+1j*ddx.pos.imag
            arrow.tail = arrow.head-1
            arrow.set(width=0, headSize=30, color=color, alpha=alpha)

            return mo.Frame([ddx, power, arrow])

    dtracker = DerivTracker(p=0)
    dtracker = mo.Actor(dtracker)
    colorlayer.mask.merge(dtracker, atFrame=time)
    dtracker.fadeIn(20)

    rectbase = mo.grid.rect(mainlayer.viewtime(0)).set(width=0)
    # Puppet skit reacts to dtracker's p-value and changes its
    # color accordingly.
    class BG(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex

            p = dtracker.time(index).p
            color = tuple(grad.value(mo.lerp(0,1, p, start=0, end=3)))
            rect = rectbase.copy().set(fill=color)
            return rect

    bg = BG()
    bg = mo.Actor(bg)
    colorlayer.merge(bg, atFrame=time)
    colorlayer.camera.newkey(time).visible = True

    time = mation.lastID()
    gridlayer.camera.newkey(time)
    gridlayer.camera.newendkey(30).zoomIn(2.5, focus=0)

    mation.endDelayUntil(56.33*30)
    print("Start varying the fractional order:", mation.seconds())

    time = mation.lastID()
    dtracker.newkey(time)
    dtracker.newendkey(75).p = 2
    dtracker.newendkey(60).p = 1/2

    # Puppet skit reacts to dtracker p-value and draws the
    # corresponding fractional derivative curve.
    fcurve_base = FuncFrac(
        func=lambda x: x**3, domain=[0,8.5], steps=100,
        width=cubic.last().width, dash=(20,10)
        ).set(interpMethod=None)
    class FracCurve(mo.Skit):
        def makeFrame(self, index=None):
            if index is None:
                index = mation.currentIndex

            p = dtracker.time(index).p
            color = tuple(grad.value(mo.lerp(0,1, p, start=0, end=3)))

            a = 0
            b = 2.2 if p < 2 else mo.lerp(2.2, 8.5, p, start=2, end=3)
            # curve = mo.grid.line(a, b)
            # curve = curve.fimage(lambda x: b*(x/b)**2)
            # curve = curve.fimage(lambda x: x + 1j*x**p).set(
            #     width=7, color=color, dash=[20,10]
            #     )

            curve = fcurve_base.copy()
            curve.domain = [a,b]
            curve.color = color
            curve.p = p
            curve.steps = 100

            return curve

    fcurve = FracCurve()
    gridlayer.merge(fcurve, atFrame=dtracker.firstID())
    # print(fcurve.makeFrame(index=dtracker.keyID(-2)+10).p)
    # return

    mation.endDelayUntil(65.33*30)
    print("Show half-deriv of sin(x):", mation.seconds())

    time = mation.lastID()
    sine = mo.graphics.Image("./resources/ddx-sine-question.png").set(
        pos=(3.94-4j), height=2.5, align=[-1,0]
        )
    sine = mo.Actor(sine)
    mainlayer.merge(sine, atFrame=time)
    sine.fadeIn(20, jump=2j)

    mation.endDelayUntil(66.75*30)
    print("Show half-deriv of exp(x):", mation.seconds())

    exp = mo.graphics.Image("./resources/ddx-exp-question.png").set(
        pos=sine.last().pos-3j, height=sine.last().height, align=[-1,0]
        )
    exp = mo.Actor(exp)
    mainlayer.append(exp)
    exp.fadeIn(20, jump=2j)






    print("Animation length:", mation.seconds())
    mation.endDelay(10*30)

    # mation.finitizeDelays(30)

    # mation.start = mation.lastID()
    mation.locatorLayer = mainlayer
    mation.clickRound = 2
    mation.clickCopy = True
    # mation.newFrameRate(10)
    # mation.play()

    mation.newFrameRate(60)
    mation.export("./00_intro.mp4", scale=1)


main()
